METADATA
last updated: 2025-12-14 RT updated metadata after BA fixed inconsistencies
file_name: Decontamination Procedures.md
file_date: 2022-10-11
title: Decontamination Procedures
category: guides
subcategory: test-site
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1v7rhZUefNCPczjkAUY3J8IHDkIn_23ZJ7zA5iTjWv6c
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/guides/test-site/Decontamination%20Procedures.docx
pdf_gdrive_url: https://drive.google.com/file/d/1fmixGyoyCiyXrQfdTgMft8BYyTwJ3Lgf
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/test-site/Decontamination%20Procedures.pdf
conversion_input_file_type: docx
conversion: pandoc
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 888
words: 624
notes: 
summary_short: The Decontamination Procedures guide defines light, moderate, and draft heavy cleaning workflows for FloodLAMP test-site assay rooms, including PPE requirements and specific steps for surfaces, carts/drawers, racks, floors, and high-touch areas. It standardizes use of 10% bleach followed by 70% ethanol/IPA (with recommended dwell time) and emphasizes contamination control around the amplification area and reagent aliquots.


CONTENT

## Notes
-   For all steps in this document that specify ‘**wiping down**’, this means first wiping down with a 10% bleach solution and then 70% ethanol or IPA.  When practicable, allow the bleach solution to remain on the surface for 5-10 minutes prior to wiping away and then wiping with ethanol/IPA.
-   It can be helpful as a reminder to place tape on the ground near the amplification station if this isn’t already done. This demarcates the line beyond which any materials that enter the amp area do not leave.
-   When in the amp area, be mindful that your lab coat doesn’t touch any of the surfaces.
-   Wash lab coats regularly if they are not disposable.
-   It is advisable to ***decontaminate the amplification area last*** in any given cleaning session.
-   Wear a clean lab coat, gloves, safety glasses, mask during decontamination

## Light Decontamination
-   Prepare fresh 10% bleach solution
-   **Wipe down** all surfaces (any benches, tables, chairs, shelves that are in active use)
-   Remove all items from the four drawers in the cart
-   Thoroughly **wipe down** the inside of the drawers
-   **Wipe down** the pipettes and the outer surfaces of tip boxes
-   Refill the drawers
-   Discard the current 1X Inactivation solution aliquot

## Moderate Decontamination
In addition to all of the Light Decontamination steps above:
-   Prepare a 10% bleach bath for the plastic tube racks
-   Allow plastic tube racks to sit in the bath for 5-10 minutes, then wipe dry
-   Spray the racks thoroughly with ethanol and wipe dry
-   Place cleaned racks in a clean bin for storage
-   Cleaned every tip box (including those not actively in use), and pack into clean bin for storage
-   **Wipe down** all objects on benches and tables (equipment, pens, etc)
-   **Wipe down** all parts of walls & doors that are ever touched (doorknobs, hooks, rails, etc)
-   Within reason, **wipe down** wall surfaces (portions that are reasonably accessible)
-   Sweep the floor of any particles
-   **Wipe down** the floor with a swiffer, mop, or other implement
    -   *Ensure proper ventilation of the space during this step, but do not allow dust or other particulates to blow into the room.*
-   Discard the current aliquot of 100X Inactivation Solution
-   If current supply allows (and depending on how much remains), discard the current aliquot of PGS - this is a judgment call.

## Heavy Decontamination - DRAFT IN PROGRESS
1\)  In a space outside the test room, lay down a clean tarp (if available)
2\)  Remove all furniture and all other equipment and material from the assay room ***except*** the amplification station and place them on the tarp (or other clean floor area)
3\)  Fresh bleach prepared
4\)  Disposable lab coat used
5\)  Put all loose items into bins
6\)  Remove shelves from room
7\)  Removed all bins in room
8\)  Mopped the floors with Bleach (using normal mop)
9\)  Mopped floors with ethanol using swiffer pad made from ethanol soaked shop towels
10\)  All walls and ceiling wiped with bleach soaked shop towels
11\)  All walls and ceiling wiped with ethanol soaked shop towels
    a\)  Take great caution of fumes, especially since windows are not open for cleanliness reasons
12\)  Bench was wiped down
13\)  Shelves were wiped down as they were put back into the test room
14\)  Wiped down mallet was used to adjust shelves
15\)  Outside of all bins were wiped as they were put back onto the shelves
16\)  All Pipettes were wiped down
17\)  Open tip boxes thrown out
18\)  Amp specific spray bottles made
19\)  Amp area bleached and ethanol wiped
20\)  Amp Heater wiped
21\)  Amp lab coat thrown out (disposable)
