METADATA
last updated: 2025-12-15 RT updated metadata after BA fixed inconsistencies
file_name: Site Checklist - Alpine.md
file_date: 2022-05-24
title: Test Site Checklist - Alpine
category: guides
subcategory: test-site
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1qeZHKgUPQ7ENf7JxHa9MjvVvWuVkw0IUbxPmbd0U9-A
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/guides/test-site/Site%20Checklist%20-%20Alpine.docx
pdf_gdrive_url: https://drive.google.com/file/d/1PKufMY-68iBrvLUC6dRfTwBpOqOZSQh-
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/test-site/Site%20Checklist%20-%20Alpine.pdf
conversion_input_file_type: docx
conversion: pandoc
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 836
words: 544
notes: 
summary_short: The Test Site Checklist – Alpine provides step-by-step daily, weekly, and readiness checklists for running FloodLAMP testing at the Alpine site, including setup, reagent/consumables checks, intake logistics, run timing, rerun decision-making, and end-of-day cleanup. It standardizes site operations and communication (via the designated Slack channel) to ensure consistent testing workflow, inventory control, and equipment readiness.


CONTENT

## Testing Checklist - Alpine v1.1
Last updated: 5-24-2022 RT GW BS
For all ***communication*** steps specified below, use the Slack channel: **\# testing-alpine_portola**

### Before Arrival
-   Confirm Heaters turned on (text Randy & Theresa if confirmation not received by 8am)

### Upon Arrival 
Time:
-   Prepare 10% Bleach Solution
-   Double check water bath up to temp
-   Clean Inactivation Table
-   Set up Inactivation Table
-   Check sufficient 1XISS (or make) and Rxn Mix (frozen or source tubes), and *not expired*
-   Check sufficient consumables for usage (1.5mL tubes, strip-8s, tips, reservoirs)
-   Ensure you have expected tubes from staff
-   Check red mailbox for tubes CODE: 513

### At Carillon
Time:
-   Travel to Carillon and set up at drop off point 
-   Intake Collection tubes already dropped off
-   Continue intaking as participants drop off tubes until cut off time 9:05
-   ***Communicate*** intake anomalies (QR code and anomaly description)

### Upon Return to Alpine 
Time: 
-   Turn off air purifiers before beginning the test procedure. Keep the door closed.
-   Run test
-   When on amp, ***communicate*** time expected to remove from amp
-   Check with FL Program Admin if positives are known or unknown. Rerun if unknown.
-   ***Communicate*** Result image & lookup map 
Time:
-   Mark result on lookup map as a circled ‘P’ or ‘I’ at the end of the tube code
-   Wait 5 mins for confirmation of whether any positives are known positives
-   ***Communicate*** re-run plan for all inconclusives and unknown positives
    I.e.: “re-running 1 positive, 1 inconclusive in triplicate”
-   Re-run test
-   ***Communicate*** re-run results ETA
-   ***Communicate*** final results and time
Time:
-   Return cold blocks to freezer
-   Return pipettes, tip boxes, racks
-   Check that all thawed inactivation solution bottles & vials are covered in foil
-   Discard sample tubes from refrigerator (neg. in trash, pos. in bag in bottom freezer)
-   Turn off heaters
-   Empty and clean tip buckets with bleach and ethanol

## Weekly Checklist - Alpine v1.1
-   Update complete Inventory
-   Submit inventory to FL
-   Audit freezer sensor data for anomalies
-   Check Expiration dates of reagents
-   Empty trash bins
-   OPTIONALLY: Prepare reaction tubes for the week, and freeze
-   AS NEEDED: receive deliveries
    -   Use included ship list to verify contents
    -   ***Communicate*** any discrepancies to **\# testing - alpine**
    -   Update Inventory with new materials

## State Of Readiness Checklist - Alpine v1.1
-   Glove boxes BOTH in assay prep room AND amplification area
-   Wipes present (one active, plus extra on supply shelf)
-   Empty Tip box filled with strip tubes (fill tip box + half source box)
-   Falcon Tubes Filled with strip tube caps (two full falcon tubes, + half source box)
-   1.5mL tubes closed and in cleaned, labeled cryobox (1 active box, Next box fully ready)
-   At least 5 blank Amp run forms, and at least 1 spare of both table forms (1X ISS & RM)
-   Pens and markers clean and in proper place
    -   Pens tested and functional
-   Spare tube of inactivation solution in freezer
-   Freezer thermometer tested and functional
-   Lightbox battery charged and functional
-   Old non-significant samples clear from fridge
-   Tip buckets empty
