METADATA
last updated: 2025-12-14 RT after BA fixed inconsistencies
file_name: SDS - Clorox Bleach Regular.md
file_date: 2015-06-12
title: Safety Data Sheet - Clorox Bleach Regular
category: guides
subcategory: sds
tags: 
source_file_type: pdf
xfile_type: NA
gfile_url: NA
xfile_github_download_url: NA
pdf_gdrive_url: https://drive.google.com/file/d/1VwgYf7av-AJU_gvS-kpyu0THWaCg2Tvo
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/sds/SDS%20-%20Clorox%20Bleach%20Regular.pdf
conversion_input_file_type: pdf
conversion: ai (claude sonnet 3.5)
license: public domain
tokens: 4190
words: 2755
notes: 
summary_short: The Safety Data Sheet for Clorox® Regular Bleach (sodium hypochlorite 5–10%) outlines hazards, first aid, handling/storage, PPE, and disposal guidance for household disinfecting, sanitizing, and laundry use. It highlights severe skin and eye corrosion risks, toxic gas generation when mixed with acids or ammonia-containing cleaners, and high aquatic toxicity. The sheet also summarizes transport status and key regulatory notes (including EPA pesticide labeling and reportable quantity thresholds).


CONTENT

***INTERNAL TITLE:*** The Clorox Company - Safety Data Sheet

**Issuing Date** January 5, 2015 
**Revision Date** June 12, 2015 
**Revision Number** 1

## 1. Identification of the Substance/Preparation and of the Company/Undertaking
### Product Identifier
**Product Name**: Clorox® Regular-Bleach¹

### Other means of identification
**EPA Registration Number**: 5813-100

### Recommended Use of the Chemical and Restrictions on Use
**Recommended Use**: Household disinfecting, sanitizing, and laundry bleach
**Uses Advised Against**: No information available

### Details of the Supplier of the Safety Data Sheet
**Supplier Address**:
  The Clorox Company
  1221 Broadway
  Oakland, CA 94612

**Phone**: 1-510-271-7000

### Emergency Telephone Number
**Emergency Phone Numbers**:
For Medical Emergencies, call: 1-800-446-1014
For Transportation Emergencies, call Chemtrec: 1-800-424-9300

## 2. Hazards Identification
### Classification
This chemical is considered hazardous by the 2012 OSHA Hazard Communication Standard (29 CFR 1910.1200).
|  |  |
|--------|----------------|
| Skin corrosion/irritation | Category 1 |
| Serious eye damage/eye irritation | Category 1 |
||

### GHS Label Elements, Including Precautionary Statements
#### Emergency Overview
**Signal Word**: Danger
**Hazard Statements**:
Causes severe skin burns and eye damage
Causes serious eye damage
**Appearance**: Clear, pale yellow
**Physical State**: Thin liquid
**Odor**: Bleach

### Precautionary Statements - Prevention
Wash face, hands and any exposed skin thoroughly after handling.
Wear protective gloves, protective clothing, face protection, and eye protection such as safety glasses.

### Precautionary Statements - Response
Immediately call a poison center or doctor.
If swallowed: Rinse mouth. Do NOT induce vomiting.
If on skin (or hair): Take off immediately all contaminated clothing. Rinse skin with water.
Wash contaminated clothing before reuse.
If inhaled: Remove person to fresh air and keep comfortable for breathing.
Specific treatment (see supplemental first aid instructions on this label).
If in eyes: Rinse cautiously with water for several minutes. Remove contact lenses, if present and easy to do. Continue rinsing.

### Precautionary Statements - Storage
Store locked up.

### Precautionary Statements - Disposal
Dispose of contents in accordance with all applicable federal, state, and local regulations.

### Hazards Not Otherwise Classified (HNOC)
Although not expected, heart conditions or chronic respiratory problems such as asthma, chronic bronchitis, or obstructive lung disease may be aggravated by exposure to high concentrations of vapor or mist.

Product contains a strong oxidizer. Always flush drains before and after use.

### Unknown Toxicity
Not applicable.

### Other Information
Very toxic to aquatic life with long lasting effects.

### Interactions with Other Chemicals
Reacts with other household chemicals such as toilet bowl cleaners, rust removers, acids, or products containing ammonia to produce hazardous irritating gases, such as chlorine and other chlorinated compounds.

## 3. Composition/Information on Ingredients
| Chemical Name | CAS-No | Weight % | Trade Secret |
|---------------|--------|----------|--------------|
| Sodium hypochlorite | 7681-52-9 | 5 - 10 | * |
||

*The exact percentage (concentration) of composition has been withheld as a trade secret.

## 4. First Aid Measures
### First Aid Measures
**General Advice**
Call a poison control center or doctor immediately for treatment advice. Show this safety data sheet to the doctor in attendance.

**Eye Contact**
Hold eye open and rinse slowly and gently with water for 15 - 20 minutes. Remove contact lenses, if present, after the first 5 minutes, then continue rinsing eye. Call a poison control center or doctor for treatment advice.

**Skin Contact**
Take off contaminated clothing. Rinse skin immediately with plenty of water for 15-20 minutes. Call a poison control center or doctor for treatment advice.

**Inhalation**
Move to fresh air. If breathing is affected, call a doctor.

**Ingestion**
Have person sip a glassful of water if able to swallow. Do not induce vomiting unless told to do so by a poison control center or doctor. Do not give anything by mouth to an unconscious person. Call a poison control center or doctor immediately for treatment advice.

**Protection of First-Aiders**
Avoid contact with skin, eyes, and clothing. Use personal protective equipment as required. Wear personal protective clothing (see section 8).

### Most Important Symptoms and Effects, Both Acute and Delayed
**Most Important Symptoms and Effects**
Burning of eyes and skin.

### Indication of Any Immediate Medical Attention and Special Treatment Needed
**Notes to Physician**
Treat symptomatically. Probable mucosal damage may contraindicate the use of gastric lavage.

## 5. Fire-Fighting Measures
### Suitable Extinguishing Media
Use extinguishing measures that are appropriate to local circumstances and the surrounding environment.

### Unsuitable Extinguishing Media
CAUTION: Use of water spray when fighting fire may be inefficient.

### Specific Hazards Arising from the Chemical
This product causes burns to eyes, skin, and mucous membranes. Thermal decomposition can release sodium chlorate and irritating gases and vapors.

### Explosion Data
**Sensitivity to Mechanical Impact**: None.
**Sensitivity to Static Discharge**: None.

### Protective Equipment and Precautions for Firefighters
As in any fire, wear self-contained breathing apparatus pressure-demand, MSHA/NIOSH (approved or equivalent) and full protective gear.

## 6. Accidental Release Measures
### Personal Precautions, Protective Equipment and Emergency Procedures
**Personal Precautions**
Avoid contact with eyes, skin, and clothing. Ensure adequate ventilation. Use personal protective equipment as required. For spills of multiple products, responders should evaluate the MSDSs of the products for incompatibility with sodium hypochlorite. Breathing protection should be worn in enclosed and/or poorly-ventilated areas until hazard assessment is complete.

**Other Information**
Refer to protective measures listed in Sections 7 and 8.

### Environmental Precautions
**Environmental Precautions**
This product is toxic to fish, aquatic invertebrates, oysters, and shrimp. Do not allow product to enter storm drains, lakes, or streams. See Section 12 for ecological Information.

### Methods and Material for Containment and Cleaning Up
**Methods for Containment**
Prevent further leakage or spillage if safe to do so.

**Methods for Cleaning Up**
Absorb and containerize. Wash residual down to sanitary sewer. Contact the sanitary treatment facility in advance to assure ability to process washed-down material.

## 7. Handling and Storage
### Precautions for Safe Handling
**Handling**
Handle in accordance with good industrial hygiene and safety practice. Avoid contact with skin, eyes, and clothing. Do not eat, drink, or smoke when using this product.

### Conditions for Safe Storage, Including Any Incompatibilities
**Storage**
Store away from children. Reclose cap tightly after each use. Store this product upright in a cool, dry area, away from direct sunlight and heat to avoid deterioration. Do not contaminate food or feed by storage of this product.

**Incompatible Products**
Toilet bowl cleaners, rust removers, acids, and products containing ammonia.

## 8. Exposure Controls/Personal Protection
### Control Parameters
**Exposure Guidelines**
| Chemical Name | ACGIH TLV | OSHA PEL | NIOSH IDLH |
|---------------|-----------|----------|------------|
| Sodium hypochlorite 7681-52-9 | None | None | None |
||

ACGIH TLV: American Conference of Governmental Industrial Hygienists - Threshold Limit Value
OSHA PEL: Occupational Safety and Health Administration - Permissible Exposure Limits
NIOSH IDLH: Immediately Dangerous to Life or Health

### Appropriate Engineering Controls
**Engineering Measures**
Showers
Eyewash stations
Ventilation systems

### Individual Protection Measures, Such as Personal Protective Equipment
**Eye/Face Protection**
If splashes are likely to occur: Wear safety glasses with side shields (or goggles) or face shield.

**Skin and Body Protection**
Wear rubber or neoprene gloves and protective clothing such as long-sleeved shirt.

**Respiratory Protection**
If irritation is experienced, NIOSH/MSHA approved respiratory protection should be worn. Positive-pressure supplied air respirators may be required for high airborne contaminant concentrations. Respiratory protection must be provided in accordance with current local regulations.

**Hygiene Measures**
Handle in accordance with good industrial hygiene and safety practice. Wash hands after direct contact. Do not wear product-contaminated clothing for prolonged periods. Remove and wash contaminated clothing before re-use. Do not eat, drink, or smoke when using this product.

## 9. Physical and Chemical Properties
### Physical and Chemical Properties
**Physical State** Thin liquid
**Appearance** Clear 
**Color** Pale yellow
**Odor** Bleach
**Odor Threshold** No information available

| Property | Value | Remarks/Method |
|----------|-------|----------------|
| Physical State | Thin liquid | None known |
| Appearance | Clear | None known |
| Color | Pale yellow | None known |
| Odor | Bleach | None known |
| Odor Threshold | No information available | None known |
| pH | ~12 | None known |
| Melting/freezing point | No data available | None known |
| Boiling point / boiling range | No data available | None known |
| Flash Point | Not flammable | None known |
| Evaporation rate | No data available | None known |
| Flammability (solid, gas) | No data available | None known |
| Flammability Limits in Air | | |
| Upper flammability limit | No data available | None known |
| Lower flammability limit | No data available | None known |
| Vapor pressure | No data available | None known |
| Vapor density | No data available | None known |
| Specific Gravity | ~1.1 | None known |
| Water Solubility | Soluble | None known |
| Solubility in other solvents | No data available | None known |
| Partition coefficient: n-octanol/water | No data available | None known |
| Autoignition temperature | No data available | None known |
| Decomposition temperature | No data available | None known |
| Kinematic viscosity | No data available | None known |
| Dynamic viscosity | No data available | None known |
| Explosive Properties | Not explosive | |
| Oxidizing Properties | No data available | |
||

### Other Information
| Property | Value |
|----------|-------|
| Softening Point | No data available |  
| VOC Content (%) | No data available |  
| Particle Size | No data available | 
| Particle Size Distribution | No data available | 
||

## 10. Stability and Reactivity
### Reactivity
Reacts with other household chemicals such as toilet bowl cleaners, rust removers, acids, or products containing ammonia to produce hazardous irritating gases, such as chlorine and other chlorinated compounds.

### Chemical Stability
Stable under recommended storage conditions.

### Possibility of Hazardous Reactions
None under normal processing.

### Conditions to Avoid
None known based on information supplied.

### Incompatible Materials
Toilet bowl cleaners, rust removers, acids, and products containing ammonia.

### Hazardous Decomposition Products
None known based on information supplied.

## 11. Toxicological Information
### Information on Likely Routes of Exposure
#### Product Information
**Inhalation**
Exposure to vapor or mist may irritate respiratory tract and cause coughing. Inhalation of high concentrations may cause pulmonary edema.

**Eye Contact**
Corrosive. May cause severe damage to eyes.

**Skin Contact**
May cause severe irritation to skin. Prolonged contact may cause burns to skin.

**Ingestion**
Ingestion may cause burns to gastrointestinal tract and respiratory tract, nausea, vomiting, and diarrhea.

#### Component Information

| Chemical Name | LD50 Oral | LD50 Dermal | LC50 Inhalation |
|---------------|-----------|-------------|-----------------|
| Sodium hypochlorite 7681-52-9 | 8200 mg/kg (Rat) | >10000 mg/kg (Rabbit) | - |
||

### Information on Toxicological Effects
**Symptoms**
May cause redness and tearing of the eyes. May cause burns to eyes. May cause redness or burns to skin. Inhalation may cause coughing.

### Delayed and Immediate Effects as well as Chronic Effects from Short and Long-Term Exposure
**Sensitization**
No information available.

**Mutagenic Effects**
No information available.

**Carcinogenicity**
The table below indicates whether each agency has listed any ingredient as a carcinogen.
| Chemical Name | ACGIH | IARC | NTP | OSHA |
|---------------|-------|------|-----|------|
| Sodium hypochlorite 7681-52-9 | - | Group 3 | - | - |
||

IARC (International Agency for Research on Cancer)
Group 3 - Not Classifiable as Carcinogenicity in Humans

**Reproductive Toxicity**
No information available.

**STOT - Single Exposure**
No information available.

**STOT - Repeated Exposure**
No information available.

**Chronic Toxicity**
Carcinogenic potential is unknown.

**Target Organ Effects**
Respiratory system, eyes, skin, gastrointestinal tract (GI).

**Aspiration Hazard**
No information available.

### Numerical Measures of Toxicity - Product Information
The following values are calculated based on chapter 3.1 of the GHS document:
**ATEmix (oral)** 
54 g/kg
**ATEmix (inhalation-dust/mist)**
58 mg/L

## 12. Ecological Information
### Ecotoxicity
Very toxic to aquatic life with long lasting effects.

This product is toxic to fish, aquatic invertebrates, oysters, and shrimp. Do not allow product to enter storm drains, lakes, or streams.

### Persistence and Degradability
No information available.

### Bioaccumulation
No information available.

### Other Adverse Effects
No information available.

## 13. Disposal Considerations
### Disposal Methods
Dispose of in accordance with all applicable federal, state, and local regulations. Do not contaminate food or feed by disposal of this product.

### Contaminated Packaging
Do not reuse empty containers. Dispose of in accordance with all applicable federal, state, and local regulations.

## 14. Transport Information
### DOT
Not restricted.

### TDG
Not restricted for road or rail.

### ICAO
Not restricted, as per Special Provision A197, Environmentally Hazardous Substance exception.

### IATA
Not restricted, as per Special Provision A197, Environmentally Hazardous Substance exception.

### IMDG/IMO
Not restricted, as per IMDG Code 2.10.2.7, Marine Pollutant exception.

## 15. Regulatory Information
### Chemical Inventories
**TSCA**
All components of this product are either on the TSCA 8(b) Inventory or otherwise exempt from listing.

**DSL/NDSL**
All components are on the DSL or NDSL.

**TSCA** - United States Toxic Substances Control Act Section 8(b) Inventory
**DSL/NDSL** - Canadian Domestic Substances List/Non-Domestic Substances List

### U.S. Federal Regulations
**SARA 313**
Section 313 of Title III of the Superfund Amendments and Reauthorization Act of 1986 (SARA). This product does not contain any chemicals which are subject to the reporting requirements of the Act and Title 40 of the Code of Federal Regulations, Part 372.

**SARA 311/312 Hazard Categories**
- Acute Health Hazard: Yes
- Chronic Health Hazard: No
- Fire Hazard: No
- Sudden Release of Pressure Hazard: No
- Reactive Hazard: No

**Clean Water Act**
This product contains the following substances which are regulated pollutants pursuant to the Clean Water Act (40 CFR 122.21 and 40 CFR 122.42)
| Chemical Name | CWA - Reportable Quantities | CWA - Toxic Pollutants | CWA - Priority Pollutants | CWA - Hazardous Substances |
|---------------|------------------------------|------------------------|---------------------------|----------------------------|
| Sodium hypochlorite 7681-52-9 | 100 lb | - | - | X |
||

**CERCLA**
This material, as supplied, contains one or more substances regulated as a hazardous substance under the Comprehensive Environmental Response Compensation and Liability Act (CERCLA) (40 CFR 302)
| Chemical Name | Hazardous Substances RQs | Extremely Hazardous Substances RQs | RQ |
|---------------|---------------------------|------------------------------------|----|
| Sodium hypochlorite 7681-52-9 | 100 lb | - | RQ 100 lb final RQ RQ 45.4 kg final RQ |
||

**EPA Statement**
This chemical is a pesticide product registered by the Environmental Protection Agency and is subject to certain labeling requirements under federal pesticide law. These requirements differ from the classification criteria and hazard information required for safety data sheets and for workplace labels of non-pesticide chemicals. Following is the hazard information as required on the pesticide label:

**DANGER: CORROSIVE.** Causes irreversible eye damage and skin burns. Harmful if swallowed. Do not get in eyes, on skin, or on clothing. Wear protective eyewear and rubber gloves when handling this product. Wash thoroughly with soap and water after handling and before eating, drinking, chewing gum, using tobacco, or using the restroom. Avoid breathing vapors and use only in a well-ventilated area.

### US State Regulations
**California Proposition 65**
This product does not contain any Proposition 65 chemicals.

**U.S. State Right-to-Know Regulations**
| Chemical Name | New Jersey | Massachusetts | Pennsylvania | Rhode Island | Illinois |
|---------------|------------|---------------|--------------|--------------|----------|
| Sodium hypochlorite 7681-52-9 | X | X | X | X | - |
| Sodium chlorate 7775-09-9 | X | X | X | - | - |
||

### International Regulations
**Canada**
WHMIS Hazard Class
E - Corrosive material

## 16. Other Information
### NFPA   
Health Hazard: 3
Flammability: 0
Instability: 0
Physical and Chemical Hazards: -

### HMIS   
Health Hazard: 3
Flammability: 0
Physical Hazard: 0
Personal Protection: B

**Prepared By**
Product Stewardship  
23 British American Blvd.  
Latham, NY 12110  
1-800-572-6501

**Revision Date**
June 12, 2015

**Revision Note**
Revision Section 14.

**Reference**
1096036/164964.159  

### General Disclaimer
The information provided in this Safety Data Sheet is correct to the best of our knowledge, information and belief at the date of its publication. The information given is designed only as a guidance for safe handling, use, processing, storage, transportation, disposal, and release and is not to be considered a warranty or quality specification. The information relates only to the specific material designated and may not be valid for such material used in combination with any other materials or in any process, unless specified in the text.

End of Safety Data Sheet
