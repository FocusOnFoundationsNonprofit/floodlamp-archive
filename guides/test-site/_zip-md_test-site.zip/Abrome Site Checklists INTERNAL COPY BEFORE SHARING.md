METADATA
last updated: 2025-12-14 RT updated metadata
file_name: Abrome Site Checklists INTERNAL COPY BEFORE SHARING.md
file_date: 2022-09-04
title: Testing Site Checklists
category: guides
subcategory: test-site
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1Plnksj-OwJzUV9f0WIvhQncd_pBCS50HJuw-lSi7IqM
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive-wip/main/guides/test-site/Abrome%20Site%20Checklists%20INTERNAL%20COPY%20BEFORE%20SHARING.docx
pdf_gdrive_url: https://drive.google.com/file/d/1jy34vLE5VOkjL2RXIq_ATPv92UBJhfgP
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive-wip/blob/main/guides/test-site/Abrome%20Site%20Checklists%20INTERNAL%20COPY%20BEFORE%20SHARING.pdf
conversion_input_file_type: docx
conversion: pandoc
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 1272
words: 704
notes: 
summary_short: Provides the complete operational checklists for running FloodLAMP surveillance tests at testing sites, covering daily test procedures (equipment warm-up, reagent verification, sample processing, result communication), weekly maintenance, and ongoing lab readiness standards. It standardizes the testing workflow to ensure accurate results, proper reagent handling, and timely follow-up on positive/inconclusive pools. This was introduced at the pilot site Abrome.


CONTENT

## Testing Checklist - Abrome v1.1
Last updated: 9-4-2022 by Randy True
Direct any questions to support@floodlamp.bio

### Upon Arrival
- Water bath & amp heater turned on ***at least one hour*** before starting to process samples
  - Can add boiling water from kettle to speed up the process
  - Change water bath water weekly

### During Water Bath Heating
-   Review freezer sensor data to ensure no thawing occurred.
-   Prepare fresh 10% Bleach Solution, preferably daily, but at least every 3 days.
-   Clean Inactivation Table thoroughly - first with 10% bleach, then with 70% ethanol or IPA.
-   Set up Inactivation Table.
-   Verify sufficient 1XISS is prepared (minimum 1 mL per sample, plus extra 5mL) **AND < 2 weeks old**
    -   Otherwise prepare 1XISS: [SOP-101-A\_2 1X Inactivation Saline Solution Prep - Table Form - Abrome.pdf](https://drive.google.com/file/d/1OLXQShwg3ecKP3Os5c2JDuG3UCbrbuiQ/view?usp=sharing)
-   Verify sufficient aliquots of RM (one per sample + two for controls, plus extra) **AND not expired** (< 4 weeks old, no visible discoloration)
    -   Otherwise prepare RM: [SOP-102-A\_2 Reaction Mix Prep - Table Form - Abrome.pdf](https://drive.google.com/file/d/1Qv8Bk1rReWMlm9Z3X3sK9cdq9YcxL8Vt/view?usp=sharing)
    -   RM in strips-of-8 tubes to be used today can be kept in refrigerator until use
    -   Any additional RM in strips-of-8 tubes should be placed immediately in freezer
        -   Verify that caps are tightly sealed!
-   Verify sufficient test consumables for usage (1 mL tips, 10 uL tips, gloves, wipes, aluminum foil)
-   Intake collection tubes, preferably prior to the cutoff time, or during Amp
    -   Ideal would be to intake tubes as people return them, so as to address the uncollected tubes (tubes returned without the collection step completed)
    -   Ideally verify receipt of all expected collection tubes from students and staff
    -   Note any anomalies (e.g., uncollected tubes)
-   Double check water bath is up to temperature (at least 95°C) before starting to process samples

### Running Test 
-   Turn off air purifiers before beginning the test procedure. Keep the door closed.
-   Tie back hair (if applicable).
-   Run test:
    -   Longer Training Amp Run Form: [SOP-104-A\_1 Test Training - Run Form - Abrome.pdf](https://drive.google.com/file/d/1KoCXZzsHXKmg85mVdKIEbzHbFr20deDd/view?usp=sharing)
    -   Standard Amp Run Form: [SOP-103-A\_1 Amplification - Run Form - Abrome.pdf](https://drive.google.com/file/d/1REe5TKDHvmMoiBQUJHJOri5CR1VhO0qk/view?usp=sharing)
-   Rerun test on any positive and inconclusive sample(s) in triplicate using the same inactivated sample(s) kept in the refrigerator.
-   After running the test and any reruns, if any pools have returned positive or inconclusive results:
    -   Communicate ***referrals*** to participants in those pools:
        -   [Surveillance Program Results Communications Guidelines.pdf](https://drive.google.com/file/d/1p7oEPNAbIhwoYzjoO3FkHD6Oiw-Z1sxI/view?usp=sharing)
    -   Enact your internal protocols accordingly.

### Cleanup
-   Return cold blocks to the freezer.
-   Return pipettes, tip boxes, racks.
-   Check that all thawed inactivation solution bottles & vials are covered in foil.
-   Discard sample tubes from refrigerator (neg. in trash, pos. in bag in bottom freezer).
-   Turn off heaters.
-   Empty tip buckets and clean them with bleach and ethanol.

## Weekly Checklist - Abrome - v1.1
Last updated: 9-2-2022 by Gary Withey
Direct any questions to support@floodlamp.bio
-   Change water in water bath weekly.
    -   Preferable to use distilled water.
-   Update complete Inventory according to schedule as agreed with FloodLAMP staff.
-   Check Expiration dates of reagents.
-   Empty trash bins.
-   OPTIONALLY: Prepare reaction tubes for the week, and freeze.

## State Of Readiness Checklist - Abrome - v1.1
Last updated: 9-2-2022 by Gary Withey
Direct any questions to support@floodlamp.bio

The following should be in place at all times to ensure smooth operation of the lab:
-   Glove boxes BOTH in assay prep area AND amplification area (keep separate glove supplies).
-   Wipes present (one active, plus extra on supply shelf).
-   Empty Tip box filled with strip tubes (fill tip box + half source box).
-   Falcon Tubes Filled with strip tube caps (two full falcon tubes, + half source box).
-   1.5mL tubes closed and in cleaned, labeled cryobox (1 active box, Next box fully ready).
-   At least 5 blank Amp run forms, and at least 1 spare of both table forms (1X ISS & RM).
-   Pens and markers clean and in proper place.
    -   Pens tested and functional.
-   Spare tube of inactivation solution in freezer.
-   Freezer thermometer tested and functional.
-   Old non-significant samples clear from fridge.
-   Tip buckets empty.
