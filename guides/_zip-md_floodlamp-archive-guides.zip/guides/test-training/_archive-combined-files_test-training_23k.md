METADATA
last updated: 2026-04-15_180749
file_name: _archive-combined-files_test-training_23k.md
category: guides
subcategory: test-training
words: 15419
tokens: 22527


CONTENT

# _archive-combined-files_test-training_23k (5 files, 22,527 tokens)

# 1,106  _context-commentary_guides-test-training.md
METADATA
last updated: 2026-03-16 RT
file_name: _context-commentary_guides-test-training.md
category: guides
subcategory: test-training
gfile_url: https://docs.google.com/document/d/1S6h3QfU0HthWXZA25EH2U3mSBIDrGBNYfm5-2X3MyrU
words: 844
tokens: 1106


CONTENT

## Context
The `guides/test-training` subcategory contains materials from FloodLAMP's structured, video-based training program for its QuickColor COVID-19 test. The program was designed to enable new operators, including non-laboratory personnel such as firefighters, to learn the full testing workflow independently, including safety and contamination control through sample processing, amplification, and result logging.

The training system used Moodle Cloud as the learning management platform, with EdPuzzle integrated for interactive video content. An administrative guide `CRTT Moodle and EdPuzzle Guide` documented how to manage the platform, including user enrollment, course setup, content creation, activity completion settings, course copying, and learner reporting. The concept for the training program originated with FloodLAMP and was developed with a consulting firm specializing in educational curriculum development.

A series of 17 training videos were produced covering the complete testing workflow. The transcripts, preserved in the archive file `Test Training Video Transcripts`, address: introductory orientation; safety and PPE; contamination protocols for RNase, positive control, sample cross-contamination, and amplicon handling; each procedural step from 1X inactivation solution preparation through the inactivation step, reaction mix preparation, thawing, adding samples to reactions, intaking samples via the FloodLAMP app, resulting, and run logging. Scale-up procedures for larger batches including dispensing and water bath inactivation; and appendices on lab setup, pipette cleaning, and dispenser operation. The videos were narrated walkthroughs filmed in working lab environments, often with real-time interaction between the trainer and site personnel. The companion file `Test Training Video Index` provides a compact index to the 17 videos with durations and links to the main FloodLAMP webpage, downloadable video archive, Vimeo pages, and YouTube versions.

The `Certification Run Assessment v1.1` provided a formal pass/fail checklist for evaluating new operators by reviewing a recorded test run. The assessment covered PPE and safety compliance, contamination control practices and common infractions, documentation, and correct execution of each procedural step from inactivation through app-based tube handling, with an optional module for plate-scale testing. The assessment was designed for self-grading. The expectation was that the trainee would typically go through several iterations on running the test and reviewing the checklist, identifying their own mistakes. Then only when the trainee checked all the boxes in the latest assessment would FloodLAMP personnel review the records. This was set up to be scalable, being self-driven by the trainee and then only require about 30 minutes of FloodLAMP staff time for certification.

In practice, only a small number of operators completed the video-based training program. FloodLAMP's pilot sites generally preferred in-person training from experienced FloodLAMP testing staff, and the program saw limited adoption relative to the investment required to produce it. The training content itself, however, documents the full testing workflow in considerable procedural detail and provides a record of how a decentralized molecular test was taught to non-laboratory personnel.

These materials connect to the operational guides in the `guides/test-site` subcategory, which cover site setup and deployment logistics, and to the `pilots/pilot-sites` subcategory, which documents the individual pilot programs where the training was (or was not) used.

### Archive Files Not Converted to Markdown
`FloodLAMP Rapid Test Training - Storyboard.pdf`
`FloodLamp Rapid Test Training - Storyboard.pptx`
`QuickColor LAMP Trainee Tracking List SPREADSHEET.xlsx`

## Commentary
The video-based training program was overly ambitious for the scale at which we actually deployed FloodLAMP testing programs. For our last deployment at Abrome, our final pilot site, they chose to pay extra to have one of our experienced test technicians fly out to set up the lab and train their people in person rather than rely on the self-guided video curriculum. And this was a school with folks very experienced in educational programs. The handful of operators who did use the videos — notably at the Needham, Massachusetts site — completed the training successfully. But even this case had considerable hand-holding and in-person interaction (FloodLAMP staff set up the Needham lab and helped with the tester training).

Beyond the procedures themselves, the video transcripts capture the reasoning behind contamination controls, quality practices, and the practical tips that come from running the test repeatedly — things like why you treat the amplification area as radioactive, how to handle the positive control with one hand, or when to just replace materials rather than trying to track down a contamination source. As a record of how a decentralized, point-of-need molecular test was taught to non-laboratory personnel, including firefighters, this material may have reference value for those interested in designing similar programs.

AI completely changes how a program like this would be done today. In addition to or instead of pre-recorded videos and an LMS, a lab testing person would likely be best served by a multi-modal AI assistant that could use audio, display information on a screen, and answer questions in real time. Such a system could adapt to the operator's pace, respond to specific questions as they arise during a run, and scale both training and ongoing operational support without requiring experienced personnel to be physically present at each site. This is one area where the gap between what we built in 2021-2022 and what would be possible today is particularly striking.


# 1,773  CRTT Moodle and EdPuzzle Guide.md
METADATA
last updated: 2025-12-14 RT updated metadata after BA added image links
file_name: CRTT Moodle and EdPuzzle Guide.md
file_date: 2022-08-03
title: Covid Rapid Test Training (CRTT) Moodle and EdPuzzle Guide
category: guides
subcategory: test-training
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1GGv3YLSyIv0J8WTbt61FhI57Bh6VmEEjdLQfmKOL79A
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/guides/test-training/CRTT%20Moodle%20and%20EdPuzzle%20Guide.docx
pdf_gdrive_url: https://drive.google.com/file/d/1W0SeYZ0LcjI0YUo5DO8QK0RzNqwiHDpe
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/test-training/CRTT%20Moodle%20and%20EdPuzzle%20Guide.pdf
conversion_input_file_type: docx
conversion: pandoc
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 1773
words: 769
notes: 
summary_short: The "CRTT Moodle and EdPuzzle Guide" document outlines how to administer FloodLAMP’s v1 training program in Moodle Cloud and EdPuzzle, including user enrollment, course setup, content creation, activity completion settings, and reporting. It helps training staff maintain a consistent learner experience and troubleshoot common integration issues when building or copying courses.


CONTENT

***INTERNAL TITLE:*** CRTT: Moodle and EdPuzzle Guide
## Table of Contents
|  |  |
|---------|------|
| Purpose of this Guide | 1 |
| Moodle Account Login (Statistics, Billing, Tools) | 2 |
| Video Demo for Admin Login | 2 |
| EdPuzzle Teacher Login | 2 |
| Creating New Users in Moodle | 2 |
| Course Link to Covid Rapid Test Training (CRTT) | 3 |
| User Tours can be Confusing | 3 |
| Creating EdPuzzle Content | 3 |
| EdPuzzle Work Around for Learners | 3 |
| Learner Recordings via Google Forms | 4 |
| Self Assessment Options | 4 |
| • JLX Trying Out a Moodle Lesson | 4 |
| • JLX Showing Options for a Moodle Quiz | 4 |
| Activity Completion Settings | 4 |
| Copying Courses in Moodle | 5 |
| Reporting: Learner Viewing Stats | 5 |
| • Stats on EdPuzzle Videos | 5 |
| • Reporting for Quizzes, Lessons, etc. | 6 |
||

## Purpose of this Guide
The guide is meant to collect all the foundational and fundamental information that FloodLAMP needs to finish the content creation and learning experience development process of their v1 training program.

## Moodle Account Login (Statistics, Billing, Tools)
This is the **GENERIC** Moodle Cloud Login page where you are logging in as a System Admin for any Moodle Cloud:
[https://moodlecloud.com/app/en/login](https://moodlecloud.com/app/en/login)
To log in as ADMIN on this page use:
Username: Floodlamp
Password: ​​LAMPlamp11!!

This is the **FLOODLAMP** Moodle Cloud Login Page where you are logging in as any FLOODLAMP user.
[https://floodlamp.moodlecloud.com/](https://floodlamp.moodlecloud.com/)
To log in as ADMIN on this page use the following, but **NOTE!** this is the SAME USER:
Username: Floodlamp
Password: ​​LAMPlamp11!!

## Video Demo for Admin Login
[https://www.loom.com/share/7f146c8094574642ba369998cef7656b](https://www.loom.com/share/7f146c8094574642ba369998cef7656b)

## EdPuzzle Teacher Login
User: floodlamplab@gmail.com
Pass: FFrT2)#y7=33\_7i

## Creating New Users in Moodle
-   100% self-enrollment - just send any new user sign up Moodle URL:
-   [https://floodlamp.moodlecloud.com/login/signup.php](https://floodlamp.moodlecloud.com/login/signup.php)
-   Walkthrough here: [https://www.loom.com/share/567a9f46dfc948ca8aa70a187c6d2b5e](https://www.loom.com/share/567a9f46dfc948ca8aa70a187c6d2b5e)

## Course Link to Covid Rapid Test Training (CRTT)
[https://floodlamp.moodlecloud.com/course/view.php?id=5](https://floodlamp.moodlecloud.com/course/view.php?id=5)

## User Tours can be Confusing
We’ve disabled the User Tours. When User Tours are used for a large and complex Moodle they might be very useful but in a simple, single course with self-enrollment, the User Tours confused some test users.
How to: [https://moodle.org/mod/forum/discuss.php?d=380051](https://moodle.org/mod/forum/discuss.php?d=380051)
Admin page: [https://floodlamp.moodlecloud.com/admin/tool/usertours/configure.php](https://floodlamp.moodlecloud.com/admin/tool/usertours/configure.php)

## Creating EdPuzzle Content
[https://www.loom.com/share/81c4c711f8bb42cf92a509401d4acba5](https://www.loom.com/share/81c4c711f8bb42cf92a509401d4acba5)
**NOTE!** Once EdPuzzle Content has been LINKED via this integration, if you move the video on Edpuzzle side, rename it, or put it in a new folder the integration won’t be able to find it. It will show a page like this instead: *“This assignment is currently inactive. Ask your teacher if you have any questions.”*
_Screenshot showing the EdPuzzle "inactive assignment" error page that appears when a linked video has been moved, renamed, or placed in a new folder._

## EdPuzzle Work Around for Learners
JLX created directions right in the Moodle Course for the learners.
*It is very easy for them!* [https://floodlamp.moodlecloud.com/mod/page/view.php?id=101](https://floodlamp.moodlecloud.com/mod/page/view.php?id=101)

## Learner Recordings via Google Forms
[https://www.loom.com/share/fca35a9acf004bb9897f0d2579d3eb91](https://www.loom.com/share/fca35a9acf004bb9897f0d2579d3eb91)

## Self Assessment Options
Great forum post discussing Options:
[https://moodle.org/mod/forum/discuss.php?d=394827](https://moodle.org/mod/forum/discuss.php?d=394827)
*(TLDR; Quiz is likely the most efficient option)*

### JLX Trying Out a Moodle “Lesson”:
[https://www.loom.com/share/0bf0f4bb045248d581c98daa477e3b23](https://www.loom.com/share/0bf0f4bb045248d581c98daa477e3b23)

### JLX Showing Options for a Moodle “Quiz”:
[https://www.loom.com/share/a05617d516ee4fbf957b6037c36d4101](https://www.loom.com/share/a05617d516ee4fbf957b6037c36d4101)

## Activity Completion Settings
[How to Page](https://docs.moodle.org/310/en/Activity_completion_settings#:~:text=Default%20activity%20completion%20allows%20you,you%20can%20specify%20this%20here.)

1.  JLX set the current Course to a **Default** Activity Completion for **External Tools** (E.g. EdPuzzle) and **Pages.** This setting changes the default settings from Manual, meaning the student would have to Mark it Complete, to Automatic so that when they’ve viewed it, it shows as Done.
    a.  Be aware as you add any new content that the completion settings are not set to manual (Moodle will show this for manual: “Student can manually mark the activity as completed”)
    b.  Update new content to: “Show activity as complete when conditions are met” which will be followed by: “Student must view this activity to complete it”
2.  JLX already updated **all the current pages in the course** to these settings:
    a.  “Show activity as complete when conditions are met”
    b.  “Student must view this activity to complete it”

_Screenshot showing the Moodle activity completion settings configured to "Show activity as complete when conditions are met" with the condition "Student must view this activity to complete it."_

## Copying Courses in Moodle
[https://www.loom.com/share/f707fec983764f40a949abd3e588722d](https://www.loom.com/share/f707fec983764f40a949abd3e588722d)
**NOTE!** In addition to recreating EdPuzzle video links in the new course, you will ALSO have to create a NEW Google Form to keep the learner videos separated in different folders.

## Reporting: Learner Viewing Stats
### Stats on EdPuzzle Videos:
[https://www.loom.com/share/dec6ebac812a48858ce2dd0c36d80986](https://www.loom.com/share/dec6ebac812a48858ce2dd0c36d80986)

### Reporting for Quizzes, Lessons, etc.:


# 1,144  Certification Run Assessment v1.1.md
METADATA
last updated: 2025-12-15 RT updated metadata after BA fixed inconsistencies
file_name: Certification Run Assessment v1.1.md
file_date: 2022-02-12
title: Test Training - Certification Run Assessment v1.1
category: guides
subcategory: test-training
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1DhkmEUn15q0MnETtUb3tjp9VcBA5JtLnmHfB_PpRlFw
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/guides/test-training/Certification%20Run%20Assessment%20v1.1.docx
pdf_gdrive_url: https://drive.google.com/file/d/17ZqwLhedEXXnS4H-lNeOXWmD1MzrCnno
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/test-training/Certification%20Run%20Assessment%20v1.1.pdf
conversion_input_file_type: docx
conversion: pandoc
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 1144
words: 766
notes: 
summary_short: The "Certification Run Assessment v1.1" document is a pass/fail evaluation checklist for certifying test operators by reviewing a recorded run and logging any deviations with timestamps. It covers PPE/safety, contamination controls and infractions, prep and documentation, inactivation, reaction mix preparation, strip-tube amplification workflow, and app tube handling, with an optional module for plate-scale testing and electric dispenser use.


CONTENT

***INTERNAL TITLE:*** Certification Run Assessment v1.1
## SOP
-   Only approved personnel can perform this assessment
-   Watch video and check items
-   Note timestamp of any deviations
-   Determine PASS or FAIL
-   Log assessment with Form

## User Write In
Certification Run Assessment [Form Link](https://forms.gle/Qs7Jw8qU2ZXTmETD7) version 1.1
Video Link:
Assessor Name:
Date and Time:
PASS or FAIL

### Safety
-   Proper PPE (Gloves, Lab Coat, N-95 Mask, and Goggles / Face Shield)

### Contamination
-   Pen and sharpie labeled with green tape
-   Separation of Post-Amp area

### Contamination Infractions
-   PPE lapse/removal
-   Use green labeled pen/marker with bare hands and not putting it to be cleaned afterwards
-   Use unmarked pen/marker with clean gloves (without cleaning gloves after or changing gloves)
-   Bare hands on anything improper, except in desk area
-   Reuse pipette tip improperly
-   Touch pipette tip to anything and then not discard it
-   Touch anything dirty then go back to work (face, mask, uncleaned phone, uncleaned laptop)

### Prep
-   Turn on heaters, heat indicating light
-   Alcohol wipe the collection tubes

### Documentation
-   Read each item then check it off after completing it
-   Writing legible

### Inactivation
-   Write down on log sheet the amounts of saline and 100X prior to pipetting
-   Label 1XISS and logging the preparation correctly
-   Volumes correct for Saline and 100X IS
-   Mixing correct for 1XISS
-   Volume correct for 1XISS added to samples (1mL)
-   Sample tubes opened and closed properly
-   Vortex of samples correct
-   Timing correct for inactivation heating and cooling

### Reaction Mix Prep (strip8 tubes)
-   Write down entry on log sheet prior to starting prep
-   Calc volumes correctly for PGS and CLAMP based on number of reactions
-   CLAMP and PGS thawed properly, so not to get too warm
-   Spin down reagents and reaction mix
-   Correct volumes for CLAMP and PGS
-   Get PGS and CLAMP source tubes back in freezer quickly
-   Vortex and spin down reaction mix tube
-   Marking the top tube in strip with 1,2,3, etc
-   Correct volume of reaction mix in each pcr tube (23uL)
-   Pipetting at the bottom of tubes
-   No blowout while dispensing reaction mix
-   Volume check strip tubes
-   Keep reactions covered strip tubes with rack lid to prevent dust

### Amp Run (strip8 tubes)
-   Get Cold PCR Block out ~10min before adding tubes
-   Reaction mix tubes ready (thawed but not too warm (<10 min)
-   Strip 8 tubes labeled on top tube of each strip
-   Tips setup properly to align with strips8 tubes to be used
-   Add negative control 1st
-   Using a lookup rack to keep continuity of sample order
-   Visually checking the 2uL in the tip from each inactivated sample
-   Amp pipetting technique correct - pipet up and down 5 times, blowout in liquid, tip touch
-   Well position correct and correspondence between tip, strip tube# and, where sample tube is put in lookup rack
-   Transfer strip to regular PCR block (so they aren’t cold going to Amp)
-   Only touching positive control (TPC) with one hand
-   Glove change after putting the positive control (TPC) back in freezer and before caps
-   Not touching the top of strip8 tubes or inside of a strip8 cap
-   Completely sealed strip tubes - check at eye level
-   Change gloves again after touching loading tubes/plate onto amp heater
-   Set main timer for 25min
-   Set phone timer for 24min
-   Put sample tubes in fridge during amp heating
-   Wait at least 1 minute after pulling off the amp heater
-   Take photo in lightbox
-   For photo apply crop and vivid filter
-   Logging amp run sheet properly with google form entry

### App
-   Intake tubes correctly
-   Process and Result tubes correctly

**ONLY COMPLETE THIS LAST SECTION IF TRAINING FOR PLATE SCALE TESTING**

### Dispenser Demonstration
-   Unpack an electric dispenser
-   Properly prime the dispenser
-   Dispense 1mL into tube without touching the tip

### Amp Run (Abbreviated Plate)
-   Prepare reaction Mix following all previous guidelines
-   Pipette Reaction Mix into a reservoir
-   Use Multichannel Pipette to fill Column 1
-   Fully seal plate with foil seal
-   Pierce B1 to add negative control
-   Pierce C1 - H1 to add samples
-   Pierce A1 to add TPC, following all TPC guidelines
-   Glove change
-   Use a second foil seal on top of the first
-   Tight seal, no delamination
-   Put on Amp heater
-   Glove change


# 829  Test Training Video Index.md
METADATA
last updated: 2026-03-26 RT
file_name: Test Training Video Index.md
file_date: 2021-08-29
title: FloodLAMP Test Training Video Index
category: guides
subcategory: test-training
tags: 
source_file_type: md
xfile_type: NA
gfile_url: 
xfile_github_download_url: NA
pdf_gdrive_url: NA
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/test-training/Test%20Training%20Video%20Index.pdf
conversion_input_file_type: NA
conversion: none
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 829
words: 237
notes: 
summary_short: Index of the 17 FloodLAMP test training videos with main links, durations, and Vimeo and YouTube URLs.


CONTENT

## Main Links
[FloodLAMP Test Training Webpage (2023)](https://www.floodlamp.bio/test-training)
[Amazon S3 zip download (3.5GB)- FloodLAMP Test Training Videos - 17 mp4 files (1080p).zip](https://fofpublic.s3.us-west-2.amazonaws.com/floodlamp-archive/FloodLAMP+Test+Training+Videos+-+17+mp4+files+(1080p).zip)

## FloodLAMP Training Video Transcript 01 - Intro (0:54)
https://vimeo.com/668273372
https://youtu.be/VY0bJnu4wEk


## FloodLAMP Training Video Transcript 02 - Safety and Contamination (21:02)
https://vimeo.com/897312084
https://youtu.be/Ce6V4WkpjHc


## FloodLAMP Training Video Transcript 03 - 1X Inactivation Saline Solution Prep (8:31)
https://vimeo.com/668089789
https://youtu.be/a8BkXnBRREg


## FloodLAMP Training Video Transcript 04 - Inactivation Reaction (6:25)
https://vimeo.com/668089545
https://youtu.be/eajXOyGHg84


## FloodLAMP Training Video Transcript 05 - Reaction Mix Prep (15:35)
https://vimeo.com/668261400
https://youtu.be/1AQWefZTQpA


## FloodLAMP Training Video Transcript 06 - Thawing Reactions (2:31)
https://vimeo.com/668226340
https://youtu.be/1DzDbtVA4Ls


## FloodLAMP Training Video Transcript 07 - Adding Samples to Reaction (10:01)
https://vimeo.com/668227040
https://youtu.be/JRnMAsdfNuY


## FloodLAMP Training Video Transcript 08 - Intaking Samples (3:46)
https://vimeo.com/668259122
https://youtu.be/b_OiM2GeaOA


## FloodLAMP Training Video Transcript 09 - Resulting (2:02)
https://vimeo.com/668255645
https://youtu.be/548NHE7a_4E


## FloodLAMP Training Video Transcript 10 - Logging Run (3:01)
https://vimeo.com/668260417
https://youtu.be/Nzq31sB0GLQ


## FloodLAMP Training Video Transcript 11 - Large Scale Clean and Dispense (20:00)
https://vimeo.com/668274931
https://youtu.be/-PhnjCvjop0


## FloodLAMP Training Video Transcript 12 - Large Scale Inactivation (5:33)
https://vimeo.com/668290807
https://youtu.be/y1_2WmBfB_Y


## FloodLAMP Training Video Transcript 13 - Reaction Plate Prep (2:54)
https://vimeo.com/668272376
https://youtu.be/lAVEpkRcFXs


## FloodLAMP Training Video Transcript 14 - Plate Processing (4:33)
https://vimeo.com/897312968
https://youtu.be/suLdbWCPaL0


## FloodLAMP Training Video Transcript 15 - (Appendix) Setup (3:44)
https://vimeo.com/668087884
https://youtu.be/e_HMw9dZPUE


## FloodLAMP Training Video Transcript 16 - (Appendix) Pipette Cleaning (4:13)
https://vimeo.com/668088713
https://youtu.be/nPgFKjwqN4s


## FloodLAMP Training Video Transcript 17 - (Appendix) Dispensers (3:40)
https://vimeo.com/668273690
https://youtu.be/UuUYbQgqaBk


# 16,043  Test Training Video Transcripts.md
METADATA
last updated: 2025-12-17 RT from data/floodlamp/test-training-early/test-training_new17_md/training_new17_md_combined.md
file_name: Test Training Video Transcripts.md
file_date: 2021-08-29
title: FloodLAMP Test Training Video Transcripts
category: guides
subcategory: test-training
tags: 
source_file_type: audio
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1t3yOYBBcFmnzhJSnOp4ZEvxHJlNKTiZf
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/guides/test-training/Test%20Training%20Video%20Transcripts.docx
pdf_gdrive_url: https://drive.google.com/file/d/1o2YbfHTBGRIiA6UpjDapjHwx9S60jIa6
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/guides/test-training/Test%20Training%20Video%20Transcripts.pdf
conversion_input_file_type: md
conversion: none
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 16043
words: 12311
notes: 
summary_short: The "Test Training Video Transcripts" document compiles the narrated walkthroughs of 17 videos for the QuickColor testing workflow, including safety/PPE, contamination control (RNAse, positive control, sample cross-contamination, and amplicon “post-amp” handling), and the end-to-end run process from 1X inactivation saline prep through resulting, app intake, and run logging. The transcripts also cover scaled-up procedures (clean/dispense, large-batch inactivation) and plate-based processing, plus setup and cleaning appendices for workspaces, pipettes, and dispensers. This material helped sites train new operators and standardize repeatable, contamination-resistant runs with consistent documentation.


CONTENT

## FloodLAMP Training Video Transcript 01 - Intro

Test Trainer  [0:00](https://vimeo.com/668273372/14ec57a5d7?ts=0)
All right. Hi there. I'm Randy True with FloodLAMP Biotechnologies, and this is the FloodLAMP testing training program for our QuickColor test. This is a visually read colorimetric LAMP test that can take as little as about 15 minutes of hands-on time to run, and has high sensitivity, molecular quality. This is a great screening test and we're going to be running it here in this setup and the training program is going to cover all the mechanics and the tips and tricks for doing all the steps. We're going to be going through both the steps as well as the run sheets and the way that we log these runs, which are a key part of our quality system. So stay tuned. This is going to be a fun little series here. Thanks.


## FloodLAMP Training Video Transcript 02 - Safety and Contamination

Randy True  [0:00](https://vimeo.com/897312084/c5c9beae9b?ts=0)
So the safety part is about protecting y'all. I do need to give the disclaimers that this is not formal lab or biosafety training and that the site managers and personnel and volunteers, you are all ultimately responsible for maintaining appropriate training and certifications and and also with compliance with local, state and federal regulations. We're providing this information on a best effort basis during this public health emergency. And we're trying to highlight the key things, you know, that we pay attention to on a safety basis. So it's not it's not by any means complete. I included some links here. Y'all are being being an EMS here, you're probably pretty familiar with safety protocols medical protocols. So, basics, basic PPE is involved, mask gloves, lab coats. I usually prefer a face shield to goggles because mine fog up. We do have these listed in our protocol as a checkbox. The key is to have a face shield to stuff in the bunker. Pardon?

Speaker 2  [1:09](https://vimeo.com/897312084/c5c9beae9b?ts=69000)
Sorry, Mandy. We've got goggles in the bunker. As a checkbox. The key... Pardon? Sorry, I didn't...

Speaker 0  [1:12](https://vimeo.com/897312084/c5c9beae9b?ts=72000)
We've got goggles moved up here.

Speaker 2  [1:22](https://vimeo.com/897312084/c5c9beae9b?ts=82000)
And then Randy for masks, is this, I'm assuming N95 to work with this stuff?

Randy True  [1:33](https://vimeo.com/897312084/c5c9beae9b?ts=93000)
We do sometimes use medical masks as well. I prefer N95s especially when I'm at our lab because there are a bunch of other people. From a, Yeah, from an infection control point, the N95s are preferred if you have them. From a contamination, when we get the contamination side, which is about protecting the test, a medical mask is fine. So in terms of sample handling, it's better if the incoming sample tubes are actually in biohazard bags, or if you are doing collection, if you're having all 20 people come to the same place, you could put them in a rack and just put that in a closed bin and save a lot of plastic. Again, some of that is your call in terms of your infection control procedure. The sample tubes, we do call for them to be wiped with alcohol after debagging. So the step with the highest infection control risk is when you open the tubes with the dry swabs for adding the 1X inactivation saline solution. So we prefer to do this in a well ventilated place. The current deployments in Florida are in medical office rooms, which just have windows. And so they aren't doing it like this, where you have an open garage. You know, labs typically have biosafety cabinets or chem hoods. Those are good places to do it. So there's a sort of a few options here, but I think it is important to highlight that this is the step to pay the most attention to is this very first step of opening the tube to add the inactivation solution. After that, it gets vortexed and heated, and then that it's a chemical plus heat inactivation, which denatures all the proteins and lysis the virus. And so it's not even a positive sample would not be infectious after that step. So in terms of chemical safety, I provided a link here to the SDSs involved with our test. And the two main chemicals are TCEP and EDTA, which are the two components of the main components of the inactivation solution. This inactivation solution is at two, You work with it at two concentrations, the 100x, which is what you use to make the inactivation saline solution, which is what you add to the samples. So give extra caution when you handle the 100x inactivation solution. So we provided an eye wash station. And so you should know where that is and and have a sink, but and know where the sink is as well. All this is probably old hat to y'all. Okay, so let's jump into something probably that's not as much old hat to y'all, but it is to Katrina, which is contamination from a molecular biology perspective. So we're going to focus on four types of contamination And contamination control really is the name of the game here with this, this RNA assay. Actually, a high school teacher that we collaborated with very early on, she had never got an RNA assay to work in her lab until we provided her kits last fall. And she tried with her students and she said, didn't work. And I asked her, well, did you use everything that we gave you? Did you use anything from your lab? And she said, oh, we use the water. I said, just only use what we gave you. She did, and then it worked first time and it worked for her students. So what I'm gonna try to do here is kind of convey the kind of the mindset to get into in the key highlights. And it's worth just pausing for a second. And I'd like to click on this link if it's gonna work here. This summarizes the important aspects of RNAs contamination quicker than I can. And then I think helps, will help us kind of make a point.

NEB Narrator  [5:59](https://vimeo.com/897312084/c5c9beae9b?ts=359000)
Preventing RNA degradation is trickier than preventing DNA degradation. RNAses are present in all cell types from prokaryotes to eukaryotes and can sometimes survive prolonged boiling or auto-claving. So what are the major sources of RNAs contamination in the lab? Aqueous solutions and reagents, environmental exposure as RNAs are in the air, on both surfaces and in dust, and from human skin and hair. How can you prevent this contamination? Always wear gloves in the lab and change them often, especially after contact with skin, hair, doorknobs, keyboards, or animals. Use RNAs-free solutions and RNAs-free certified disposable plasticware and filter tips. Maintain a separate area for RNA work and carefully clean the surfaces. Decontaminate glassware by baking at 180 degrees Celsius or higher for several hours or by soaking in freshly prepared 0.1% DEPC water or ethanol for one hour, followed by draining and autocleaning. Decontaminate polycarbonate or polystyrene materials such as electrophoresis tanks by soaking in 3% hydrogen peroxide for 10 minutes. DEPC treatment of solutions is accomplished by adding one ml of any remaining amino acid residue.

Randy True  [7:16](https://vimeo.com/897312084/c5c9beae9b?ts=436000)
I'm intentionally skipping through this because they start talking about a bunch of stuff that's common to normal molecular biology labs. But this gets to a real key point, which is this lab that we have set up next door to y'all is really different from a normal lab because we're only doing one thing there, this COVID test. And this COVID test is quite simple compared to most tests that are done in a clinical lab or certainly most protocols that are done in a molecular biology research lab. So you might be wondering, oh, like, why are we setting up a COVID lab in a molecular RNA assay testing lab in a firehouse. Doesn't that take a real lab? And in some sense, yes, what you're going to have is actually a real lab. But in another sense, it's so pared down and the paring down is what enables us to be successful. I set up a lab in my garage and I did a did a FaceTime call with this Stanford professor that former Stanford professor who is collaborating with another nonprofit and he said, He said, you know, I said, what do you think of the lab I set up? And he's like, he's like, looks great. I was like, do you think I'm going to have problems, contamination, cleanliness? He's like, that's better than almost any lab at a, at a university because it's yours. You have it controlled. It's only for this and you'll be in great shape. And we have been, you know. So the key is to understand kind of how to avoid these several types of contamination. So let's just go through it real fast again. They did it on the video, but RNAs is this enzyme that degrades RNA, which is way more fragile than DNA, and it's everywhere. Getting an RNA assay to work is way harder than getting a DNA assay to work because again this stuff is everywhere and if you contaminate your tube your bag of tubes or any solution or something it can give you unreliable even sometimes intermittently bad results and it can be very frustrating to track down. The place we care about this RNAs contamination is primarily in this amplification reaction. And the reason is because the inactivation reaction, you're putting a nose swab with tons of RNAs in it into that reaction. And that's part of the purpose of it is to degrade RNAs. So we really focus on the second step of this test. How do you know, you know, how do we know if you have this problem? Well, the positive controls won't work. And so another key thing that makes us able to do this test in this kind of environment with newly trained firefighters is the controls, when you use them properly and when you design the test to use the controls, give you a great indication of when the test is working and when it's not. So what are we going to do to avoid the RNAs is, number one, is access control. And I sort of already saw some of this going on. I saw Peter in the lab like leaning over the amp table and I was like, oh no, don't touch anything with your bare hands. So that's the first thing.

Speaker 3  [10:39](https://vimeo.com/897312084/c5c9beae9b?ts=639000)
I'll come back later, Deacon.

Randy True  [10:42](https://vimeo.com/897312084/c5c9beae9b?ts=642000)
That's the first thing is that, you know, I've seen this problem too when we were giving tours, three, four fire chiefs and everybody were coming in and then it's like, oh no, like you don't want to, they can just, if they don't know, they can just touch something and cause a real annoying problem. So I would recommend putting a lock on the door, putting the sign up and just controlling access to it. I mean, do definitely feel free to give tours and stuff, but just make sure people don't touch anything. There is a station, a desk station where you can touch your computer or other stuff without gloves, but it's a certain area. All the rest of the area, you just think you've got to have gloves on. And even in addition to gloves, you really want a lab coat so that you don't even get your forearm touching anything. And it's just better to be extra careful about this and just to get in the mindset where skin doesn't touch anything that's clean in the stations. So I encourage a process to do a good cleaning up front and then keep things clean. Danny Chavez said he cleans his lab every day, and I think that's probably recommended from good lab practice. I actually don't for our lab here because it takes time and I prefer to be extra careful and keep the key things in bins that I keep on a shelf. So you can also use foil to put over things to keep them clean, keep dust off. You want to be extra careful with the reaction plastics and Katrina will help kind of point out what those are. You want to be wary of cross contamination. By cross contamination, I mean you touch a pen with your bare hands, and now you get finger grease on the pen. And then you're wearing gloves, you think you're okay, but then you go and touch something that's greasy, then you can pick up some and transfer. Now, you could drive yourself crazy thinking, well, how many degrees of cross contamination do I got to worry about? Worry about the first degree and just try to get some basic procedures and kind of mindset in place. And then you still got to do the work. You can't drive yourself crazy. Another key thing that we do to deal with RNAs contamination is we just we stage things so that we can just replace them and you can just get in you can you can get a new bottle of saline you can get new bag of tubes and you want to avoid the what I call the matlock trap which is like trying to sleuth and figure out where where the problems are coming from. It's better just to replace things, I could tell you some, I learned this one the hard way. Okay, so That's RNAs contamination. Do you guys have any questions about that?

Speaker 2  [13:51](https://vimeo.com/897312084/c5c9beae9b?ts=831000)
Nope. No, but I'm sure Randy's work, firefighters would probably look a little intimidated by all this stuff. This is not normally our area. Yeah. But I think the takeaway is, yeah, we're touching stuff and make sure we're clean.

Speaker 0  [14:09](https://vimeo.com/897312084/c5c9beae9b?ts=849000)
Yep. Would, would gowns work as well as lab coats?

Randy True  [14:15](https://vimeo.com/897312084/c5c9beae9b?ts=855000)
Yeah, gowns will work fine. Just anything that's kind of covering your skin. I actually jotted down on my follow-up that we should have included a couple of disposable lab coats just to account for multiple people in there. We did provide one kind of regular lab coat. But long sleeve shirt is also better than nothing, particularly if it's clean. Okay, I'll try to hurry quickly through the other kinds of contamination and some of these are best kind of learned along with the protocol. Particularly problematic one is positive control contamination. This is what screwed the CDC on the rollout of their kit and really put our whole country behind the eight ball at the beginning of this pandemic. This manifests as your negative controls aren't negative, they're showing up positive results or in the middle in conclusive results. So it's pretty obvious you have this. It can be hard to rectify because, especially if it's in the manufactured materials. So part of this is on our side. But the part that you worry about on your side is to follow the protocol and there's some special handling steps and procedures when you touch and deal with the positive control tube. You have to use the positive control tube with every heat cycle, every run, because it confirms that the reagents are still good. It's a critical part of the overall quality and assurance. So you do have to touch it and use it for every run. So I have some sort of recommendations in terms of just using one hand. We have a key glove change. And then we also just keep the positive controls in bags in the bottom of the freezer. And these procedures have worked really well for us for a long time now and haven't had any problems. So I think we'll be good to follow those. Okay, so sample cross contamination. By this we mean transferring material from one sample tube to another. So that's like, for example, if you open a tube and there's a drop on the tube and then you get that on your glove and then you open another tube and get that on the other tube on the threads or something in a way that can get inside. You know, if you have this problem, well, actually you don't know that you have this problem if all your tubes are negative, you could be cross contaminating all over the place. And you would never know if they're all negative, But if you do have a positive, you'll see other neighbor tubes get contaminated or come up positive. So a telltale sign of that would be neighbor positives and more than one positive in a batch. Again, following the protocol, being careful when you handle the sample tubes and the lids. If you do get a drop, wipe it up and clean it. And I suggest noting if that happens on a run sheet so that if you do get some positives and you can figure it out, you can look at it more carefully. Okay, so the last contamination I'm going to talk about is amplicon. And this one is really bad. So amplicons are the product of the DNA of the amplification. And they are DNA. They're not actually RNA. Sometimes they're called products. So I showed here the diagram for PCR and I showed the diagram for LAMP. LAMP is an alternative amplification to PCR and it is like biochemistry wizardry. It uses six primers instead of two and it forms these loop structures. And this happens all at a single temperature, whereas for the PCR, you ramp it up and down. And so LAMP produces 10 times as much DNA per volume as PCR in one third the amount of time and at a single temperature. So it's like a nuclear explosion of DNA production, whereas PCR is like a very controlled sort of firecrackers kind of going off. So the key here is that with LAMP, we wanna even be extra careful with amplicon contamination. And the reason I say if you get this, it's death, is because it can contaminate the entire lab and really require you to move the lab and start from scratch. I've even heard horror stories about me to do that in a new building. A lot of times this is because you open the tubes in order to do some other analysis. So I hadn't, you know, I'd never heard of LAMP before last summer. We've run PCR in the lab that I was in charge of at my former company, so totally familiar with PCR, never heard a lamp. And when I reached out to the team that developed the tests that we use, the first thing that the grad student who ran the test told me was never open the tubes. So that's the key thing. I don't see any reason why y'all would. We never have. And we've never had this amplicon contamination, but since it's so bad, I feel like I have to highlight it. And the way we deal with this is that we treat the tubes, the amplified tubes, the heater, the light box, everything in that area as if it's radioactive. And this area is like a black hole, anything that goes into it doesn't come out. So the pens that go in there, the post-it notes, you just leave them over there. And then whenever you touch them, the tubes or the heater, whatever, you again treat it like your gloves are radioactive and you take them off and you throw them away. And so it may feel wasteful, but don't worry about wasting gloves. It's, you will waste way more if you ever get any kind of contamination. It's just a part of the process. Semiconductor industry wastes even more gloves. Glove change is critical. Again, if you follow these rules, I think we won't have a problem. There is actual extra protection from this with a thermo-lay-bio-nucleotide, big words, it's some chemistry protection that helps where these amplicons, if they carry over, they get degraded in the first part of the temperature cycle. So don't worry about that if it doesn't make sense. It's just be aware. The main thing is to be aware of this AMP area and the fact that we just treat it like it's super radioactive. Not radioactive, not because we're worried about it hurting us, but just for this contamination perspective. OK, you all have any questions on the contamination?


## FloodLAMP Training Video Transcript 03 - 1X Inactivation Saline Solution Prep

Test Trainer  [0:00](https://vimeo.com/668089789/24a9d1595b?ts=0)
All right, so we are on step 2 here, which is make the inactivation saline solution, the 1XISS. And we got some amounts here. We'll probably just change this to five. But this is for sort of a small batch, medium batch, and a large batch. I got everything set up over here in my drawers, so it's all handy and easy to access. I highly recommend having some standard sizes. If you're doing these really small runs, five. Actually, I did 5.05 a while ago. Even if you just do five, you'll have enough. And I want to walk through using our log sheets. So what that looks like here is this form. This would be a new one. And so you would write down the ID. In this case it's just a number. This one is not underscore 210427 dash 1214. I actually have another sheet with this one but I'm sort of showing you filling this out. There's a freeze expiration and a thaw expiration. You read that off of the tube. This would be 0422 and this one is it's 0222. This one is 222. So fill out your name here. One, 17. There we go. So the key here is every time you make the 1XISS, you fill out a line. It is 1pm. And we give this a designation 0117-1. Then we put the saline dash one then we put the saline information this one is a SAO underscore 21 10 zero seven dash five mil these are some different names. Oh, I forgot a zero, 10, 07. And this head expiration of 10, 22. So the saline here is 5.05, And then the 100x will be 50.5. So get set up. Oh, look, it's already set at 50.5. Done this recently. So the key here is to write down the amounts first. And I'm going to be using, overall, the run app short form. But I'm going to show you the long form as well. I like to keep the forms underneath. Okay, so here we go. I can start filling this out for the day. Okay, heaters are on and I'm working on making that. Got that. We are in a special setup here, so I'm not able to wear my goggles. So we wipe the tubes. So we're going to come back to this guy. So now this is the short version of the run sheet. I recommend when you start, You start with the long one. This one corresponds to the mini system. We have one for the standard system. And this one has, this is what you're going to be using to practice all of the items that are checked on our certification. So you want your pen labeled with green tape, separation of the post-amp area. Got that. Heaters are on. And now this is an important part. The heater indicator light is lit. If you just turn this on, it's easy to think it's hot, and then it's not, and you go to use it. So all the heaters have a heating indicator light, so know what that is. It looks like little flames coming up there. So you notice these are very similar, except this just has some extra steps. This fits on one page. This is three pages. So it also has the common infractions here, which you'll want to watch out for. So I'm going to keep checking this as we go, Though the one I'm going to fill out mainly is this one for a run. This is what you'll use once you get certified or once you get comfortable. OK, so back to making the 1X. Got our saline. Got our samples here. Let's get those out of the way. Let's get the clipboard out of the way. Actually for the clipboard, what's important is to follow the SOP for making the saline. So it says to vortex the 100X for 10 seconds. Okay and then we're going to add the 100th volume, our 50.5 here. And then we're going to vortex again. We're also going to make sure we label this tube. Well, we'll do it after we go here. So I like to open the tube that's going in first. Oops, do this face up. It's out of the way. It doesn't look like it got all the way down. There you go, 50.5. So you notice here you always want to check the tip, see the liquid fully in the tip, no big air bubbles, no problems. Here you want to be careful because we didn't spin this guy down. So now we vortex this guy. It says for bigger tubes to invert it. Keep vortexing it. There we go. So now I'd like to do this step before the samples come in the door as a part of the morning prep. And then right on the tube. For good hygiene there, put this info here. Okay, check off that you did it. Oh, I'm sorry, we haven't done this step yet. This is adding it. We did the prep. So we'll come back to this in just a sec. OK. We are done with making the 1X.


## FloodLAMP Training Video Transcript 04 - Inactivation Reaction

Test Trainer  [0:00](https://vimeo.com/668089545/f7ec03055b?ts=0)
So we're going to be intaking the sample tubes. I can show you our set of instructions we got here. I got handy printouts. Step 1 of 8, intake sample tubes. It says clean tubes, spray wipe with ethanol. And you can intake at the app at this point but we like to wait to save time so we are going to wait till it's on the amp heating and the reason is if if somebody didn't collect any app or for whatever reason there was a problem we've run it anyway and we try to sort it out later. So here's what we got. So we got a clean surface here. It happens to be a nice metal surface. So we're just going to give these guys quick spray. Sometimes we do this in a bin. Just a few of them we have here. Just then get them nice and dry. Just try to get the fingerprints off. Okay, that's it.

Test Trainer  [1:15](https://vimeo.com/668154271/8db8846029?ts=65000)
So we're on step 3 here, which is add the 1X inactivation saline solution to the sample tubes. It's one mil. So we're going to use our little pipette or pull it to the front, set it at a thousand. This guy's out of the way. We're going to do it one sample tube at a time. If you notice in our short run sheet, it's just one line here. In our longer run sheet here, we did this guy. Got the extra steps described here. So we did these. The volumes are correct. We did 50 for five mils. The way you can think about this is this is 5,000 divided by 100 makes 50 microliters. The mixing was correct. And now we're on to that step. So these are all the things we check. Okay. So this is pretty straightforward. Just going to pop this guy open. We're going to do these, get this guy open. Now this is the step where you're opening the dry sample tubes here. So you don't want to drop the tubes out. You don't want to splash the solution. I like to spin the tubes. I sort of bend these tubes. You may be using a different kind of tube. You may be using a bigger 5-mil tube, and you may be using a dispenser as well for the larger volumes. We're demonstrating the small amount here. And number five. And one thing is, notice we still have a little bit left. That's why we add the .05. You don't strictly need that though because you add 50 microliters. So five and the 50 from the 100X gives you an end of 5.05. But we're going to use this for our negative control. Okay so these guys are all good so we're gonna vortex these. You can do them all in a rack. Just got to be careful not to drop them. It's a little tricky. Okay. Now, we're going to put it in the heater. Turn on the timer. Now we wait.

Test Trainer  [5:42](https://vimeo.com/668226123/14d1448aed?ts=342000)
Okay, it's almost done. Okay. There we go. So pull these guys off. There we go. Got to give it at least five minutes to cool. And per the protocol, the longer protocol, It says make sure to put in the fridge before the 30 minute mark. That would be 30 minutes from when you pull them off. So you don't want to leave them sitting at room temp for more than that. Okay, that's it.


## FloodLAMP Training Video Transcript 05 - Reaction Mix Prep

Test Trainer  [0:00](https://vimeo.com/668261400/fa2b78d5e7?ts=0)
Okay, so this video is going to be to show making the reaction mix and we're going to make enough for 48 reactions. That's how the PGS comes packaged for 48. So you're going to use this whole tube And then this is a new master mix, so we're going to end up using half of this guy. There we go. So these have been thawing about 10 minutes. So if you plan ahead, then you have to hold them less to get them to finish thawing and you sort of want to see. This guy's not quite thawed. That guy not either, but that's okay because I need a few minutes to just get sorted on my strips. So I'm gonna put these into strip tubes. You could also do a plate. I'll show a little bit about that at the end. So I'm going to get out my way, I like to keep the strip tubes in this kind of container. It's just easier to get out. And I'm not going to be marking them. I mark them when we get them out and use them. It just saves time and sometimes you cut them in half. Okay. Trying to Make sure you don't touch the inside as you do this. I don't touch the ends that are sticking out. As soon as you get them done, close that. So, here's our sign for making the reaction mix. It has the set up for eight and for 48. If you end up wanting to do a whole plate 96, you just do 2 48s and add them together. If we look over here at the long run form, and this says mini system but it would be the same, it says to start by writing down the entry on the log sheet prior to starting the prep. So we'll go ahead and do that and show you what that looks like. So here's our reaction mix SOP. I should say, as you can see, we have another entry already. Now this corresponds to this lot number for the master mix, and it's the same lot number. So we don't have to do anything new here. If you end up using all of one line, you switch to another one, then you can retire this form and get a new one. So we're going to just fill this out. 11722 3pm. It's going to be RM_0117-1. And then this is going to be a new master mix ID. So we'll call this one underscore 0117. We do like to identify these guys uniquely. So you'll want a little towel to wipe these guys off so they're not so wet. And to this one, we're going to use up. This one we can write 01 17 there we go So now we know which one we're talking about. And it helps, too, to see that on the cap. It shows that we have used it. So the PGS here, yours will probably have a lot and an expiration. This one's a little bit older, so it doesn't have that. But it says PGS underscore 210604. So same thing, and it has that same expression. And then this is the key part. We're just going to write down what we're doing here. If I'm doing the whole thing. So we have two entries here, kind of just spelled out for you, either 8 reactions or 48. If you're doing, say, three strips instead of just one strip of eight, then you just multiply these numbers by three. If you're doing a whole plate, you just do two PGS tubes. *And that's because this is set up so that the amount is is correct for adding 655 straight to this tube you don't need another intermediate tube.* If you were doing a strip of eight or some intermediate amount you would want to get one of your 1.5 mil tubes and use that and go from both of these into this tube as your as your reaction mix too. Okay so the key here is 655 that's the number in the set. It's going to be the big pipette, P1000. Go down to 655, get ready. 655, there we go. Okay, we've got to get one more thing to be ready. Trough. Actually, we've got a few more things to get ready, but this is one important one. Trough out. Always make sure to have your foil handy. Piece of foil. Pull this guy out. Now the thing that we need is our multi-channel pipette over here. So we're going to have this guy ready for when we're ready to go. Okay, so let's check our reaction mixes. Oh, yep, See it's liquid now. And you want to look at this one to see if there's any ice. Doesn't look like there's any more ice. So you vortex you guys together for about 10 seconds. Okay. Then you pull out the ballast tube here. Put these in opposite. Give this a quick spin. That's all you need. You're just trying to get it from the top. There we go. Okay. And you do want to move reasonably quickly through this so that these guys aren't sitting for a long time. And in fact, you know, I would recommend, especially the first time you do this, to go ahead and get a cold block out. In fact, you know what, I'm gonna just go ahead and do this because I'm gonna freeze these guys afterwards. I'm not gonna use any of them. So normally you want to get your cold block out about 10 minutes before so that it's not freezing. Actually my freezer is set a little bit warmer than standard, so it may not freeze anyway, but I'm going to go ahead and put these in. I'm going to keep this rack handy because this is what I'm going to put them in afterwards. Okay, this guy's here. Keep that here. And then you do want your lid handy too. This lid's a little bit bigger, so it fits nicely. Okay, I think we are ready to go now. So we need to add the 655 to this guy. Open this up. So this is the master mix here. This is new, it's tight. It's the same thing with all these screw cap lids. You want to do that little bend so that they don't flick. You want to be careful here not to stick the pipette or too far down in there when you start because otherwise you'll overflow the tube. Make sure you get the nice full tip. Beautiful color. There you go. Tip touch on the side. There we go. I'm just going to go ahead and get this guy back in the freezer so I don't have to worry about it degrading. Okay give this guy a little pulse and then we're gonna stick him in here so we get all liquid down. You don't want to run short. Okay. There we go. Now we're just going to use this same setting to get it into the reservoir. Oh, don't need that open yet. Okay, So here you want to try to be careful to not create too many bubbles. So I'm just going to go pipette in like that. Oh, so you got a bubble there. Don't worry too much if you do. Okay, there you go. Not too bad with the bubbles. This guy just goes in the trash. Now your multi-channel should just live at 23. That's how much you do for each one. So, there you go. Okay, see, we popped those bubbles. I like to balance this one. I go all the way to the bottom and no blowout. Just be slow and steady. Just be slow and steady. Number three. Number four. Number five. Last one. The last one can be the trickiest because you want to make sure all your tips are full. So if your table's tilted, you can have a problem. If you've created too many bubbles, you can have a problem. And if you do have that problem, What I would recommend you do is go ahead and just get two tips or four tips or whatever you need in order to get you know You need to get some more you can get some more like that See you get a few more reactions if we needed. There's a little bit of overage here. So this is a nice little trick to know. I'll just put this back in here. Okay, so now all we gotta do is cap our tubes and get them in the freezer. 48 reactions worth. So in terms of capping these guys, again you want to make sure to not touch the inside of the caps. So see I'm only grabbing it by the edge there. What I like to do is just kind of press it on like that. I'm gonna come back and press them all down. I think sometimes I move them before I put the caps on because you press hard into the... See how they do on this rack. They can get stuck on these PCR racks. If they do, you just push from below. That's how you kind of get them unstuck. OK. Just avoid touching the other strips. OK. So Now I'm going to come back through here. All nice and clicked flat. There we go. If you don't get this part right, they will turn slightly orange and then you can't use those. Whichever tubes turn orange you can't use. So I'm going to come back a second pass to make sure they're nice and flush. Okay. There we go. Get this guy out. Yeah, they don't get stuck on this. You want to inspect each one as you pull it out. Looking really good. I'm actually going to put them over here. These are all the same, so there's no particular order to them. There we go. Nice looking strip tubes. They're all ready to go. You can do 48, you can do 96, you can do 192, as many as you want. So we need to do a few cleanup things here. We are going to make sure that we label this with the ID here 0117-1. There we go. So I like to just put this, recommend just putting this on the top. You want labels that stay on in the freezer. So if you don't have any, you can recommend some. Okay, there we go. Then finally, put this guy in a Ziploc bag. You don't want to jostle it too much because you want it to freeze with the reaction mix all just down at the bottom. So there you go. Into the freezer. Thanks for watching!


## FloodLAMP Training Video Transcript 06 - Thawing Reactions

Test Trainer  [0:00](https://vimeo.com/668226340/1503f76081?ts=0)
Okay, so while these guys are cooling for the five minutes, we're gonna get out our reaction strips here. We got three left from this batch. You're gonna wanna make sure you don't leave these out for too long. Make sure you keep the freezer door shut while you do this. So these guys just take just about five minutes. Now here's a tip, push them up from the bottom. There you go. Make sure that they're all nice and pink there. If they're not pink that means you've probably got a little air gap on the top seal and you can't use that tube. So here we go. Just going to leave those. Make sure to get these guys back in the freezer before they thaw. There we go. Oh, got our five minute timer again. Stop that guy. Okay. Because we're only doing one strip, we're not going to use the cold block. Because we're going to be able to load this guy and get him on the amp pretty quick. If you were going to do more strips, then even before now, when you get him on the amp heater, you would get out your cold block. Here's the cold block. Because you want the cold block to warm up just a little bit. You don't want it to be totally frozen so that when you put the reactor strips in it they you want to stay cold but not frozen. OK. In terms of our run sheet here, there's where we're at. We're using strip eight tubes. They are frozen. And the reaction mix ID was on there. I can also get it from when I made it. Let's show you what that looks like. Here it is. So it's RM0115-1. I made this just a few days ago and I made all six strips. So that means six strips. I can say two strips left.


## FloodLAMP Training Video Transcript 07 - Adding Samples to Reaction

Test Trainer  [0:00](https://vimeo.com/668227040/c1dd7a8cac?ts=0)
Okay, so we're ready to add the samples and you can actually do this while they're cooling down. Our timer just went off so I'll do this part fast. But what we're going to do is we're going to finish filling out our form here. Number of reactions is going to be seven. Five samples plus the two controls. We will record the positive control ID in just a second. We're going to do two things here. We're going to, just to be careful, we're going to put these in number order. 43. Again, you can do this while they're cooling down, 32, 24, and 23. Okay, There we go. If you want to be extra careful, you can write the numbers down. Spot number three, four, five, six, seven. This is actually when you're Using a larger number of tubes in our lookup rack, this is a little more straightforward. Here with small numbers, I kind of like to have the backup. 23, 24, 32, 43, and 115. Okay so we're going to set up the tips to align with reactions. Should already be set up. I'm just going to use the leftmost column there. Okay, and now we're going to do something important and this is, should be in our protocol here. We already had done that. We'll go through that again. Here we go. This one right here. Strip 8 tube labeled on the top of each strip. So notice this guy isn't labeled, all nice and pink, so we're just going to put a one right there. Okay. Now, I'm going to get a piece of foil. I should keep this shut. A piece of foil for our caps. I like to try and save the caps. That way I don't get a mismatch between tubes and caps. If you do foul the caps or break it or have some problem, then don't worry about it, just get new ones. And here's a little technique tip, especially when these are colder. You do want to wait till it warms up that five minutes, but you kind of twist the first one off. And you're trying to make sure you don't touch the inside as you pull it off. So if your glove is not behaving, then try to fix it. Okay, and what I do here is I grab the tip and I'm pressing on the one behind it. We're not worried about cross-contamination here because there's no samples in here. So let's put that there, keep it nice and clean. Okay, we're going to do the negative control first. That is spot number two. Go down and get that. You always want to make sure you see the liquid in there. Go 12345. Blow out. Put These over here. Oh, don't try not to do that. There we go. Okay, we're gonna keep these guys covered while we work. Okay, get this out of the way, get our samples here ready to go, and we're ready to add them. Just going to put one at a time. Trying to hold the sample tubes over here, so hold them over here. Now these aren't activated, but you still don't want the chance for cross-contamination. So you've got to focus on counting to eight. Here's number three. There we go. Now you can look at the tip to see where you're at. Number four. There, I see it in the tip. Number four. If you lose track of where you are, just look right back over at the tips. That's why we align the tips, or set up the tips, we call it. There we go, number five. Number five. You'll get used to the positions here. If you get lost, look over there. Okay, and one more, six. If you get lost look over there, yeah okay and one more number seven. We're just going to leave that eighth one blank. Okay. Here we go. Keep these guys covered. So if we look at our list here, set up the tips, add the two microliters. You know, it doesn't say to add the positive control, it doesn't say to add the negative control because this is a short version. The long version has that in there. The positive control ID, actually had written down, it's TPC underscore. There we go. And I put quotes here for refer to the 1X. Okay. Got the positive control in the freezer here. So I'm going to be careful with this. I'll try to only touch the tube with my left hand. So what I do here is warm it up for about 30 seconds. So this is SARS-2 RNA, stabilized in total human RNA. This is the most fragile component of the test, meaning if you let it sit out at room temperature for very long, it degrades really fast and it won't work. Okay, so there we go. We're going to go back and get our first tip. We're gonna pipe it up and down to mix it quick. Oh, gotta make sure. That was something, I haven't had it a little too fast. You know, sometimes when you don't get your tip seated properly, it doesn't work. There, that worked. Doesn't work. There, that worked. Okay. And we got this. Okay. Shut this. Put this guy back in his little baggie. Back in the freezer. Okay, and a very important step here, which is to change gloves. If you just touch with your left hand and you're careful, you can just change one glove, but you have to change gloves. It's just a precaution to avoid any positive control cross contamination. So now we have our conveniently pre-loaded strip tubes here. When you grab these, be careful not to touch the inside. Okay, so press down there. There we go. Now, this critical part is you've got to make sure you hear that little pop. You've got to make sure that you're all pressed all the way down. Okay, and when you pull it out, you wanna look, make sure it's nice and flat. Okay, these guys are ready to go over here on the amp. All right, gotta put them in. Now, since I touched the amp area with my right hand, I'm going to change that glove and make sure I've got a timer set. I should have a separate timer over there, which I don't have right now. So let's just stop it a few seconds early since I started a few seconds late. Now I'm gonna show you, show you filling out the form when this comes off. All right.


## FloodLAMP Training Video Transcript 08 - Intaking Samples

Test Trainer  [0:00](https://vimeo.com/668259122/bd0ba696b0?ts=0)
Okay, so we just got our samples on the amp. Our main timer is going over there. So we're going to make sure we do these two parts circled here. Set the phone timer for 24 minutes or however long you need as your buffer to get back, because typically you go do something during this time. The second one is to put the sample tubes in the fridge, but notice here we have the intake sample tubes in the app as well. So we're just gonna go ahead and intake the sample tubes in the app. Here we go, give just a sec. Okay. So pop open the FloodLAMP app. And I'm already logged in on the staff side. If you're not, you switch there. So now we just hit intake, and hit create batch, and that's the batch name. Now notice that this needs to go over here. It's up at the top because you can do it first, but we typically are waiting now until it's on the app to save some time. And it's the date backwards, dash one for the first one. Okay, so we hit submit. And now it just pops straight into the scanner, and we're going to keep these in order. It doesn't like the lighting here. There we go. For some reason it doesn't pick it up for you, usually it helps by moving it back. It's kind of a little counterintuitive there. Okay, so now hit cancel. And now if you wanna linearly process them through, choose your batch, update it, tell it it's on the amp. There you go. And now once it comes off and you're ready to result it, you go into that one, hit update, hit result, and you can result them. If for some reason one of the tubes is positive or inconclusive and you want to result the rest of the batch is negative, you can hit this arrow and you can go scan it. Well, this would be I think to add to the to that batch what we could do is go up to the scanner here and hit no batch. Say this one was positive. We could scan it. There you go. I notice now it pulled that one out of the batch. I think if we do this, I believe, we can add it right back in. So that allows you to flexibly process all the samples together, which typically they're going to be negative. Well, not so much right now, unfortunately, but when you're doing routine screening. And then the few positives that you do get, you can pull out easily. And the result of the rest is negative, and the positive is positive. So we're going to make sure to remember our key step here, get these guys in the fridge. There we go. Thanks for watching!


## FloodLAMP Training Video Transcript 09 - Resulting

Test Trainer  [0:00](https://vimeo.com/668255645/fd27b62f60?ts=0)
Okay, timer is almost done here. Samples are about to come off. My phone timer went off. So I'm at the ready here. Okay, and we want to be tight on that. Here we go. That is what you want to see. Just positive control positive and everything else negative, assuming you're testing your friends and coworkers. So here we did the amp heat reactions. And now log and report results. Let the samples cool for at least a minute. As they cool, the color brightens up a little bit. So again, we'll give this a minute. So to go through the checklist here, when we set this timer, we set a phone timer for 24 minutes. Then we did a second thing, which was put the samples in the fridge. So you want to make sure that you do those two items. The reason the samples go in the fridge is so that if you need to do a rerun, they're preserved. So, important step. Okay, it's been about a minute. So the way we do this, you can do this on an Android or iPhone. If you have a different camera, you'll just have to get the right filter. Take a photo. You can either zoom in on your phone or afterwards. And then we do, if you have an iPhone, we apply the second filter over, it's called Vivid. We'll crop it a little bit more. Okay. There we go. And so now that's done.


## FloodLAMP Training Video Transcript 10 - Logging Run

Test Trainer  [0:00](https://vimeo.com/668260417/9a1877e852?ts=0)
So we finished our run and we got our photo. Everything went smooth. We had no surprise positives. So we will update in the app here. Let's do that first. We got our batch here of five tubes, and then we hit update, we hit result, negative, update status, select the same one, and we hit notify, and this won't actually send out notifications. This is a remnant of when we did do that. We did design the app to do that, I should say. OK, so now we have updated the results in the app. Check that guy off. And we just got one last thing to do here, and that is to log the run with the form link. So we're gonna go in here to that guy. Put in my name. Put in my FloodLAMP address. Whichever email address you use, just try to stick with the same one so we know who you are. We are at MBC Biolabs in San Carlos. We had five samples. Our batch ID was 220117-1. And now we hit this and choose to take a photo. Okay. And center it there. Now we have a record of this. We upload it. Okay. Now we did not use a lookup, a run lookup. If you want to, notice there's a map that you can write in on the back. So we didn't use that, but we could. We always want to do a photo of the results. There we go. It's a boring set of photos. Usually it's some fun photos of the kids. There we go. Okay. Didn't have any initial inconclusives. No notes to report. Pretty standard run. And there you go. And so now that's registered. Alright. And I can check this off and file this away. All right. There we go. Now we're done. Another run under our belt. Thanks for watching!


## FloodLAMP Training Video Transcript 11 - Large Scale Clean and Dispense

Test Trainer  [0:00](https://vimeo.com/668274931/5db248e4a5?ts=0)
Okay, so we're going to handle the sample so I'm going to get on my canary gown. I just leave it tight at the neck and put on over my lab coat. Oh, I got a tear. Oh, got a tear. There we go. That's not ideal, but we're gonna roll with it. We're going to roll with it Okay. All right. So got a dispenser all set up. Just, I guess go ahead and take, and take the samples over here. Try and wear my face shield again. It just keeps fogging up. Okay. So here we go. I've been asking people not to write their names on because it makes me think that they haven't collected in the app, but So far that's not been persuasive. So this part can be a little bit time consuming, so if you have a helper, this is a good thing to have them help with. In fact, if they're on site, you could even have them start this before the collection cutoff time because most people have deposited right now. Let's see, it's not going to work. Okay. So, two tubes here. We have about 35 mostly preschool families. So this could be over 100 people. I can't see it here so I'll just turn this like this. Way. Here's a big bag. Small tube in a big bag. How did that happen? We'll use this to put small bags. Lots of bags. Lots of bags. Pretty exciting, huh? Some folks skip the big outer individual bio bags and just put tubes straight in racks. And then I do recommend if you do that keeping them in a bin that says biohazard just to be extra careful. Okay. Alright, another giant bag. I've got a few different ways of collection kits that I've got out. Probably a faster way to do this, but you usually have help for this. Maybe we should give Carillon a rack, huh? It'll make this a lot easier. Given the state of things, the prevalence of the virus seems a little silly to put asymptomatic screening samples in a bunch of plastic, but we're following the rules. I'm gonna go ahead and just double check the lids. This is being extra cautious but We're just going to spray these with ethanol. I don't want to crank these down too tight. I should have counted them. I didn't. Well, hopefully we'll have enough inactivation solution. Okay, so the quick way to do this is spray them and then dry them as we pull them out. Oops. Probably get another rack for out here. We can probably just put them... Set them here.

Test Trainer  [8:04](https://vimeo.com/668274931/5db248e4a5?ts=484000)
Do two at once. We should go get a rack. Natasha, you want to pause and go grab us a rack? I can actually just hold it while... If you want to keep rolling Christine, you want to say I can hold the camera while she does that? Sure. I think that one maybe you could stop and do a second cut or something. I don't know. Just because it's synced up. Synced up. Yeah, you're right. You're right. Okay. This is a little tedious. You grab the blue one, the blue big, the big blue one, Natasha. There we go. Clean in tubes. Exciting stuff here. And then there's a bin on the shelf that has a few more orange ones like that. Can you grab those? Maybe just, even just one more? Let's just do this the right way and put these in a rack. It's much more civilized. That way I won't knock them all over like that. Fantastic. You can put them over there on the left. Thank you. How many do you think we had? 36? 35? 35. That looks right. There we go. Okay. All right, 35. Okay so now starts the fun dispensing process. I'll try my visor again, we'll see. Okay. Catch that drip. Get faster at this at this. Got it on the side. Now that's just one exit activation solution. This one is drippy. That's probably faster. Put these over here. Over here. So that was an air bubble and this is why we have the pipette handy. Because we are going to need to use our overflow to top off. So, I'm going to eyeball it. Just a little more. Hopefully we won't get too many of those. So, I'm just going to prime it first, just to make sure. Not getting anything weird. Just to make sure I'm not getting anything weird. What happened here? Got an air bubble. Got an air bubble. There we go. You can also do it this way. I might need to be faster that way. There we go. Well, that's not gonna work. Well, that's not going to work. Check out this tube. Okay. Pop it off. I think I need to fix the tube down there. Oops, I should leave that behind. Make sure you get the caps on Nice and tight here.


## FloodLAMP Training Video Transcript 12 - Large Scale Inactivation

Test Trainer  [0:00](https://vimeo.com/668290807/3c156973e9?ts=0)
So, okay, so we got them all dispensed here and we're ready to vortex. So I'm just going to put this off the table because this is a... Don't want this to rattle around. Here we go. There we go. You know what, same with this guy. These guys are all done. There we go. Okay. So now, just to the side. So we're going to do 30 seconds here. There we go, same here. There we go. Just turn this off. Okay. There we go. Okay. Now I'm going to go ahead and change gloves. Here we go. Here we go. I'm going to put this up here. I'm just going to put these in here. Easy transport. Okay, now we go into the lab. There we go. I'm just going to put these in the water bath. So let me put this over here. Before you do any of that, Do you want me to get the other camera in here? Nope, nope. We'll just do it with this one. Okay. The biggest danger is steam burns here, so you kind of let the water drip like that. Then, I'm just going to put these in. There we go. We're going to start our timer. That way we'll pull the first ones out. Kind of go across. Okay. Okay. Okay. All right, now we let these cook for eight minutes.


## FloodLAMP Training Video Transcript 13 - Reaction Plate Prep

Test Trainer  [0:00](https://vimeo.com/668272376/be640d2258?ts=0)
Okay, so we're gonna just show quickly here. We're not gonna actually do it, but we're gonna show the steps for doing a whole plate. It's very similar to the strip tube, except you can do the whole plate, you can do half the plate. So if you have partial plates, I do recommend storing them in foil. I have this in a foil in a bag. That way you keep them clean, even cleaner than the inside of a plastic bag. So the plates, they're all a little bit different. You'll probably have two or three different types that we have going. You'll see A1 is in the upper left. So you want to get it in the cold block like that. Then use a cold block lid to keep it covered. Get the rest of the plates away. This is why it's so handy to have the set of drawers right here. It cost about $30, but super helpful. Okay, so now this would be set up and we'd do just like we did before go into all the columns there once that's filled then you want to get a plate seal. So here you go and see how I do on this. Just want to start one edge, pull it across. You just want to make sure it gets fully covered. I was close there. You can see I started a little too far on the right. And then this sealer here, this plate has a little bit of a raised lip, so we're going to do it from both sides. There you go, and you just want to see all of the spots. Okay, you want to take this and again put it in a plastic bag. Okay, there's your sealed plate. You may also have, or if you don't, and it's a convenient format for you, you can request these. These are little 24 blocks, so they're basically plates that have been chopped up but are certified DNAase, RNAase free. And so in that case, you would want to take your plate seal, and with scissors you bleached and ethanoled cut sections that are sort of just big enough to cover these guys. And you can seal them the same way. Okay, that's the little plate setup here.


## FloodLAMP Training Video Transcript 14 - Plate Processing

Test Trainer  [0:01](https://vimeo.com/897312968/f8511e8b9d?ts=1000)
Now, he's ready to pipette into. So get this stuff out of the way, get your two microliter pipette, and get comfortable. It's going to take about 30 minutes to pipette a plate. But just keep in mind that you are testing about 400 people trying to find that needle in a haystack of unknown infected person before they spread it. That's the whole goal here. So as you're getting bored doing this, remind yourself that. So I'm a little bit cramped on space here. Let's see. I'm just gonna Let's see, I'm gonna just get some stuff out of the way that I'm not gonna be using. So I would move these guys probably. Yikes. These guys probably. Yikes. So we're just gonna want to draw. Probably have them end up set up like this. And then again you're going to come here you would have dispensed probably into a like a 1.5 mill tube, one ml of the inactivation solution that you used for adding to the samples. And so you would do that guy first, again in position number two. I think in the last video I forgot to show doing that positive control so but showed that on the first one so so this would be position number two right there I'm sorry that's position B1 okay then you get that guy back out of the way. Now that gives you a reference point to start. And again, I would go ahead and set up your pipette tips. In this case, you probably have a new box and it would have them going all the way across and you just would have taken out the second one. So it would look like this except going all the way across. So now we're ready to get comfortable and start pipetting. I don't know if there's any liquid in here. So the key here is getting sorted out on your lookup. So you make sure that this goes in the right spot. And notice we got our batch label on here, and then we can, ideally these batch labels will be smaller labels, and you can put this on the plate or make sure it rides along with the plate. Okay, so you get the idea here. Making sure you're lined up tip to spoil spot. You're going all the way down to the bottom, doing your five pipette up and downs, and then above the liquid blowout and tip touch. There you go. So you just keep going. So you just keep going. Then, once you finish, so you go all the way across, then you get another plate seal. And you follow the same operation you did before. You peel this one back and you put it across and you seal the whole plate back up. Make sure to do your positive control last here, same way we did it before. Okay, that is how you do a plate.


## FloodLAMP Training Video Transcript 15 - (Appendix) Setup

Test Trainer  [0:00](https://vimeo.com/668087884/5a89ad015f?ts=0)
Okay, I'm just getting my space organized here. Now this is a bit of an unconventional setup because normally you have your your amp heater on a separate table here we have this all together for for a demonstration. What I've done is I've taped off the amp area because regardless, you should have that taped off because that's the black hole where stuff goes in and does it come out and we treat it like it's radioactive. So I've cleaned this whole table already with bleach and then ethanol. And now I'm getting, setting the stuff from the new table, my main table I'm going to clean here. So I got the bleach, got some towels I can set up here. And typically I prefer to spray the towel kind of away from the work area. And that's, so you just don't want a lot of bleach overspray. I wipe even stuff I'm gonna have around, including the pens and markers. This is really important. The green tape means it's clean. At the beginning of the day, it's a good idea to clean them again. If you do ever touch these with your bare hands, you need to put them somewhere where you know to clean them, like a box that says to clean or something. So we're going to kind of clean this in sections here so I can move this stuff over. Okay, so that's my bleach. Now I'm just going to do the same thing with ethanol. The ethanol displaces the bleach, leaves it a little bit cleaner. You don't want to leave stuff wet, you want it to dry pretty fast. So anything you're going to touch while you're working, it's just nice at the beginning to clean it and keep it clean. Okay, so now I've got this section clean, so I'm going to move my stuff over. There we go. There we go. Same thing with ethanol. Okay. Hit this with ethanol as well. Okay, I might be touching my camera here. I will be touching my phone, so I'm going to bleach my phone. It's good not to be distracted by your phone while you're working, but if you're going to end up needing it for photos or other things, good to bleach it. Just wipe it. Also usually bleach wipe the top of my chair. Okay, now ethanol.


## FloodLAMP Training Video Transcript 16 - (Appendix) Pipette Cleaning

Test Trainer  [0:00](https://vimeo.com/668088713/534352aaf0?ts=0)
So we just cleaned our table and we're gonna go through cleaning the pipettes real fast. Bring them over here. I'm just gonna wipe the outside of the boxes as well. So it's kind of nice to do this in an area usually kind of away from your work area. Just get over here. These I do just give a spray. You don't want this to get everywhere. Flip them over. Get them kind of top to bottom. So I wipe them in between. Make sure to get the top thumb part, and I give this guy a little like that, wipe spot. Just kind of keep wiping. Just got to get them nice and dry. I don't know if the manufacturers recommend this or not, or if they're worried about bleach. This is what I've been doing though. Okay, same thing with ethanol. Give a quick spray. Flip them over. Okay, and wipe. Okay, and wipe. There we go. Surface. There we go. Surface. Let's try to get it nice and dry. If your towel gets too wet, just get another one. You should have plenty of towels. Okay. I've done plenty of towels. Okay and one more quick bleach wipe. These guys, It's kind of where you touch them. Especially the thumb part. And then, look, one towel left, perfect. Okay, these guys. These guys. Okay. Here we go. These guys are all ready to go and I just put them on top of where they go. Make sure they... Oops. There we go. Actually, I'm just going to get these way out of the way. Alright, so now I get my stuff over here to the right. Tip bucket in the middle. Get these guys set up. Okay, now we're good to go. We're all set up, clean, pipette's clean, table clean, accoutrement's clean, we're good.


## FloodLAMP Training Video Transcript 17 - (Appendix) Dispensers

Test Trainer  [0:00](https://vimeo.com/668273690/40c8936544?ts=0)
All right. We are getting prepared to do a run here. And first I'm going to go through setting up the dispenser. So we got it in a handy little Tupperware here. Got our 500 mil bottle and we just, I've got the whole controls. I just leave everything plugged in. It's easiest this way. Okay, and then I'm gonna stretch this cord across. There we go. And I just stick the whole head in a plastic bag to keep it clean. But before I do, I'm going to put our saline. Actually, I'm sorry, this is our 1X inactivation solution we just made. It's 50 mils for 35 samples. Should be enough overage. Oops. I should have my mask on when handling this. It's okay. Got a little drip. Okay, now we can go ahead and stick this guy on. Alright, all sealed up. Now we're gonna get this set up. This over here. This set up back here. Okay, actually you know what? We probably want to set this up on the other side because of the cord. Once we get it started we're not going to need a change. Nope. I think I can get it. Nope. See the plug right there. This thing does have batteries, so you can't operate it for a while without the plug. We are going to go ahead and plug it in though. System test. Okay. Everything's set up. One mil dispense, 10 iterations. Let's go ahead and prime it. Let's also get this cord out. Let's do a little cord management here. There we go. Okay, it's looking good. Okay, ready to go. Alright, so our dispenser is all set up. In case we need to catch a drip. Looks like there's a drip right there. Okay. All right.
