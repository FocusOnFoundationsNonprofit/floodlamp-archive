METADATA
last updated: 2026-03-04 by BA
file_name: 2023-11-08_FDA Website - In Vitro Diagnostics EUAs.md
file_date: 2023-11-08
title: FDA Website - In Vitro Diagnostics EUAs
category: regulatory
subcategory: fda-policy
tags: 
source_file_type: website
xfile_type: NA
gfile_url: NA
xfile_github_download_url: NA
pdf_gdrive_url: NA
pdf_github_url: NA
conversion_input_file_type: docx
conversion: manual cut and paste
license: Public Domain
tokens: 507
words: 217
notes: date converted 2024-04-05
web_url: https://www.fda.gov/medical-devices/covid-19-emergency-use-authorizations-medical-devices/in-vitro-diagnostics-euas
summary_short: The "2023-11-08_FDA Website - In Vitro Diagnostics EUAs" document explains FDA’s COVID-19 IVD EUA framework after the May 11, 2023 expiration of the HHS public health emergency and the end of certain COVID-19 enforcement-policy guidances. It clarifies that the PHE’s end did not eliminate FDA’s authority to keep existing EUAs in effect or issue EUAs under FD&C Act section 564, and it directs manufacturers to FDA’s EUA transition-plan guidance and related FAQs for expectations when EUA declarations eventually end.


CONTENT

November 8, 2023 - The COVID-19 public health emergency (PHE) declared under section 319 of the Public Health Service (PHS) Act [expired](https://www.hhs.gov/about/news/2023/02/09/fact-sheet-covid-19-public-health-emergency-transition-roadmap.html) on May 11, 2023. The COVID-19 enforcement policy guidances within scope of the [Transition Plan for Medical Devices That Fall Within Enforcement Policies Issued During the Coronavirus Disease 2019 (COVID-19) Public Health Emergency]((https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-fall-within-enforcement-policies-issued-during-coronavirus-disease)) are no longer in effect.

The end of the COVID-19 PHE and certain COVID-19 enforcement policy guidances no longer being in effect do not impact the FDA's ability to authorize devices, including tests, for emergency use. Existing emergency use authorizations (EUAs) for devices relating to COVID-19 remain in effect under section 564 of the Federal Food, Drug, and Cosmetic Act. The FDA encourages manufacturers of devices issued EUAs related to COVID-19 to review the guidance: [Transition Plan for Medical Devices Issued Emergency Use Authorizations(EUAs) Related to Coronavirus Disease 2019 (COVID-19)](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-issued-emergency-use-authorizations-euas-related-coronavirus-disease) and [Transition Plan for Medical Devices Issued Emergency Use Authorizations (EUAs) Related to Coronavirus Disease 2019 (COVID-19)](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-issued-emergency-use-authorizations-euas-related-coronavirus-disease), which outlines the FDA's recommendations and expectations to such manufacturers to transition to normal operations when the declarations that allowed for FDA to issue EUAs under section 564 of the Federal Food, Drug, and Cosmetic Act end. Additional information is provided on the page [FAQs: What happens to EUAs when a public health emergency ends?](https://www.fda.gov/emergency-preparedness-and-response/mcm-legal-regulatory-and-policy-framework/faqs-what-happens-euas-when-public-health-emergency-ends)
