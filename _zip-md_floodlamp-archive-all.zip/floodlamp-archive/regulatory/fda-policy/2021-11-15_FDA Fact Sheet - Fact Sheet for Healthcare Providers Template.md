METADATA
last updated: 2026-03-04 by BA
file_name: 2021-11-15_FDA Fact Sheet - Fact Sheet for Healthcare Providers Template.md
file_date: 2021-11-15
title: FDA Fact Sheet - Fact Sheet for Healthcare Providers Template
category: regulatory
subcategory: fda-policy
tags: 
source_file_type: docx
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1z89Vls227zXt8-XD3KID4OYRZWMjgFZH
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/regulatory/fda-policy/2021-11-15_FDA%20Fact%20Sheet%20-%20Fact%20Sheet%20for%20Healthcare%20Providers%20Template.docx
pdf_gdrive_url: https://drive.google.com/file/d/1KrfwKAHzjWluT23JNvaWm28NY7idzlzM
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/regulatory/fda-policy/2021-11-15_FDA%20Fact%20Sheet%20-%20Fact%20Sheet%20for%20Healthcare%20Providers%20Template.pdf
conversion_input_file_type: docx
conversion: pandoc
license: Public Domain
tokens: 2806
words: 1814
notes: 
summary_short: The "2021-11-15_FDA Fact Sheet - Fact Sheet for Healthcare Providers Template" document is a standardized, fill-in document for EUA-authorized COVID-19 tests that explains authorized use (including serial testing in individuals with or without symptoms), specimen type, and key result interpretation and reporting expectations. It includes required language on false positives/negatives, considerations for asymptomatic testing, optional pooling and home-collection language, and a variant-performance limitation statement. It helps test sponsors and high-complexity laboratories produce consistent provider-facing labeling that aligns with EUA conditions and public health reporting needs.


CONTENT

***INTERNAL TITLE:*** FACT SHEET FOR HEALTHCARE PROVIDERS
**Coronavirus Disease 2019 (COVID-19)** 
**v1.0 (November 15, 2021)**
**LABORATORY NAME - TEST NAME     Month DD, YYYY**

This Fact Sheet informs you of the significant known and potential risks and benefits of the emergency use of the \[DEVICE/TEST NAME\].

**This test is to be performed only using anterior nasal respiratory specimens from individuals, including individuals without symptoms or other reasons to suspect COVID-19, when tested at least once per week.**

The \[DEVICE/TEST NAME\] is authorized for use with anterior nasal respiratory specimens from individuals, including individuals without symptoms or other reasons to suspect COVID-19, when tested at least once per week.

**All patients whose specimens are tested with this assay will receive the Fact Sheet for Patients: \[LABORATORY NAME\] - \[DEVICE/TEST NAME\].**

**What are the symptoms of COVID-19?**

Many patients with COVID-19 have developed fever and/or symptoms of acute respiratory illness (e.g., cough, dyspnea), although some individuals experience only mild symptoms or no symptoms at all. The current information available to characterize the spectrum of clinical illness associated with COVID-19 suggests that, when present, symptoms include cough, shortness of breath or dyspnea, fever, chills, myalgias, headache, sore throat, new loss of taste or smell, nausea or vomiting or diarrhea. Signs and symptoms may appear any time from 2 to 14 days after exposure to the virus, and the median time to symptom onset is approximately 5 days. For further information on the symptoms of COVID-19 please see the link provided in “*Where can I go for updates and more information?*” section.

Public health officials have identified cases of COVID-19 throughout the world, including the United States. Please check the CDC COVID-19 webpage (see link provided in “*Where can I go for updates and more information?*” section at the end of this document) or your local jurisdictions website for the most up to date information.

**What do I need to know about COVID-19 testing?**

Current information on COVID-19 for healthcare providers is available at CDC’s webpage, *Information for Healthcare Professionals* (see links provided in “*Where can I go for updates and more information?*” section).

-   The \[DEVICE/TEST NAME\] can be used to test anterior nasal respiratory specimens.

-   The \[DEVICE/TEST NAME\] should be ordered for the detection of SARS-CoV-2 in individuals, including individuals without symptoms or other reasons to suspect COVID-19, when tested at least once per week.

-   \[INCLUDE THE FOLLOWING BULLET IF YOUR TEST INCLUDES USE OF AN AUTHORIZED HOME COLLECTION KIT – MODIFY TO INCLUDE HOME COLLECTION INDICATION BASED ON THE APPENDIX YOU ARE CLAIMING: The \[DEVICE/TEST NAME\] can also be used to test anterior nasal respiratory specimens collected by a healthcare provider (HCP) or self-collected under the supervision of an HCP or self-collected at home using the following authorized home collection kit(s) \[INCLUDE NAME OF AUTHORIZED KIT\]\].

-   \[INCLUDE THE FOLLOWING BULLET IF YOUR TEST ALLOWS SPECIMEN POOLING – BASED ON THE APPENDIX YOU ARE CLAIMING\]: The \[DEVICE/TEST NAME\] can also be used to test up to \[INCLUDE POOLING INDICATION BASED ON THE APPENDIX YOU ARE CLAIMING\].

-   The \[DEVICE/TEST NAME\] is only authorized for use at the \[NAME OF LABORATORY\] that is certified under the Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. §263a, and meets requirements to perform high complexity tests.

Specimens should be collected with appropriate infection control precautions. Current guidance is available at the CDC’s website (see links provided in “*Where can I go for updates and more information?*” section).

When collecting and handling specimens from individuals suspected of being infected with the virus that causes COVID-19, appropriate personal protective equipment should be used as outlined in the CDC *Interim Laboratory Biosafety Guidelines for Handling and Processing Specimens Associated with Coronavirus Disease 2019 (COVID-19)*. For additional information, refer to CDC *Interim Guidelines for Collecting, Handling, and Testing Clinical Specimens from Persons Under Investigation (PUIs) for Coronavirus Disease 2019 (COVID-19) (*see links provided in “*Where can I go for updates and more information?*” section).

**What does it mean if the specimen tests positive for the virus that causes COVID-19?**

A positive test result for COVID-19 indicates that RNA from SARS-CoV-2 was detected, and therefore the patient is infected with the virus and presumed to be contagious. Laboratory test results should always be considered in the context of clinical observations and epidemiological data (such as local prevalence rates and current outbreak/epicenter locations) in making a final diagnosis and patient management decisions. Patient management should be made by a healthcare provider and follow current CDC guidelines.

The \[DEVICE/TEST NAME\] has been designed to minimize the likelihood of false positive test results. However, it is still possible that this test can give a false positive result, even when used in locations where the prevalence is below 5%. In the event of a false positive result, risks to patients could include the following: a recommendation for isolation of the patient, monitoring of household or other close contacts for symptoms, patient isolation that might limit contact with family or friends and may increase contact with other potentially COVID-19 patients, limits in the ability to work, delayed diagnosis and treatment for the true infection causing the symptoms, unnecessary prescription of a treatment or therapy, or other unintended adverse effects.

\[INCLUDE THIS TEXT IF YOUR INDICATION INCLUDES POOLING: Individuals included in a pool that returns a positive or invalid result should be treated as a presumptive positive unless or until they receive a negative result when re-tested individually. However, as most individuals in a positive pool will likely receive a negative result when re-tested individually, they should isolate until receiving a negative result when re-tested individually and should **not** be cohorted with other individuals who have received a positive or presumptive positive result.\]

All laboratories using this test must follow the standard testing and reporting guidelines according to their appropriate public health authorities.

**What does it mean if the specimen tests negative for the virus that causes COVID-19?**

A negative test result for this test means that SARS-CoV-2 RNA was not present in the specimen above the limit of detection. However, a negative result does not rule out COVID-19 and should not be used as the sole basis for treatment or patient management decisions. It is possible to test a person too early or too late during SARS-CoV-2 infection to make an accurate diagnosis via \[DEVICE/TEST NAME\].

In addition, asymptomatic people infected with the virus that causes COVID-19 may not shed enough virus to reach the limit of detection of the test, giving a false negative result. In the absence of symptoms, it is difficult to determine if asymptomatic people have been tested too late or too early. Therefore, negative results in asymptomatic individuals may include individuals who were tested too early and may become positive later, individuals who were tested too late and may have serological evidence of infection, or individuals who were never infected.

\[INCLUDE THIS TEXT IF YOUR INDICATION INCLUDES POOLING: Specimens with low viral loads may not be detected in sample pools due to the decreased sensitivity or increased interference of pooled testing. Your interpretation of negative results should take into account clinical and epidemiological risk factors.\]

When diagnostic testing is negative, the possibility of a false negative result should be considered in the context of a patient’s recent exposures and the presence of clinical signs and symptoms consistent with COVID-19. The possibility of a false negative result should especially be considered if the patient’s recent exposures or clinical presentation indicate that COVID-19 is likely, and diagnostic tests for other causes of illness (e.g., other respiratory illness) are negative.

If COVID-19 is suspected based on exposure history together with other clinical findings, re-testing using a new sample with a sensitive method \[INCLUDE THIS TEXT IF YOUR INDICATION INCLUDES POOLING: or without pooling\] should be considered by healthcare providers in consultation with public health authorities. Additional testing may be helpful to ensure testing was not conducted too early.

Risks to a patient of a false negative test result include: delayed or lack of supportive treatment, lack of monitoring of infected individuals and their household or other close contacts for symptoms resulting in increased risk of spread of COVID-19 within the community, or other unintended adverse events.

The performance of this test was established based on the evaluation of a limited number of clinical specimens. The clinical performance has not been established in all circulating variants but is anticipated to be reflective of the prevalent variants in circulation at the time and location of the clinical evaluation. Performance at the time of testing may vary depending on the variants circulating, including newly emerging strains of SARS-CoV-2 and their prevalence, which change over time.

**What is an EUA?**

The United States FDA has made this test available under an emergency access mechanism called an Emergency Use Authorization (EUA). The EUA is supported by the Secretary of Health and Human Service’s (HHS’s) declaration that circumstances exist to justify the emergency use of in vitro diagnostics (IVDs) for the detection and/or diagnosis of the virus that causes COVID-19. An IVD made available under an EUA has not undergone the same type of review as an FDA-approved or cleared IVD. FDA may issue an EUA when certain criteria are met, which includes that there are no adequate, approved, available alternatives, and based on the totality of scientific evidence available, it is reasonable to believe that this IVD may be effective in diagnosing COVID-19.

This test is authorized under the Umbrella EUA for SARS-CoV-2 Molecular Diagnostic Tests for Serial Testing \[include link to this letter\] for use in \[the specific laboratory, that is certified under CLIA and meets requirements to perform high complexity tests, in which it was developed\] for \[insert indication(s) from applicable appendix(ces)\] using the test procedures validated in accordance with the requirements of the Umbrella EUA for SARS-CoV-2 Molecular Diagnostic Tests for Serial Testing.

The EUA for this test is in effect for the duration of the COVID-19 declaration justifying emergency use of IVDs, unless terminated or revoked (after which the test may no longer be used).

**What are the approved available alternatives?**

Any tests that have received full marketing status (e.g., cleared, approved), as opposed to an EUA, by FDA can be found by searching the medical device databases here: <https://www.fda.gov/medical-devices/device-advice-comprehensive-regulatory-assistance/medical-device-databases>. A cleared or approved test should be used instead of a test made available under an EUA, when appropriate and available.  FDA has issued EUAs for other tests that can be found at:

<https://www.fda.gov/emergency-preparedness-and-response/mcm-legal-regulatory-and-policy-framework/emergency-use-authorization>.

**Where can I go for updates and more information?**

**CDC webpages:**

**General:** <https://www.cdc.gov/coronavirus/2019-ncov/index.html>

**Symptoms:**

<https://www.cdc.gov/coronavirus/2019-ncov/symptoms-testing/symptoms.html>

**Healthcare Professionals:**

[https://www.cdc.gov/coronavirus/2019-nCoV/hcp/index.html](https://www.cdc.gov/coronavirus/2019-nCoV/guidance-hcp.html)

**Information for Laboratories:** <https://www.cdc.gov/coronavirus/2019-nCoV/lab/index.html>

**Laboratory Biosafety:** <https://www.cdc.gov/coronavirus/2019-nCoV/lab-biosafety-guidelines.html>

**Isolation Precautions in Healthcare Settings:**

[https://www.cdc.gov/infectioncontrol/guidelines/isolation/index.html](https://www.cdc.gov/infectioncontrol/guidelines/isolation/index.html%20)

**Specimen Collection:** <https://www.cdc.gov/coronavirus/2019-nCoV/guidelines-clinical-specimens.html>

**Infection Control:** <https://www.cdc.gov/coronavirus/2019-ncov/php/infection-control.html>

**FDA webpages:**

**General:** [www.fda.gov/novelcoronavirus](http://www.fda.gov/novelcoronavirus)

**EUAs:**(includes links to fact sheet for individuals and manufacturer’s instructions) <https://www.fda.gov/medical-devices/coronavirus-disease-2019-covid-19-emergency-use-authorizations-medical-devices/in-vitro-diagnostics-euas>

**LABORATORY NAME:**

ADDRESS LINE 1

ADDRESS LINE 2



**Customer Support:**

+1 800 XXX-XXXX

customersupportemail@company.com

**Technical Support:**

+1 800 XXX-XXXX

techsupportemail@company.com
