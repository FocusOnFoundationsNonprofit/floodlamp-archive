## files to include for combined md
aggregate_pilot-data/aggregate_pilot-data_summary.md
ABRM_pilot-data/ABRM_pilot-data_summary.md
BEND_pilot-data/BEND_pilot-data_summary.md
COMB_pilot-data/COMB_pilot-data_summary.md
COSP_pilot-data/COSP_pilot-data_summary.md
CRLN_pilot-data/CRLN_pilot-data_summary.md
DAVI_pilot-data/DAVI_pilot-data_summary.md
DAVI_pilot-data/DAVI_pilot-data_referral-antigen-comparison.md
DAVI_pilot-data_referral-antigen-comparison_AI-ANALYSIS-AND-CHECK.md
FLMP_pilot-data/FLMP_pilot-data_summary.md
FLSP_pilot-data/2021-12-28_Case Report - Randy.md
FLMP_pilot-data/2022-01-01_Case Report - New Years Eve.md
FLMP_pilot-data/2022-01-02_Carillon Case Report of Asymptomatic Positive Family Pool.md
FLSP_pilot-data/FLSP_pilot-data_summary.md
FTFC_pilot-data/FTFC_pilot-data_summary.md
KENT_pilot-data/KENT_pilot-data_summary.md
NDHM_pilot-data/NDHM_pilot-data_summary.md
ROSA_pilot-data/ROSA_pilot-data_summary.md

## files to include for zip
_code_pilots-data/
_dev-code_pilots-data/
_docs_pilot-data/
ABRM_pilot-data/
aggregate_pilot-data/
BEND_pilot-data/
COMB_pilot-data/
COSP_pilot-data/
CRLN_pilot-data/
DAVI_pilot-data/
FLMP_pilot-data/
FLSP_pilot-data/
FTFC_pilot-data/
KENT_pilot-data/
NDHM_pilot-data/
ROSA_pilot-data/
_archive-combined-files_pilot-data_84k.md
_context-commentary_pilots-pilot-data.md
_context-commentary_pilot-data_data-processing.md
_filelist_pilot-data.md
Data PUB - Pilot Data Google Files - PUB Filenames.csv
Data PUB - Pilot Data Google Files - PUB URLs.csv
reference_aggregate_stats.csv
reference_stats_metrics.csv