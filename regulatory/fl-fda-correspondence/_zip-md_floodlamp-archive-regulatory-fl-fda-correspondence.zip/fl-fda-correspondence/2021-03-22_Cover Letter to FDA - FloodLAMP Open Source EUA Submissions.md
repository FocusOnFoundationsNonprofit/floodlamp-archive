METADATA
last updated: 2025-12-16 BA updated metadata after BA fixed inconsistencies
file_name: 2021-03-22_Cover Letter to FDA - FloodLAMP Open Source EUA Submissions.md
file_date: 2021-03-22
title: Cover Letter to FDA - FloodLAMP Open Source EUA Submissions
category: regulatory
subcategory: fl-fda-correspondence
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1NQ3_Rmh-AYVSPYn7AP-Hls9rMLBXEX1zWLvRLTrzPrE
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/regulatory/fl-fda-correspondence/2021-03-22_Cover%20Letter%20to%20FDA%20-%20FloodLAMP%20Open%20Source%20EUA%20Submissions.docx
pdf_gdrive_url: https://drive.google.com/file/d/1Msh-TYQeiZlCc2fd_zhW0CQOk3U8B_bO
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/regulatory/fl-fda-correspondence/2021-03-22_Cover%20Letter%20to%20FDA%20-%20FloodLAMP%20Open%20Source%20EUA%20Submissions.pdf
conversion_input_file_type: docx
conversion: pandoc
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 716
words: 518
notes: 
summary_short: The "2021-03-22_Cover Letter to FDA - FloodLAMP Open Source EUA Submissions" document is a cover letter to the FDA that accompanied FloodLAMP Open Source EUA Submissions. It summarizes FloodLAMP’s follow-up to a pre-EUA with two full EUA submissions: the QuickColor colorimetric LAMP test and the EasyPCR duplex PCR test, both using a shelf-stable chemical plus heat inactivation workflow. It positions the assays as open-source, supply-chain-resilient protocols (modeled on SalivaDirect) and highlights primer sourcing, clinical performance claims, intended screening use cases, and supporting plans for IRB studies and a companion mobile app.


CONTENT

Dear COVID19DX IVD Team,

I'm pleased to follow up on FloodLAMP Biotechnologies' pre-EUA PEUA201985 with 2 complete COVID-19 IVD EUA submissions. Thank you for the extensive comments and guidance on the pre-EUA.

These new submissions are for direct tests rather than the glass milk purification from our pre-EUA. Both tests utilize the same shelf stable chemical plus heat inactivation protocol. The FloodLAMP QuickColor(TM) COVID-19 Test uses a colorimetric LAMP amplification that is visually read by a simple color change. The FloodLAMP EasyPCR(TM) COVID-19 Test uses a one-step PCR amplification in duplex with an internal control.

Both EUA submissions are configured as open source protocols, building on the model established by SalivaDirect(TM). The chemicals and reagents needed for the tests are readily available in large quantities. The workflow for the tests has been simplified and only a single pipet tip per sample is required, further reducing potential supply chain bottlenecks.

The LAMP primers chosen target 3 different genes in SARS-CoV-2 to ensure robustness and sensitivity. These primer sequences have been widely validated in research, utilized in testing programs, and submitted in other LAMP EUAs. Over the last 3 months, FloodLAMP has partnered with LGC Biosearch to establish the supply of these primers. FloodLAMP configured the primers to be offered as a catalog product by LGC Bioserach, and placed an order for 1.2M reactions in January. A portion of the production primers were delivered to FloodLAMP's lab on March 19. The other portion will be launched shortly as catalog products. With the support of the CDC and FDA, with authorization of our tests, FloodLAMP will offer a blanket right of reference to the LAMP primer validation data for any IVD test developer or CLIA lab, in an effort to further expand access to COVID-19 testing and screening.

The FloodLAMP QuickColor(TM) COVID-19 Test demonstrated 90% sensitivity and 100% specificity in our clinical evaluation. It is ideal for use in serial screening of schools and large populations, as no specialized instrumentation is required. Both tests have very low consumables cost, at $1-2 per reaction, and a modestly trained operator can process 800 reactions per shift without any automation.

FloodLAMP is in the process of obtaining an IRB to perform clinical studies for unsupervised home collection, pooling, and asymptomatic screening. The clinical studies will include usability testing for our mobile app. The app has a patient interface for sign up, consent, sample collection and results. It also has a staff interface for sample intake, barcode scanning, batch control, and results reporting, as well as an api to interface with any LIMS. The app enables accessioning and results reporting without a LIMS, providing a low overhead end-to-end digital solution for a lab running community screening.

FloodLAMP's EUA submissions for these 2 molecular tests provide a combination of performance, ease of use, supply chain robustness, low cost, and scalability. Along with the other testing and screening program elements we've developed, they will significantly increase test capacity and access across the nation.

We look forward to further engaging with the FDA on this important effort.

Sincerely,
Randy True

Founder - FloodLAMP Biotechnologies, Public Benefit Corporation
randy@floodlamp.bio
