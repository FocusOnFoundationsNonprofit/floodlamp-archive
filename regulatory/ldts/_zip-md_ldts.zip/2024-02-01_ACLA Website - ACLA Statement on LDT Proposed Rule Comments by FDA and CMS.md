METADATA
last updated: 2025-12-17 BA
file_name: 2024-02-01_ACLA Website - ACLA Statement on LDT Proposed Rule Comments by FDA and CMS.md
file_date: 2024-02-01
title: ACLA Website - ACLA Statement on LDT Proposed Rule Comments by FDA and CMS
category: regulatory
subcategory: ldts
tags: 
source_file_type: website
xfile_type: NA
gfile_url: NA
xfile_github_download_url: NA
pdf_gdrive_url: NA
pdf_github_url: NA
conversion_input_file_type: docx
conversion: manual cut and paste
license: Public Domain
tokens: 378
words: 202
notes: date converted 2024-06-03
web_url: https://www.acla.com/acla-statement-on-ldt-proposed-rule-comments-by-fda-and-cms/
summary_short: The ACLA statement responds to an FDA/CMS joint release on proposed LDT regulation by reiterating ACLA’s position that LDTs are not medical devices and that FDA’s proposed rule would harm patients and stifle diagnostic innovation. It emphasizes laboratories’ role in patient care and argues for a legislative approach developed with Congress and stakeholders rather than applying the medical device framework to LDTs.


CONTENT

Washington, D.C. – In response to a [joint release](https://www.fda.gov/medical-devices/medical-devices-news-and-events/fda-and-cms-americans-deserve-accurate-and-reliable-diagnostic-tests-wherever-they-are-made) from the U.S. Food & Drug Administration (FDA) and Centers for Medicare & Medicaid Services (CMS) on a proposed rule to regulate laboratory developed tests (LDTs) as medical devices, the below statement can be attributed to American Clinical Laboratory Association (ACLA) President Susan Van Meter.

“ACLA late last year provided [extensive comments](https://www.acla.com/fda-proposed-rule-to-regulate-ldts-as-medical-devices-would-slow-development-of-critical-lab-tests-and-should-be-withdrawn-acla-urges/) urging the FDA to withdraw the proposed rule that seeks to regulate LDTs as medical devices under the Federal Food, Drug, and Cosmetic Act. We firmly maintain that LDTs are not medical devices and regulating them as such would be harmful to patients and would severely hamper innovation in the next generation of diagnostics. Laboratories and the LDTs they develop have made – and continue to make – extraordinary contributions to patient care and public health. Every day, LDTs help physicians and patients to diagnose diseases and make informed health care choices. Rather than imposing a device framework that is inappropriate for LDTs, ACLA encourages FDA to work with Congress, ACLA, and other stakeholders to develop legislation that would establish a role for FDA in the regulation of LDTs aligned with their already robust oversight.”

Read ACLA’s full comment letter [here](https://www.acla.com/aclas-comments-on-fdas-proposed-regulation-of-laboratory-developed-tests-as-medical-devices/).
