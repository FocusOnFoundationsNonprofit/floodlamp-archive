METADATA
last updated: 2025-12-17 BA
file_name: 2024-03-21_FDA Website - ACLA President to Testify on Regulation of Diagnostic Tests.md
file_date: 2024-03-21
title: FDA Website - ACLA President to Testify on Regulation of Diagnostic Tests
category: regulatory
subcategory: ldts
tags: 
source_file_type: website
xfile_type: NA
gfile_url: NA
xfile_github_download_url: NA
pdf_gdrive_url: NA
pdf_github_url: NA
conversion_input_file_type: docx
conversion: manual cut and paste
license: Public Domain
tokens: 381
words: 198
notes: date converted 2024-06-03
web_url: https://www.acla.com/acla-president-to-testify-on-regulation-of-diagnostic-tests/
summary_short: The "2024-03-21_FDA Website - ACLA President to Testify on Regulation of Diagnostic Tests" document summarizes ACLA’s argument that treating most lab testing services as medical devices would reduce access to critical tests, raise costs, and hinder innovation, and points to ACLA’s prior comments urging withdrawal of the rule and advocating for legislation to establish a diagnostics-specific framework.


CONTENT

Washington, D.C. – [American Clinical Laboratory Association](https://www.acla.com/) (ACLA) President Susan Van Meter will testify before the House Energy and Commerce Committee’s Subcommittee on Health for a hearing titled, “[Evaluating Approaches to Diagnostic Test Regulation and the Impact of the FDA’s Proposed Rule](https://energycommerce.house.gov/posts/chairs-rodgers-and-guthrie-announce-health-subcommittee-hearing-on-regulation-of-diagnostic-tests),” today at 10:00 a.m. E.T. 

Laboratory developed test services are an indispensable pillar of the nation’s health care system. ACLA members provide high quality and innovative testing services to patients in every state across the country. However, the U.S. Food and Drug Administration’s (FDA) proposed rule would subject virtually all laboratory testing services to medical device regulation, which would limit or eliminate access to critical tests, increase health care costs, and undermine diagnostic and medical innovation.

ACLA previously [submitted comments](https://www.acla.com/fda-proposed-rule-to-regulate-ldts-as-medical-devices-would-slow-development-of-critical-lab-tests-and-should-be-withdrawn-acla-urges/) urging the FDA to withdraw its proposed rule to regulate laboratory developed tests as medical devices under the Federal Food, Drug, and Cosmetic Act. The association maintains that legislation is required for FDA to regulate laboratory developed tests and has committed to working with Congress, FDA, and other stakeholders to develop a diagnostic-specific regulatory framework. 

The hearing can be watched via the committee’s website [here](https://energycommerce.house.gov/committees/subcommittee/health).

Van Meter’s written remarks, as submitted to Congress, are available [here](https://www.acla.com/statement-of-acla-president-to-the-health-subcommittee-of-the-house-energy-commerce-committee/).
