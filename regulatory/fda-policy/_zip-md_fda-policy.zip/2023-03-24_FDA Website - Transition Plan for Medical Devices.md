METADATA
last updated: 2026-03-04 by BA
file_name: 2023-03-24_FDA Website - Transition Plan for Medical Devices.md
file_date: 2023-03-24
title: FDA Website - Transition Plan for Medical Devices
category: regulatory
subcategory: fda-policy
tags: 
source_file_type: website
xfile_type: NA
gfile_url: NA
xfile_github_download_url: NA
pdf_gdrive_url: NA
pdf_github_url: NA
conversion_input_file_type: docx
conversion: manual cut and paste
license: Public Domain
tokens: 483
words: 201
notes: date converted 2024-03-27
web_url: https://www.fda.gov/medical-devices/covid-19-emergency-use-authorizations-medical-devices/in-vitro-diagnostics-euas-molecular-diagnostic-tests-sars-cov-2
summary_short: The FDA announces final March 24, 2023 guidances that lay out how medical devices covered by COVID-19 enforcement policies or issued COVID-19 EUAs should transition back to normal regulatory operations. It highlights FDA recommendations to create a transition implementation plan, prepare and submit an appropriate marketing submission, and take other follow-on actions, with links to the guidances and an April 18, 2023 webinar for stakeholders.


CONTENT

March 24, 2023 - The FDA has finalized two guidances: [Transition Plan for Medical Devices That Fall Within Enforcement Policies Issued During the Coronavirus Disease 2019 (COVID-19) Public Health Emergency](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-fall-within-enforcement-policies-issued-during-coronavirus-disease) and [Transition Plan for Medical Devices Issued Emergency Use Authorizations (EUAs) Related to Coronavirus Disease 2019 (COVID-19)](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-issued-emergency-use-authorizations-euas-related-coronavirus-disease). The guidances outline the FDA's general recommendations to transition from certain policies adopted and operations implemented during the COVID-19 pandemic to normal operations, including the FDA's recommendations for:

Developing a transition implementation plan,
Submitting a marketing submission, and
Taking other actions with respect to these devices.
The FDA encourages stakeholders to review the two final guidances, view the webinar, and reach out to the FDA if they have questions or concerns. In particular, for manufacturers planning to seek marketing authorization for their devices, the FDA recommends beginning work on a marketing submission, including a transition implementation plan, as described in the guidances.

Additional Resources:
[Transition Plan for Medical Devices That Fall Within Enforcement Policies Issued During the Coronavirus Disease 2019 (COVID-19) Public Health Emergency](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-fall-within-enforcement-policies-issued-during-coronavirus-disease)
[Transition Plan for Medical Devices Issued Emergency Use Authorizations (EUAs) Related to Coronavirus Disease 2019 (COVID-19)](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/transition-plan-medical-devices-issued-emergency-use-authorizations-euas-related-coronavirus-disease)
[Webinar on Guidances on COVID-19 Transition Plans for Medical Devices - April 18, 2023](https://www.fda.gov/medical-devices/medical-devices-news-and-events/webinar-guidances-covid-19-transition-plans-medical-devices-04182023)
