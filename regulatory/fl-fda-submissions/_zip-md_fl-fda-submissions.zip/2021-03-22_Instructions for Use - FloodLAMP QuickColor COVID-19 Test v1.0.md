METADATA
last updated: 2025-12-16 BA updated metadata after BA fixed inconsistencies
file_name: 2021-03-22_Instructions for Use - FloodLAMP QuickColor COVID-19 Test v1.0.md
file_date: 2021-03-22
title: Instructions for Use - FloodLAMP QuickColor COVID-19 Test v1.0
category: regulatory
subcategory: fl-fda-submissions
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/15lzY7exZ6PTja9NeAYTs0zUF05Nyl2J5yD9f3BmEJvM
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive-wip/main/regulatory/fl-fda-subs/2021-03-22_Instructions%20for%20Use%20-%20FloodLAMP%20QuickColor%20COVID-19%20Test%20v1.0.docx
pdf_gdrive_url: https://drive.google.com/file/d/1wp_mYfcQBSyl0I5oPwB6QfBHcVuD2AWd
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive-wip/blob/main/regulatory/fl-fda-subs/2021-03-22_Instructions%20for%20Use%20-%20FloodLAMP%20QuickColor%20COVID-19%20Test%20v1.0.pdf
conversion_input_file_type: gdoc
conversion: gdoc markdown
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 12087
words: 7494
notes: 
summary_short: The Instructions for Use for the FloodLAMP QuickColor COVID-19 Test v1.0 provides CLIA high-complexity laboratories with the complete protocol for an extraction-free, colorimetric RT-LAMP assay with visual readout after chemical and heat inactivation. It details required reagents and equipment, primer preparation, step-by-step testing workflow, control requirements, result interpretation by color change, and contamination precautions. It also documents analytical and clinical performance claims, including a 12,500 copies/mL LoD and 90% positive agreement with 100% negative agreement in an 80-specimen evaluation.


CONTENT

***INTERNAL TITLE:*** FloodLAMP QuickColor(TM)  COVID-19 Test
Instructions for Use v1.0

IVD
COVID-19 Emergency Use Authorization Only
For *in vitro* diagnostic (IVD) Use  

www.floodlamp.bio
FloodLAMP Biotechnologies, PBC | 930 Brittan Ave. San Carlos, CA 94070 USA

## Table of Contents
|  |  |
|---------|------|
| Intended Use | 3 |
| Principles of Procedure | 3 |
| Materials Provided and Storage | 4 |
| Materials Required but Not Provided | 4 |
| • Standard Lab Equipment and Consumables | 6 |
| Warnings and Precautions | 6 |
| • General Precautions | 6 |
| • Contamination Precautions | 7 |
| Limitations | 7 |
| Conditions of Authorization for the Laboratory | 9 |
| Specimen Collection and Storage | 10 |
| Running Tests | 11 |
| • Reagent Preparation | 11 |
| • Controls Preparation | 12 |
| • 10X LAMP Primer Mix Preparation | 13 |
| • Sample Preparation | 15 |
| • Sample Inactivation | 15 |
| • Colorimetric LAMP Amplification Reaction Preparation | 15 |
| • Sample Addition and Heating | 16 |
| • Test Controls | 17 |
| • Patient Specimen Results Interpretation | 18 |
| Performance Evaluation | 19 |
| • Analytical Sensitivity: Limit of Detection (LoD) | 19 |
| • Analytical Sensitivity: Inclusivity (in silico) | 19 |
| • Evaluation of Impact of Viral Mutations | 20 |
| • Analytical Specificity: Cross-Reactivity (in silico) | 22 |
| • Analytical Specificity: Cross-Reactivity (wet testing) | 26 |
| • Analytical Specificity: Interfering Substances | 26 |
| Clinical Evaluation | 27 |
| Support | 29 |
||

FloodLAMP QuickColor(TM) COVID-19 Test  
For COVID-19 Emergency Use Authorization Only  
Instructions for Use

## Intended Use
FloodLAMP QuickColor(TM) COVID-19 Test is a reverse transcriptase loop-mediated isothermal amplification (RT-LAMP) assay intended for the qualitative detection of RNA from SARS-CoV-2 in upper respiratory specimens including nasopharyngeal swabs, anterior nasal and mid-turbinate nasal swabs from individuals suspected of COVID-19 by their healthcare provider and from individuals without symptoms or other epidemiological reasons to suspect COVID-19 infection, when tested at a weekly interval with no more than 9 days between tests. Testing is limited to laboratories certified under the Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. §263a, to perform high complexity tests, or by similarly qualified non-U.S. laboratories. 

Results are for the identification of SARS-CoV-2 RNA. The SARS-CoV-2 RNA is generally detectable in upper respiratory specimens including nasopharyngeal swabs, anterior nasal and mid-turbinate nasal swabs during the acute phase of infection. Positive results are indicative of the presence of SARS-CoV-2 RNA; clinical correlation with patient history and other diagnostic information is necessary to determine patient infection status. Positive results do not rule out bacterial infection or co-infection with other viruses. The agent detected may not be the definite cause of disease. Laboratories within the United States and its territories are required to report all test results to the appropriate public health authorities.

Negative results do not preclude SARS-CoV-2 infection and should not be used as the sole basis for patient management decisions. Negative results must be combined with clinical observations, patient history, and epidemiological information.

The FloodLAMP QuickColor(TM) COVID-19 Test is intended for use by qualified and trained clinical laboratory personnel specifically instructed and trained in the techniques of *in vitro* diagnostic procedures. The FloodLAMP QuickColor(TM) COVID-19 Test is only for use under the Food and Drug Administration’s Emergency Use Authorization.

## Principles of Procedure
The FloodLAMP QuickColor(TM) COVID-19 Test is an RNA-extraction free isothermal RT-LAMP assay that indicates the presence of the SARS-CoV-2 viral RNA with a simple visual color change. It can widely and rapidly be scaled because 1) no special instrumentation of any kind is required, neither nucleic acid extraction equipment nor a RT-PCR instrument, 2) it utilizes reagents and supplies readily available in large quantities, and 3) is a very straightforward protocol with minimal steps that can be executed quickly and reliably. It also utilizes the same streamlined sample preparation as the FloodLAMP EasyPCR(TM) Test which is also a supply chain robust, open source protocol test. Together the two tests can be used in an integrated program for screening and rapid confirmation in large populations by a broad range of laboratories. 

The FloodLAMP QuickColor(TM) COVID-19 Test uses a set of specific primers that target ORF1ab, N and E genes for the detection of SARS-CoV-2 RNA. Loop Mediated Isothermal Amplification (LAMP) is a nucleic acid amplification technique wherein DNA amplification is carried out at a constant temperature of approximately 65°C. Samples are first treated with a TCEP-based Inactivation Solution followed by a heat inactivation step. The resulting inactivated sample is directly used as input in the LAMP reaction. The amplification reaction mix includes a reverse transcriptase (RT) polymerase to create complementary cDNA from RNA. The cDNA is subsequently amplified by a high strand displacement DNA polymerase. The amplified DNA products lower the pH of the reaction. A phenol red pH indicating dye is included in the amplification reaction mix, thus causing the reaction solution to visibly change from an initial bright pink to a bright yellow when sufficient amplification occurs. Reactions that change color to yellow indicate that SARS-CoV-2 RNA is present.

## Materials Provided and Storage
The FloodLAMP QuickColor(TM) COVID-19 Test utilizes standard chemicals available from multiple vendors, with the exception of the LAMP primers and Colorimetric LAMP master mix. Designated CLIA labs may order components directly from vendors.

## Materials Required but Not Provided
The FloodLAMP QuickColor(TM) COVID-19 Test is to be used with the reagents or equivalents listed in Table 1. No specialized instruments are needed. Only ordinary laboratory equipment such as pipettes, centrifuges, and heaters are needed.

#### Table 1: Validated reagents used with the Test
| Item | Concentration | Chemical Composition | Vendor | Catalog Number |
| :---- | :---: | :---- | :---- | :---- |
| TCEP | .5 M | tris(2-carboxyethyl)phosphine hydrochloride | Sigma-Aldrich Millipore Sigma | 646547-10X1ML |
| EDTA | .5 M | Ethylenediaminetetraacetic acid | Thermo Fisher | 15575020 |
| NaOH | 10 N | Sodium Hydroxide | Sigma-Aldrich | SX0607N-6 |
| Nuclease-free Water | - | Ultrapure Water, nuclease-free | Thermo Fisher | 10977015 |
| NaCl | 5 M | Sodium Chloride | Thermo Fisher | 24740011 |
| Guanidine HCl | 6 M | Guanidine Hydrochloride | Sigma-Aldrich | SRE0066 |
| Colorimetric LAMP MM\* | - | Colorimetric LAMP Master Mix | New England Biolabs | M1804 |
||

\* Item may not be substituted for equivalent. Only the specified vendor and catalog number may be utilized.

The FloodLAMP QuickColor(TM) COVID-19 Test uses 18 LAMP primers targeted for 3 different SARS-CoV-2 genes, with 6 primers for each target. All 18 primers are mixed together and are input into a single amplification reaction. Primer names and sequences are listed in Table 2. Primers may be purchased pre-blended from the vendor LGC Biosearch Technologies with the product names LAMP\_S2-As1e, LAMP\_S2-N2, LAMP\_S2-E1. Alternatively, primers may be purchased as individual custom oligos. Appropriate validation of primer mixes from custom oligos is required. See Primer Preparation below for more information. 

#### Table 2: Primer names and sequences
| Primer Name | Sequence (5’-3’) |
| :---- | :---- |
| **ORF1ab gene (AS1e)** |   |
| Orf1ab\_FIP | TCAGCACACAAAGCCAAAAATTTATTTTTCTGTGCAAAGGAAATTAAGGAG |
| Orf1ab\_BIP | TATTGGTGGAGCTAAACTTAAAGCCTTTTCTGTACAATCCCTTTGAGTG |
| Orf1ab\_F3 | CGGTGGACAAATTGTCAC |
| Orf1ab\_B3 | CTTCTCTGGATTTAACACACTT |
| Orf1ab\_LF | TTACAAGCTTAAAGAATGTCTGAACACT |
| Orf1ab\_LB | TTGAATTTAGGTGAAACATTTGTCACG |
| **N Gene (N2)** |   |
| N2\_FIP | TTCCGAAGAACGCTGAAGCGGAACTGATTACAAACATTGGCC |
| N2\_BIP | CGCATTGGCATGGAAGTCACAATTTGATGGCACCTGTGTA |
| N2\_F3 | ACCAGGAACTAATCAGACAAG |
| N2\_B3 | GACTTGATCTTTGAAATTTGGATCT |
| N2\_LF | GGGGGCAAATTGTGCAATTTG |
| N2\_LB | CTTCGGGAACGTGGTTGACC |
| **E Gene (E1)** |   |
| E1\_FIP | ACCACGAAAGCAAGAAAAAGAAGTTCGTTTCGGAAGAGACAG |
| E1\_BIP | TTGCTAGTTACACTAGCCATCCTTAGGTTTTACAAGACTCACGT |
| E1\_F3 | TGAGTACGAACTTATGTACTCAT |
| E1\_B3 | TTCAGATTTTTAACACGAGAGT |
| E1\_LF | CGCTATTAACTATTAACG |
| E1\_LB | GCGCTTCGATTGTGTGCGT |
||

### Standard Lab Equipment and Consumables
* 70% ethanol  
* 10% bleach, prepared daily  
* 96-well PCR reaction plates (Applied Biosystems \# 4346906, 4366932, 4346907, Eppendorf \# 951020303 or equivalent)  
* Optical strip caps (Applied Biosystems \# 4323032 or equivalent)  
* Optical plate seal (Applied Biosystems \# 4311971 or equivalent)  
* PCR strip tubes and caps (USA Scientific catalog \# 1402-2500 or equivalent)   
* 5 mL transport tubes or equivalent (sterile)  
* 1.5 mL microcentrifuge tubes or equivalent (nuclease-free)  
* Aerosol resistant micropipette tips (nuclease-free)  
* Micropipettes (calibrated)  
* Bottle top dispenser for 1 mL volume (optional, calibrated)  
* 96-well cold block  
* Cold blocks for 5 mL and 1.5 mL \- 2.0 mL tubes, or ice  
* Vortex mixer  
* 96-well plate centrifuge or equivalent  
* Mini centrifuge for 1.5 mL tubes or equivalent  
* 2 x Thermal cycler, water bath, dry heat bath or equivalent (calibrated)  
* Class II Biological Safety Cabinet (BSC) 

## Warnings and Precautions
Materials or chemicals required for the use of the FloodLAMP QuickColor(TM) COVID-19 Test should be closely examined by the user. The user should carefully read all warnings, instructions or Safety Data Sheets provided by the supplier and follow the general safety precautions when handling biohazards, chemicals and other materials. 

### General Precautions
* The FloodLAMP QuickColor(TM) COVID-19 Test is for *in vitro* diagnostic use (IVD) only. Rx Only.  
* For use under COVID-19 Emergency Use Authorization Only.  
* Standard precautions and procedures should be taken when handling and disposing of human samples.  
* This test has not been FDA cleared or approved; the test has been authorized by FDA under an Emergency Use Authorization (EUA) for use by laboratories certified under the Clinical Laboratory Improvement Amendments (CLIA) of 1988, 42 U.S.C. §263a, to perform high complexity tests.  
* This test has been authorized only for the detection of nucleic acid from SARS-CoV-2, not for any other viruses or pathogens.  
* This test is only authorized for the duration of the declaration that circumstances exist justifying the authorization of emergency use of *in vitro* diagnostic tests for detection and/or diagnosis of COVID19 under Section 564(b)(1) of the Act, 21 U.S.C. § 360bbb-3(b)(1), unless the authorization is terminated or revoked sooner.  
* Standard precautions and procedures should be taken when handling and extracting human samples.  
* Standard precautions and procedures should be taken when using laboratory equipment.  
* Standard precautions and procedures should be taken when disposing of waste.  
* Dispose of reagents according to local regulations.  
* Do not use reagents after their recommended stability time frame.  
* Ensure reagents are stored at the recommended temperatures as described below and in the vendor product information and manuals.

### Contamination Precautions
* Avoid contamination by following good laboratory practices, wearing proper personal protective equipment, segregating workflow, and decontaminating workspace appropriately.  
* Ensure that surfaces and equipment used for all test steps have been properly cleaned with 10% bleach and 70% ethanol.  
* Ensure all consumables are DNase and RNase free except for sample collection tubes which may be sterile.  
* Use only calibrated pipettes and filter tips that are sterile and PCR clean.  
* After completion of the test, dispose of the amplification reaction plates or tubes. **Do not open tubes** or remove the seals on plates after heating amplification reactions.

## Limitations
* The use of this assay as an *in vitro* diagnostic under the FDA COVID-19 Emergency Use Authorization (EUA) is limited to laboratories that are certified under the Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. § 263a, to perform high complexity tests by Rx only.   
* Use of this assay is limited to personnel who are trained in the procedure. Failure to follow these instructions may lead to erroneous results.   
* The performance of the FloodLAMP QuickColor(TM) COVID-19 Test was established using Nasopharyngeal Swab specimen type collected in saline. Nasal swabs, oropharyngeal swabs, mid-turbinate nasal swabs specimens are also considered acceptable specimen types for use with the test but performance has not been established.   
* Samples must be collected according to recommended protocols and transported and stored as described herein.  
* Samples should not be collected in UTM or VTM or Liquid Amies transport media.  
* The effect of vaccines, antiviral therapeutics, antibiotics, chemotherapeutic or immunosuppressant drugs have not been evaluated.  
* Detection of SARS-CoV-2 RNA may be affected by sample collection methods, patient factors (e.g., presence of symptoms), and/or stage of infection.  
* False-positive results may arise from various reasons, including, but not limited to the following:  
  * Contamination during specimen collection, handling, or preparation  
  * Contamination during assay preparation  
  * Incorrect sample labeling  
* False-negative results may arise from various reasons, including, but not limited to the following:  
  * Improper sample collection or storage  
  * Degradation of SARS-CoV-2 RNA  
  * Presence of inhibitory substances  
  * Use of extraction reagents or instrumentation not approved with this assay   
  * Incorrect sampling window  
  * Failure to follow instructions for use  
  * Mutations In SARS-CoV-2 target sequences  
* Nucleic acid may persist even after the virus is no longer viable.   
* This test cannot rule out diseases caused by other bacterial or viral pathogens.  
* Performance has not yet been established in asymptomatic individuals and will be established during a post-authorization study.   
* Use of the test in a general, asymptomatic population for serial screening is intended to be used as part of an infection control plan, that may include additional preventative measures, such as a predefined serial testing plan or directed testing of high-risk individuals. Negative results should not be treated as definitive and do not preclude current or future infection obtained through community transmission or other exposures. Negative results must be considered in the context of an individual’s recent exposures, history, and presence of clinical signs and symptoms consistent with COVID-19.  
* This test should not be used within 30 minutes of administering nasal or throat sprays.  
* Positive results must be reported to appropriate public health authorities, following state and national guidelines.   
* The clinical performance of the test has not been established in all circulating variants, and test performance may vary depending on the prevalence of variants circulating at the time of patient testing.   
* Negative test results do not exclude possibility of exposure to or infection with SARS-CoV-2 virus. Patient handling will be directed by healthcare professionals.

## Conditions of Authorization for the Laboratory
The FloodLAMP QuickColor(TM) COVID-19 Test Letter of Authorization, along with the authorized Fact Sheet for Healthcare Providers, the authorized Fact Sheet for Patients, and authorized labeling are available on the FDA website: [https://www.fda.gov/medical-devices/coronavirus-disease-2019-covid-19-emergency-use-authorizations-medical-devices/vitro-diagnostics-euas](https://www.fda.gov/medical-devices/coronavirus-disease-2019-covid-19-emergency-use-authorizations-medical-devices/vitro-diagnostics-euas)

However, to assist clinical laboratories running the FloodLAMP QuickColor(TM) COVID-19 Test, the relevant Conditions of Authorization are listed below:

* Authorized laboratories1 using the FloodLAMP QuickColor(TM) COVID-19 Test will include all authorized Fact Sheets with test result reports. Under exigent circumstances, other appropriate methods for disseminating these Fact Sheets may be used, which may include mass media.  
* Authorized laboratories1 using the FloodLAMP QuickColor(TM) COVID-19 Test will use the FloodLAMP QuickColor(TM) COVID-19 Test as outlined in the FloodLAMP QuickColor(TM) COVID-19 Test Instructions for Use. Deviations from the authorized procedures, including the authorized clinical specimen types, authorized control materials, authorized other ancillary reagents and authorized materials required to perform the test are not permitted.  
* Authorized laboratories must notify the relevant public health authorities of their intent to run the test prior to initiating testing.  
* Authorized laboratories using the FloodLAMP QuickColor(TM) COVID-19 Test will have a process in place for reporting test results to healthcare providers and relevant public health authorities, as appropriate.  
* Authorized laboratories will collect information on the performance of the test and report to DMD/OHT7-OIR/OPEQ/CDRH (via email: CDRH-EUA-Reporting@fda.hhs.gov) and FloodLAMP Biotechnologies, PBC support center (via email: eua.support@floodlamp.bio) any suspected occurrence of false positive or false negative results and significant deviations from the established performance characteristics of the test of which they become aware.  
* All laboratory personnel using the test must be appropriately trained in molecular assay techniques and use appropriate laboratory and personal protective equipment when handling these test components, and use the test in accordance with the authorized labeling.  
* FloodLAMP Biotechnologies, PBC authorized distributors, and authorized laboratories using the FloodLAMP QuickColor(TM) COVID-19 Test will ensure that any records associated with this EUA are maintained until otherwise notified by FDA. Such records will be made available to FDA for inspection upon request. 

1 For ease of reference, this will refer to, “Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. §263a certified laboratories with FDA Emergency Use Authorization FDA for performing SARS-CoV-2 testing

## Specimen Collection and Storage
Upper respiratory specimens including nasopharyngeal swabs, anterior nasal and mid-turbinate nasal swabs should be collected using standard procedures and recommendations. Swab specimens should be collected in 0.9% saline, PBS, or dry tubes. Specimens should not be collected in UTM, VTM, or Liquid Amies.

Please refer to Interim Guidelines for Collecting, Handling, and Testing Clinical Specimens for COVID-19:  
[https://www.cdc.gov/coronavirus/2019-ncov/lab/guidelines-clinical-specimens.html](https://www.cdc.gov/coronavirus/2019-ncov/lab/guidelines-clinical-specimens.html)

The stability study of the nasal swab sample transported in saline has been conducted by Quantigen Biosciences, with support from The Gates Foundation and UnitedHealth Group. Quantigen Biosciences has granted a right of reference to any sponsor wishing to pursue an EUA to leverage their COVID-19 swab stability data as part of that sponsor’s EUA request.

* Samples can be stored at room temperature for 56 hours after collection prior to inactivation.   
* For longer term storage, samples can be stored at ≤-70oC.

Note: Specimens must be packaged, shipped, and transported according to the current edition of the International Air Transport Association Dangerous Goods Regulation. Follow shipping regulations for UN 3373 Biological Substance, Category B when sending potential 2019-nCoV specimens.

## Running Tests
### Reagent Preparation
The FloodLAMP QuickColor(TM) COVID-19 Test is to be used with the reagents or equivalents listed in Table 1. 

#### Table 1: Validated reagents used with Test
| Item | Concentration | Chemical Composition | Vendor | Catalog Number |
| :---- | :---: | :---- | :---- | :---- |
| TCEP | .5 M | tris(2-carboxyethyl)phosphine hydrochloride | Sigma-Aldrich Millipore Sigma | 646547-10X1ML |
| EDTA | .5 M | Ethylenediaminetetraacetic acid | Thermo Fisher | 15575020 |
| NaOH | 10 N | Sodium Hydroxide | Sigma-Aldrich | SX0607N-6 |
| Nuclease- free Water | - | Ultrapure Water, nuclease-free | Thermo Fisher | 10977015 |
| NaCl | 5M | Sodium Chloride | Thermo Fisher | 24740011 |
| Guanidine HCl | 6M | Guanidine Hydrochloride | Sigma-Aldrich | SRE0066 |
| Colorimetric LAMP MM\* | - | Colorimetric LAMP Master Mix | New England Biolabs | M1804 |
||

\* Item may not be substituted for equivalent. 

Stocks of TCEP, EDTA, NaOH, and NaCl may be prepared from powder form at the specified concentration using nuclease-free, MilliQ or equivalent molecular biology grade water.

0.9% Saline (154 mM) may be prepared by diluting 15.4 mL of 5 M NaCl in MilliQ or equivalent molecular biology grade water to a final volume of 500 mL. Equivalent preparations or commercial saline products may be utilized, with appropriate validation.

A 100X Inactivation Solution is prepared by mixing the components in Table 3 and vortexing for 30 seconds. Equivalent preparations utilizing components with different source concentrations may be used such that the final 100X Concentration is achieved. Aliquots of 100X Inactivation Solution should be stored in the dark at \-20°C for up to 3 months. Upon thaw, working aliquots of 100X Inactivation Solution should be stored in the dark at room temperature for up to 1 month. 

#### Table 3: 100X Inactivation Solution
| Component | Source Concentration | Volume | 100X Concentration |
| :---- | :---: | :---: | :---: |
| TCEP | 0.5 M | 10 mL | 250 mM |
| EDTA | 0.5 M | 4 mL | 100 mM |
| NaOH | 10 N | 2.3 mL | 1.15 N |
| Nuclease-free Water | - | 3.7 mL | - |
| **TOTAL VOLUME** | - | **20 mL** | - |
||

Swabs that are collected or eluted in 0.9% saline solution or equivalent, the 100X Inactivation Solution should be added at 1/100th the sample solution volume.

For dry swabs, a preparation of 1X Inactivation Saline Solution should be prepared per Table 4. 1X Inactivation Saline Solution should be kept at room temperature and used within 24 hours of preparation from components or 100X Inactivation Solution.

#### Table 4: 1X Inactivation Saline Solution
| Component | Volume |
| :---- | :---: |
| 0.9% Saline (154 mM NaCl) in MilliQ Water | 1000 mL |
| 100X Inactivation Solution | 10 mL |
| **TOTAL VOLUME** | **1010 mL** |
||

### Controls Preparation
**One positive and one negative control** will be included on every 96-well plate with up to 94 samples, or with every batch of strip tubes on each heater:

1) A “no template” (negative) control (NTC) is needed to **assure the absence of cross contamination from positive samples, positive controls, or amplicons** and is used **to determine if sample results are valid.** **It consists of 100X Inactivation Solution diluted to 1X in 0.9% saline. This NTC is the same solution added to dry swabs (see Table 3 and Table 4 above for the components).**  
     
2) A positive template control is needed to **assure proper functioning of reagents and the absence of significant RNAse contamination. It consists of synthetic viral RNA at a concentration of approximately 100,000 cp/mL diluted in total human RNA and nuclease-free water.** Stock and working aliquots of the positive control are produced from the sources listed in Table 5 or equivalents. Working aliquots should be diluted prior to use to 100,000 cp/mL. Positive control aliquots should be stored for at most 3 months at \-80°C, or at most 1 month at \-20°C.   
   
#### Table 5: Components for Positive Template Control
| Material | Vendor | Catalog \# | Volume |
| ----- | :---: | :---: | :---: |
| SARS-CoV2 Positive Control RNA | Twist | 102019 | 5 µl |
| Total Human RNA | Thermo Fisher | 4307281 | 100 µl |
| Nuclease-free Water | Thermo Fisher | 10977015 | 4,895 µl |
||

### 10X LAMP Primer Mix Preparation
The FloodLAMP QuickColor(TM) COVID-19 Test uses 18 LAMP primers targeted for 3 different SARS-CoV-2 genes, with 6 primers for each target. Primer names and sequences are shown above in Table 2. All 18 primers are mixed together and input into a single amplification reaction. 

Primers may be purchased from the vendor LGC Biosearch Technologies as 3 pre-blended sets, or the primers may be purchased as 18 individual custom oligos. Table 6 below lists the primer products to be ordered.   
   
The LGC Biosearch primer products are provided already blended for each target (6 primers per tube) and dried such that upon resuspension with 1 mL of nuclease water, the primers for each target are at 30X concentration. One resuspended tube for each of the 3 targets (i.e. primer blends) are mixed together to yield a 3 mL total volume that contains all individual primers at 10X concentration. This 3 mL of 10X LAMP Primer Mix provides for 1,200 reactions at 2.5 µL per reaction.  
   
Alternatively to the pre-blended LGC Biosearch products, primers may be purchased as individual custom oligos. Custom oligos may be blended to form 30X Primer Set Mixes as intermediates or all mixed together for the 10X LAMP Primer Mix. The FIP and BIP primers for each target require purification by HPLC or an equivalent process. Appropriate validation of primer mixes from custom oligos is required. Primers may be stored at 4°C for up to one month, or at \-20°C for up to 1 year.

#### Table 6: 10X LAMP Primer Mix Components
| Vendor | Item | Catalog number | Quantity | # Reactions |
|---------|------|----------------|-----------|-------------|
| Order one of the following primer sets |||||
| LGC Biosearch Technologies | SARS-CoV-2 LAMP AS1e 6 primer set at 30X (ORF1ab gene) | LAMP_S2-AS1e-48 | 6-48 nmol | 1,200 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP AS1e 6 primer set at 30X (ORF1ab gene) | LAMP_S2-AS1e-480 | 60-480 nmol | 12,000 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP N2 6 primer set at 30X (N gene) | LAMP_S2-N2-48 | 6-48 nmol | 1,200 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP N2 6 primer set at 30X (N gene) | LAMP_S2-N2-480 | 60-480 nmol | 12,000 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP E1 6 primer set at 30X (E gene) | LAMP_S2-E1-48 | 6-48 nmol | 1,200 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP E1 6 primer set at 30X (E gene) | LAMP_S2-E1-480 | 60-480 nmol | 12,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orflab_FIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orflab_BIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orflab_F3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orflab_B3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orflab_LF | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orflab_LB | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_FIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_BIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_F3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_B3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_LF | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_LB | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_FIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_BIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_F3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_B3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_LF | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_LB | Custom Order | 250 nmol | 25,000 |
||

### Sample Preparation
\* For wet swab specimens (swabs in saline or unprocessed swab elution): 

1) If samples are frozen, thaw unless no ice crystals are present and then keep on ice, cold block or at 4°C.   
2) Pulse vortex each sample and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.   
3) Wipe the outside of the sample tube with 70% ethanol. 

For dry swab specimens:

1) Wipe the outside of the sample tube with 70% ethanol. 

### Sample Inactivation
1) Place the inactivation heater (a thermal cycler, water bath, dry heat bath or equivalent) in the BSC, turn on, and set the temperature to hold at 100 °C.  
2) \* For wet swab specimens: transfer 1 mL or available volume of each sample to an appropriately labeled 1.5 mL or 5mL tube and securely cap.   
3) \* For wet swab specimens: add 10μL per 1 mL sample volume of 100X Inactivation Solution to each sample tube.  
4) For dry swab specimens (DO NOT DO FOR WET SWAB SPECIMENS): add 1 mL of 1X Inactivation Solution to each sample tube.  
5) Vortex for 30 seconds.  
6) Place sample tubes into the inactivation heater for 8 minutes.  
7) Remove sample tubes from the inactivation heater and let cool at room temperature for 10 minutes.  
8) Place sample tubes on ice, in the refrigerator, or on a cold block at 4°C until ready to perform amplification reaction. 

Note: Testing of inactivated specimens must be conducted the same day inactivation is performed. For long term storage, keep the original specimen at ≤-70°C. 

### Colorimetric LAMP Amplification Reaction Preparation
1) Place a 96-well PCR plate or PCR strip tubes onto a cold block or ice.  
2) Thaw frozen reagents until ice crystals are not present.   
3) Pulse vortex thawed reagents and briefly spin down in a centrifuge.   
4) Store on ice, in the refrigerator, or on a cold block at 4°C until ready to use.  
5) Combine components of Primer-Guanidine Solution per volumes listed in Table 7, or proportionally scaled for the number of reactions to be run. 

      NOTE: Component volumes should be scaled proportionally for the number of reactions.   
      NOTE: The Primer-Guanidine Solution may be prepared in advance and stored at \-20°C    
      for up to 1 month.

6) Pulse vortex and briefly spin down in a centrifuge.   
7) Prepare the Colorimetric LAMP Amplification Reaction Mix by adding the Colorimetric LAMP MM to the Primer-Guanidine Solution per the volumes listed in Table 8.   
8) Vortex the Colorimetric LAMP Amplification Reaction Solution for 10 seconds and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.  
9) Add 23 µL of the Colorimetric LAMP Amplification Reaction Solution into the wells of the PCR plate or PCR strip tubes.

NOTE: Reaction plates/strip tubes comprising the Colorimetric LAMP Amplification Reaction Solution may be prepared in advance, capped/sealed, and stored at \-20°C for up to 3 days prior to addition of the sample. A heated plate sealer may be used to seal plates. Alternatively, a manually applied foil or optical seal may be used.

#### Table 7: Primer-Guanidine Solution
| Component | Volume (1 reaction) | Volume (1 reaction x 100) 1 x 96-plate w/ 4% overage |
| ----- | :---: | :---: |
| 10X LAMP Primer Mix | 2.5 µL | 250 µL |
| Guanidine HCl (400 mM) | 2.5 µL | - |
| Guanidine HCl (6 M) | - | 16.7 µL |
| Nuclease-free Water | 5.5 µL | 783 µL |
| **TOTAL VOLUME** | **10.5 µL** | **1050 µL** |
||

#### Table 8: Colorimetric LAMP Amplification Reaction
| Component | Volume (1 reaction) | Volume (100 reactions) |
| ----- | :---: | :---: |
| Primer-Guanidine Solution | 10.5 µL | 1050 µL |
| Colorimetric LAMP MM | 12.5 µL | 1250 µL |
| **SUBTOTAL VOLUME** | **23 µL** | **2300 µL** |
| Sample | 2 µL | - |
| **REACTION VOLUME** | **25 µL** | - |
||

### Sample Addition and Heating
NOTE: Ensure that positive and negative controls are included in each batch run (i.e. in each PCR plate or group of strip tubes that are heated together).

1) Turn on the amplification heater (a thermal cycler, water bath, dry heat bath or equivalent) and set the temperature to hold at 65°C.

NOTE: Amplification heater should be located in a separate, dedicated BSC or area of the lab. Proper cross contamination prevention practices are required, such as glove changes, to prevent amplicon contamination.

2) Add 2 μL of each sample into a separate tube in the amplification reaction PCR plate or strip tubes.   
3) Mix by pipetting.  
4) If using PCR plate, seal with foil seal, optical seal (optionally using heat sealer). If using PCR strip tubes, cap strips.  
5) Pulse vortex and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.  
6) Place the plate or strip tubes in the heater and set timer for 25 minutes (do not use heated lid).  
7) Remove the plate or strip tubes from the heater after 25 minutes.  
8) Let cool for 1 minute and then interpret the test results.

### Test Controls
All test controls should be examined prior to interpretation of patient specimen results. If the controls are not valid and the expected result, the specimen results cannot be interpreted. An example of the expected appearance of the negative and positive controls after amplification is shown in Figure 1.

**![][image1]![][image2]**

#### Figure 1. Negative control (left) and positive control (right) after amplification.

If the negative and positive controls do not appear as expected, the specimen results of the corresponding plate or batch should be considered invalid. In the event of a failure of either the positive or negative control, the lab should discard some or all of the consumables utilized for associated run, including the filter tips, tubes, plates, seals, and aliquots of reagents. Additionally, all pipettes, BSC, and appropriate lab surfaces should be thoroughly cleaned with freshly made 10% bleach solution, 70% ethanol, and optionally RNAseZAP product. In the event of the failure of the positive control, the working aliquot of positive control material should be discarded. Additionally, the lab should review the expiration of the batch of positive control aliquots and verify their integrity by performing qualification reactions of one or more positive control aliquots. If controls continue to fail, labs should not perform additional tests on clinical specimens or report results. Invalid test results should be repeated by performing another amplification reaction.

### Patient Specimen Results Interpretation
NOTE: Results can only be interpreted if the positive and negative controls in the plate or group of strip tubes have the expected results.

Test results should be read at least 1 minute and no more than 8 hours after plates or tubes have been removed from heat. Test results may be determined directly from visual inspection of the color of the reaction tubes: 

* yellow \- result is positive  
* bright pink or red \- result is negative  
* any other color \- result is invalid. 

Examples are shown below in Figure 2. Edge cases for positive and negative results are shown below in Figure 3. Any color variance stronger than the edge cases should be interpreted as inconclusive. In order to reduce the chance of both false negative and false positive results, this window for color variance is intentionally set to be small.

If the initial test is inconclusive, then one of the following should be performed:  
1) repeat the LAMP Amplification Reaction on the inactivated sample. If the repeat test has a positive result then the final interpretation of the test is positive. If the repeat test has a negative or another inconclusive result, then the final interpretation is inconclusive.  
2) follow up test the inactivated sample with the FloodLAMP EasyPCR(TM) COVID-19 Test or another high sensitivity EUA authorized test that comprises the same inactivation protocol. The final interpretation is the result of the follow up test.

For serial screening of individuals without symptoms or other epidemiological reasons to suspect COVID-19 infection, the initial inconclusive test result may be considered the final interpretation.

If the final interpretation of the test result is inconclusive, then "Inconclusive" should be reported and retesting of the individual is recommended. 

| ![][image3] |                  ![][image4]![][image5] |
| :---- | :---- |
| **Figure 2. Example of Test Results  (Left 2 Negative, Right 2 Positive)** |                         **Figure 3. Edge Case Test Results                          (Left Negative, Right Positive)** |

## Performance Evaluation
### Analytical Sensitivity: Limit of Detection (LoD)
The Limit of Detection (LoD) for the FloodLAMP QuickColor(TM) COVID-19 Test was established using gamma-irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) spiked into negative real specimens. The negative specimens were confirmed by PCR using the CDC primers. The gamma-irradiated virus was spiked into the specimen prior to the heat inactivation step, and carried through the entire assay. The concentration of spike was such that the contrived positive sample was at 100,000 copies/mL after the inactivation step. The stock contrived positive was diluted into inactivated negative sample matrix to produce the concentrations for the LoD study. A preliminary LoD run was performed using the concentrations ranging from 100,000 copies/mL to 3,100 copies/mL. Concentrations of 12,500 and 6,250 were selected for confirmatory LoD runs. LoD run details are provided in Supporting Data, with the results summarized below in Table 9. The LoD, defined as the concentration at which at least 95% of the samples are positive, was determined at 12,500 copies/mL.

#### Table 9: LoD Confirmatory Data Results
| Concentration of Contrived Positive Sample  | Replicates Detected |
| :---: | :---: |
| 12,500 copies/mL | 95% (20/21) |
| 6,250 copies/mL | 52% (11/21) |
||

### Analytical Sensitivity: Inclusivity (*in silico*)
An inclusivity study was conducted for the ORF1ab, N2, and E1 primer sets against all complete, high coverage SARS-CoV-2 sequences deposited at GISAID as of February 27, 2021. Table 10 summarizes the results of this *in silico* inclusivity analysis. A total of 498,224 sequences were considered. There are 10 sequence isolates that have 1mm to both As1e and E1 and had N2 excluded due to greater than 15 N's, with the other 498,214 sequence isolates all have at least 1 target region that is a complete match.

Each primer set matched at 100% similarity against the SARS-CoV-2 RefSeq reference genome (Wuhan-Hu-1; NC\_045512.1). All three primer sets differed by one or fewer mutations for 99.7% of GISAID sequences, indicating nominal primer hybridization for all SARS-CoV-2 variants under consideration.	

#### Table 10: *In Silico* Inclusivity Analysis for LAMP Primers
| Primer | AS1e  (ORF1ab gene) |  | N2  (N gene) |  | E1  (E gene) |  |
| :---- | ----- | ----- | ----- | ----- | ----- | ----- |
| **Total Primer Length** | 195 |  | 169 |  | 168 |  |
| **Total \# of Strains Evaluated** | 498,224 |  | 498,224 |  | 498,224 |  |
| **100% Match** | 474,717 | 95.3% | 479,548 | 96.3% | 462,538 | 92.8% |
| **1 Mismatch** | 19,301 | 3.9% | 15,698 | 3.2% | 30,626 | 6.1% |
| **2 Mismatches** | 338 | 0.1% | 161 | 0.0% | 1,455 | 0.3% |
| **3 Mismatches** | 9 | 0.0% | 5 | 0.0% | 103 | 0.0% |
| **\> 3 Mismatches** | 0 | 0.0% | 0 | 0.0% | 1 | 0.0% |
| **Total Strains Removed** | 3,859 | 0.8% | 2,812 | 0.6% | 3,501 | 0.7% |
||

### Evaluation of Impact of Viral Mutations
The As1e, E1 and N2 primer regions of all SARS-CoV-2 genomes present in GISAID as of 2/26/2021 were evaluated to assess the potential impact of genomic variants on LAMP primer binding. This analysis was performed with the Primer Monitoring Tool from New England Biolabs ([primer-monitor.neb.com](http://primer-monitor.neb.com)), which continually monitors registered primer sets for overlapping variants in sequences from GISAID. Results are summarized by region and locus below in Table 11, including the 30 countries with most sequences in GISAID. Sequences were aligned to the SARS-CoV-2 reference sequence (NC\_045512.2) using minimap2 (minimap2 \-t 16 \-x asm5 \-a). Variant sites (excluding Ns) were identified using samtools mpileup and summarized by region and genome position. Genomic positions having \>= 40 global variant observations are shown (column labels). When present, box labels indicate the fraction of variants observed at a given locus.

The aggregate of current published mutations are not expected to reduce performance of the FloodLAMP QuickColor(TM) COVID-19 Test by more than 5% from that established by the performance evaluation in this EUA submission. Further, the use of 3 primer sets targeting different regions in the SARS-CoV-2 genome should make the test robust to new genetic variants.

#### Table 11: Variant Analysis of LAMP Primers
![][image6]  
![][image7]

### Analytical Specificity: Cross-Reactivity (*in silico*)
*In silico* cross-reactivity analysis was performed by aligning the primer sequences of the FloodLAMP QuickColor(TM) COVID-19 Test against sequences of other coronaviruses and common respiratory flora using the BLASTn alignment tool from NCBI. Results of this analysis are presented in Tables 12A, 12B, and 12C. 

The % identity range (\# identical bases/ \# primer bases) is shown for each primer and organism. Darker font indicates % identity greater than 80%. Organisms with \>= 50% identity primer hits are shown. This analysis is not intended to predict amplification. Near perfect homology across B3, F3, FIP and BIP is necessary to support successful amplification. With the exception of SARS-CoV, simultaneous homologies do not occur between any of the primers and microorganisms screened. With respect to clinical relevance of the *in silico* cross-reactivity analysis, there are no known circulating strains of SARS-CoV circulating in humans, thus the overall probability for the test to produce a cross-reactive signal is negligible.

#### Table 12A: *In Silico* Cross-Reactivity Analysis for AS1e Primers

![][image8]

#### Table 12B: In Silico Cross-Reactivity Analysis for N2 Primers

![][image9]

#### Table 12C: *In Silico* Cross-Reactivity Analysis for E1 Primers

![][image10]

### Analytical Specificity: Cross-Reactivity (*wet testing*)
Wet testing was performed to demonstrate that the FloodLAMP QuickColor(TM) COVID-19 Test does not react with related pathogens, high prevalence disease agents and normal or pathogenic flora that are reasonably likely to be encountered in a clinical specimen.  SARS-CoV, RSV, Flu, Human Metapneumovirus. and Streptococcus Salivarius were tested for potential cross-reactivity, as shown in Table 13. Gamma-irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) was spiked onto dried AN swab specimens to produce contrived Positve Controls. Negative Control dried swabs obtained simultaneously were confirmed to be SARS-CoV-2 negative by PCR using the CDC primers. The gamma-irradiated SARS-CoV-2 virus and cross-reactivity organisms were spiked into the dried swabs prior to the heat inactivation step, and carried through the full test protocol. 

All wet testing showed no cross-reactivity with the viral pathogens and common respiratory flora, as shown in Table 13.

#### Table 13: Wet Testing Cross-Reactivity Results
| Organism | Description | BEI Number | Detected Replicates |
| ----- | ----- | :---: | :---: |
| SARS-CoV | UV-inactivated virus | NR-3882 | 0/3 |
| Human Metapneumovirus | Genomic RNA | NR-49122 | 0/3 |
| RSV | Genomic RNA | NR-43976 | 0/3 |
| Influenza B | Genomic RNA | NR-45848 | 0/3 |
| Streptococcus salivarius | Bacterial cell culture | HM-121 | 0/3 |
||

### Analytical Specificity: Interfering Substances
Exogenous and endogenous substances were tested for potential interference with the FloodLAMP QuickColor(TM) COVID-19 Test. Gamma-irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) was spiked onto dried AN swab specimens to produce contrived Positve Controls. Negative Control dried swabs obtained simultaneously were confirmed to be SARS-CoV-2 negative by PCR using the CDC primers. The gamma-irradiated SARS-CoV-2 virus and interfering substances were spiked into the dried swabs prior to the heat inactivation step, and carried through the full test protocol. 

All interfering substance testing showed no disagreement with expected positive and negative results, as shown in Table 14 and Supporting Data.

#### Table 14: Interfering Substances Results
| Interfering Substance | Active Ingredient | Concentration | % Agreement with Expected Results |  |
| :---: | :---: | :---: | :---: | :---: |
|  |  |  | **Positive Control Spiked** | **Negative Control Unspiked** |
| Blood | N/A | 1% v/v | 100% (3/3) | 100% (3/3) |
| Nasal Congestion Spray | Acetaminophen, Guaifenesin, Phenylephrine HCI | 20% v/v | 100% (3/3) | 100% (3/3) |
| Nasal Allergy Spray | Oxymetazoline HCl | 15% v/v | 100% (3/3) | 100% (3/3) |
| Lozenges | Menthol | 10% w/v | 100% (3/3) | 100% (3/3) |
| Mucin | N/A | 0.5% w/v | 100% (3/3) | 100% (3/3) |
||

## Clinical Evaluation
The clinical evaluation of the FloodLAMP QuickColor(TM) COVID-19 Test utilized confirmed clinical anterior nares swab specimens. 40 positive and 40 negative clinical specimens were evaluated and compared to a high sensitivity EUA authorized test run on the original fresh samples. The FloodLAMP QuickColor(TM) COVID-19 Test showed a positive agreement of 90% and a negative agreement of 100%. The 4 false negative results were specimens with high Ct values as previously measured by the comparator test, indicating low viral load. A summary of the clinical performance is below in Table 15. 

#### Table 15: Clinical Evaluation Results
| FloodLAMP QuickColor(TM) COVID-19 Test Results | Comparator \- High Sensitivity EUA Authorized Test |  |  |
| :---: | :---: | :---: | :---: |
|  | **Positive** | **Negative** | **Total** |
| Positive | 36 | 0 | 36 |
| Negative | 4 | 40 | 44 |
| Total | 40 | 40 | 80 |
| Positive Agreement | 90.0% (36/40) 95% CI: 76.3% to 97.2% |  |  |
| Negative Agreement | 100% (40/40) 95% CI: 91.2% to 100% |  |  |
||

## Support
FloodLAMP Biotechnologies, PBC support center   
eua.support@floodlamp.bio  
650-394-5233
