METADATA
last updated: 2026-03-05 by BA
file_name: 2021-03-26_Instructions for Use - FloodLAMP FLAMP COVID-19 Test NOT SUBMITTED.md
file_date: 2021-03-26
title: Instructions for Use - FloodLAMP FLAMP COVID-19 Test NOT SUBMITTED
category: regulatory
subcategory: fl-fda-submissions
tags: 
source_file_type: gdoc
xfile_type: docx
gfile_url: https://docs.google.com/document/d/1fsdl_yjBbAV7MnQiwihumJziZApkTa1IJ8RewS4qz-U
xfile_github_download_url: https://raw.githubusercontent.com/FocusOnFoundationsNonprofit/floodlamp-archive/main/regulatory/fl-fda-submissions/2021-03-26_Instructions%20for%20Use%20-%20FloodLAMP%20FLAMP%20COVID-19%20Test%20NOT%20SUBMITTED.docx
pdf_gdrive_url: https://drive.google.com/file/d/16kki-qqeTDNdmg-mscq5PByURqvKy3hC
pdf_github_url: https://github.com/FocusOnFoundationsNonprofit/floodlamp-archive/blob/main/regulatory/fl-fda-submissions/2021-03-26_Instructions%20for%20Use%20-%20FloodLAMP%20FLAMP%20COVID-19%20Test%20NOT%20SUBMITTED.pdf
conversion_input_file_type: gdoc
conversion: gdoc markdown
license: CC BY 4.0 - https://creativecommons.org/licenses/by/4.0/
tokens: 20466
words: 11985
notes: 
summary_short: The draft Instructions for Use for the FloodLAMP QuickFluor COVID-19 Test describe an extraction-free, fluorimetric RT-LAMP assay with real-time fluorescence detection on RT-PCR instruments following chemical and heat inactivation. It provides detailed procedures for reagent and primer preparation, instrument setup, workflow execution, controls, and Ct-based result interpretation for CLIA high-complexity laboratories. It also documents proposed analytical and clinical performance, including a 50,000 copies/mL LoD and 80–85% positive agreement with 100% negative agreement in an 80-specimen clinical evaluation, for a test that was not submitted for EUA.


CONTENT

***INTERNAL TITLE:*** FloodLAMP QuickFluor(TM) COVID-19 Test
Instructions for Use v1.0 \*\*DRAFT\*\*

IVD
COVID-19 Emergency Use Authorization Only
For *in vitro* diagnostic (IVD) Use

www.floodlamp.bio
FloodLAMP Biotechnologies, PBC | 930 Brittan Ave. San Carlos, CA 94070 USA

## Table of Contents
|  |  |
|---------|------|
| Intended Use | 3 |
| Principles of Procedure | 3 |
| Materials Provided and Storage | 4 |
| Materials Required but Not Provided | 4 |
| • Standard Lab Equipment and Consumables | 5 |
| Warnings and Precautions | 6 |
| • General Precautions | 6 |
| • Contamination Precautions | 7 |
| Limitations | 7 |
| Conditions of Authorization for the Laboratory | 8 |
| Specimen Collection and Storage | 9 |
| Running Tests | 10 |
| • Reagent Preparation | 10 |
| • Controls Preparation | 11 |
| • 10X LAMP Primer Mix Preparation | 12 |
| • Sample Preparation | 13 |
| • Sample Inactivation | 14 |
| • Preparing to Run Assay for the First Time | 14 |
| • Create the Plate Layout Map | 16 |
| • Fluorimetric LAMP Amplification Reaction Preparation | 18 |
| • Sample Addition | 19 |
| • Run the Assay | 19 |
| • Analyzing Data | 21 |
| • Results Interpretation | 22 |
| • Patient Specimen Results Interpretation | 22 |
| Performance Evaluation | 23 |
| • Analytical Sensitivity: Limit of Detection (LoD) | 23 |
| • Analytical Sensitivity: Inclusivity (*in silico*) | 23 |
| • Evaluation of Impact of Viral Mutations | 24 |
| • Analytical Specificity: Cross-Reactivity (*in silico*) | 26 |
| • Analytical Specificity: Cross-Reactivity (wet testing) | 30 |
| • Analytical Specificity: Interfering Substances | 31 |
| Clinical Evaluation | 32 |
| Support | 32 |
||

FloodLAMP QuickFluor(TM) COVID-19 Test  
For COVID-19 Emergency Use Authorization Only  
Instructions for Use

## Intended Use
FloodLAMP QuickFluor(TM) COVID-19 Test is a reverse transcriptase loop-mediated isothermal amplification (RT-LAMP) assay intended for the qualitative detection of RNA from SARS-CoV-2 in upper respiratory specimens including nasopharyngeal swabs, anterior nasal and mid-turbinate nasal swabs from individuals suspected of COVID-19 by their healthcare provider and from individuals without symptoms or other epidemiological reasons to suspect COVID-19 infection, when tested at a weekly interval with no more than 9 days between tests. Testing is limited to laboratories certified under the Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. §263a, to perform high complexity tests, or by similarly qualified non-U.S. laboratories. 

Results are for the identification of SARS-CoV-2 RNA. The SARS-CoV-2 RNA is generally detectable in upper respiratory specimens including nasopharyngeal swabs, anterior nasal and mid-turbinate nasal swabs during the acute phase of infection. Positive results are indicative of the presence of SARS-CoV-2 RNA; clinical correlation with patient history and other diagnostic information is necessary to determine patient infection status. Positive results do not rule out bacterial infection or co-infection with other viruses. The agent detected may not be the definite cause of disease. Laboratories within the United States and its territories are required to report all test results to the appropriate public health authorities.

Negative results do not preclude SARS-CoV-2 infection and should not be used as the sole basis for patient management decisions. Negative results must be combined with clinical observations, patient history, and epidemiological information.

The FloodLAMP QuickFluor(TM) COVID-19 Test is intended for use by qualified and trained clinical laboratory personnel specifically instructed and trained in the techniques of *in vitro* diagnostic procedures. The FloodLAMP QuickFluor(TM) COVID-19 Test is only for use under the Food and Drug Administration’s Emergency Use Authorization.

## Principles of Procedure
The FloodLAMP QuickFluor(TM) COVID-19 Test uses a set of specific primers that target ORF1ab, N and E genes for the detection of SARS-CoV-2 RNA. It uses Loop Mediated Isothermal Amplification (LAMP), a nucleic acid amplification technique wherein DNA amplification is carried out at a constant temperature of approximately 65°C. Samples are first treated with a TCEP-based Inactivation Solution followed by a heat inactivation step. The resulting inactivated sample is directly used as input in the LAMP reaction. The amplification reaction mix includes a reverse transcriptase (RT) polymerase to create complementary cDNA from RNA. The cDNA is subsequently amplified by a high strand displacement DNA polymerase. An intercalating fluorescent dye is also included in the reaction mix, enabling the real-time fluorescence detection of amplicons. An RT-PCR Instrument is utilized for the isothermal amplification incubation and real-time fluorescence readout.

## Materials Provided and Storage
The FloodLAMP QuickFluor(TM) COVID-19 Test utilizes standard chemicals available from multiple vendors, with the exception of the LAMP primers and Fluorimetric LAMP master mix. Designated CLIA labs may order components directly from vendors.

## Materials Required but Not Provided
The FloodLAMP QuickFluor(TM) COVID-19 Test is to be used with the reagents or equivalents listed in Table 1. The FloodLAMP QuickFluor(TM) COVID-19 Test is to be used with RT-PCR Instruments such as Applied Biosystems QuantStudio(TM) Systems and Bio-Rad CFX(TM) Systems.

#### Table 1: Validated reagents used with the Test
| Item | Concentration | Chemical Composition | Vendor | Catalog Number |
| :---- | ----- | :---- | :---- | :---- |
| TCEP | .5 M | tris(2-carboxyethyl)phosphine hydrochloride | Sigma-Aldrich Millipore Sigma | 646547-10X1ML |
| EDTA | .5 M | Ethylenediaminetetraacetic acid | Thermo Fisher | 15575020 |
| NaOH | 10 N | Sodium Hydroxide | Sigma-Aldrich | SX0607N-6 |
| Nuclease- free Water | - | Ultrapure Water, nuclease-free | Thermo Fisher | 10977015 |
| NaCl | 5M | Sodium Chloride | Thermo Fisher | 24740011 |
| LAMP Kit\* | - | Fluorimetric LAMP Kit | New England Biolabs | E1700 |
||

\* Item may not be substituted for equivalent. Only the specified vendor and catalog number may be utilized.

The FloodLAMP QuickFluor(TM) COVID-19 Test uses 18 LAMP primers targeted for 3 different SARS-CoV-2 genes, with 6 primers for each target. All 18 primers are mixed together and are input into a single amplification reaction. Primer names and sequences are listed in Table 2. Primers may be purchased pre-blended from the vendor LGC Biosearch Technologies with the product names LAMP\_S2-As1e, LAMP\_S2-N2, LAMP\_S2-E1. Alternatively, primers may be purchased as individual custom oligos. Appropriate validation of primer mixes from custom oligos is required. See Primer Preparation below for more information. 

#### Table 2: Primer names and sequences
| Primer Name | Sequence (5’-3’) |
| :---- | :---- |
| **ORF1ab gene (AS1e)** |   |
| Orf1ab\_FIP | TCAGCACACAAAGCCAAAAATTTATTTTTCTGTGCAAAGGAAATTAAGGAG |
| Orf1ab\_BIP | TATTGGTGGAGCTAAACTTAAAGCCTTTTCTGTACAATCCCTTTGAGTG |
| Orf1ab\_F3 | CGGTGGACAAATTGTCAC |
| Orf1ab\_B3 | CTTCTCTGGATTTAACACACTT |
| Orf1ab\_LF | TTACAAGCTTAAAGAATGTCTGAACACT |
| Orf1ab\_LB | TTGAATTTAGGTGAAACATTTGTCACG |
| **N Gene (N2)** |   |
| N2\_FIP | TTCCGAAGAACGCTGAAGCGGAACTGATTACAAACATTGGCC |
| N2\_BIP | CGCATTGGCATGGAAGTCACAATTTGATGGCACCTGTGTA |
| N2\_F3 | ACCAGGAACTAATCAGACAAG |
| N2\_B3 | GACTTGATCTTTGAAATTTGGATCT |
| N2\_LF | GGGGGCAAATTGTGCAATTTG |
| N2\_LB | CTTCGGGAACGTGGTTGACC |
| **E Gene (E1)** |   |
| E1\_FIP | ACCACGAAAGCAAGAAAAAGAAGTTCGTTTCGGAAGAGACAG |
| E1\_BIP | TTGCTAGTTACACTAGCCATCCTTAGGTTTTACAAGACTCACGT |
| E1\_F3 | TGAGTACGAACTTATGTACTCAT |
| E1\_B3 | TTCAGATTTTTAACACGAGAGT |
| E1\_LF | CGCTATTAACTATTAACG |
| E1\_LB | GCGCTTCGATTGTGTGCGT |
||

### Standard Lab Equipment and Consumables
* 70% ethanol  
* 10% bleach, prepared daily  
* 96-well PCR reaction plates (Applied Biosystems \# 4346906, 4366932, 4346907, Eppendorf \# 951020303 or equivalent)  
* Optical strip caps (Applied Biosystems \# 4323032 or equivalent)  
* Optical plate seal (Applied Biosystems \# 4311971 or equivalent)  
* PCR strip tubes and caps (USA Scientific catalog \# 1402-2500 or equivalent)   
* 5 mL transport tubes or equivalent (sterile)  
* 1.5 mL microcentrifuge tubes or equivalent (nuclease-free)  
* Aerosol resistant micropipette tips (nuclease-free)  
* Micropipettes (calibrated)  
* Bottle top dispenser for 1 mL volume (optional, calibrated)  
* 96-well cold block  
* Cold blocks for 5 mL and 1.5 mL \- 2.0 mL tubes, or ice  
* Vortex mixer  
* 96-well plate centrifuge or equivalent  
* Mini centrifuge for 1.5 mL tubes or equivalent  
* Thermal cycler, water bath, dry heat bath or equivalent (calibrated)  
* Class II Biological Safety Cabinet (BSC)   
* PCR Instrument (Choose 1)  
  * QuantStudio(TM) 7 Pro  
  * Bio-Rad CFX96 Touch(TM)

## Warnings and Precautions
Materials or chemicals required for the use of the FloodLAMP QuickFluor(TM) COVID-19 Test should be closely examined by the user. The user should carefully read all warnings, instructions or Safety Data Sheets provided by the supplier and follow the general safety precautions when handling biohazards, chemicals and other materials. 

### General Precautions
* The FloodLAMP QuickFluor(TM) COVID-19 Test is for *in vitro* diagnostic use (IVD) only. Rx Only.  
* For use under COVID-19 Emergency Use Authorization Only.  
* Standard precautions and procedures should be taken when handling and disposing of human samples.  
* This test has not been FDA cleared or approved; the test has been authorized by FDA under an Emergency Use Authorization (EUA) for use by laboratories certified under the Clinical Laboratory Improvement Amendments (CLIA) of 1988, 42 U.S.C. §263a, to perform high complexity tests.  
* This test has been authorized only for the detection of nucleic acid from SARS-CoV-2, not for any other viruses or pathogens.  
* This test is only authorized for the duration of the declaration that circumstances exist justifying the authorization of emergency use of *in vitro* diagnostic tests for detection and/or diagnosis of COVID19 under Section 564(b)(1) of the Act, 21 U.S.C. § 360bbb-3(b)(1), unless the authorization is terminated or revoked sooner.  
* Standard precautions and procedures should be taken when handling and extracting human samples.  
* Standard precautions and procedures should be taken when using laboratory equipment.  
* Standard precautions and procedures should be taken when disposing of waste.  
* Dispose of reagents according to local regulations.  
* Do not use reagents after their recommended stability time frame.  
* Ensure reagents are stored at the recommended temperatures as described below and in the vendor product information and manuals.

### Contamination Precautions
* Avoid contamination by following good laboratory practices, wearing proper personal protective equipment, segregating workflow, and decontaminating workspace appropriately.  
* Ensure that surfaces and equipment used for all test steps have been properly cleaned with 10% bleach and 70% ethanol.  
* Ensure all consumables are DNase and RNase free except for sample collection tubes which may be sterile.  
* Use only calibrated pipettes and filter tips that are sterile and PCR clean.  
* After completion of the test, dispose of the amplification reaction plates or tubes. **Do not open tubes** or remove the seals on plates after heating amplification reactions.

## Limitations
* The use of this assay as an *in vitro* diagnostic under the FDA COVID-19 Emergency Use Authorization (EUA) is limited to laboratories that are certified under the Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. § 263a, to perform high complexity tests by Rx only.   
* Use of this assay is limited to personnel who are trained in the procedure. Failure to follow these instructions may lead to erroneous results.   
* The performance of the FloodLAMP QuickFluor(TM) COVID-19 Test was established using Nasopharyngeal Swab specimen type collected in saline. Nasal swabs, oropharyngeal swabs, mid-turbinate nasal swabs specimens are also considered acceptable specimen types for use with the test but performance has not been established.   
* Samples must be collected according to recommended protocols and transported and stored as described herein.  
* Samples should not be collected in UTM or VTM or Liquid Amies transport media.  
* The effect of vaccines, antiviral therapeutics, antibiotics, chemotherapeutic or immunosuppressant drugs have not been evaluated.  
* Detection of SARS-CoV-2 RNA may be affected by sample collection methods, patient factors (e.g., presence of symptoms), and/or stage of infection.  
* False-positive results may arise from various reasons, including, but not limited to the following:  
  * Contamination during specimen collection, handling, or preparation  
  * Contamination during assay preparation  
  * Incorrect sample labeling  
* False-negative results may arise from various reasons, including, but not limited to the following:  
  * Improper sample collection or storage  
  * Degradation of SARS-CoV-2 RNA  
  * Presence of inhibitory substances  
  * Use of extraction reagents or instrumentation not approved with this assay   
  * Incorrect sampling window  
  * Failure to follow instructions for use  
  * Mutations In SARS-CoV-2 target sequences  
* Nucleic acid may persist even after the virus is no longer viable.   
* This test cannot rule out diseases caused by other bacterial or viral pathogens.  
* Performance has not yet been established in asymptomatic individuals and will be established during a post-authorization study.   
* Use of the test in a general, asymptomatic population for serial screening is intended to be used as part of an infection control plan, that may include additional preventative measures, such as a predefined serial testing plan or directed testing of high-risk individuals. Negative results should not be treated as definitive and do not preclude current or future infection obtained through community transmission or other exposures. Negative results must be considered in the context of an individual’s recent exposures, history, and presence of clinical signs and symptoms consistent with COVID-19.  
* This test should not be used within 30 minutes of administering nasal or throat sprays.  
* Positive results must be reported to appropriate public health authorities, following state and national guidelines.   
* The clinical performance of the test has not been established in all circulating variants, and test performance may vary depending on the prevalence of variants circulating at the time of patient testing.   
* Negative test results do not exclude possibility of exposure to or infection with SARS-CoV-2 virus. Patient handling will be directed by healthcare professionals.

## Conditions of Authorization for the Laboratory
The FloodLAMP QuickFluor(TM) COVID-19 Test Letter of Authorization, along with the authorized Fact Sheet for Healthcare Providers, the authorized Fact Sheet for Patients, and authorized labeling are available on the FDA website: [https://www.fda.gov/medical-devices/coronavirus-disease-2019-covid-19-emergency-use-authorizations-medical-devices/vitro-diagnostics-euas](https://www.fda.gov/medical-devices/coronavirus-disease-2019-covid-19-emergency-use-authorizations-medical-devices/vitro-diagnostics-euas)

However, to assist clinical laboratories running the FloodLAMP QuickFluor(TM) COVID-19 Test, the relevant Conditions of Authorization are listed below:

* Authorized laboratories1 using the FloodLAMP QuickFluor(TM) COVID-19 Test will include all authorized Fact Sheets with test result reports. Under exigent circumstances, other appropriate methods for disseminating these Fact Sheets may be used, which may include mass media.  
* Authorized laboratories1 using the FloodLAMP QuickFluor(TM) COVID-19 Test will use the FloodLAMP QuickFluor(TM) COVID-19 Test as outlined in the FloodLAMP QuickFluor(TM) COVID-19 Test Instructions for Use. Deviations from the authorized procedures, including the authorized clinical specimen types, authorized control materials, authorized other ancillary reagents and authorized materials required to perform the  test are not permitted.  
* Authorized laboratories must notify the relevant public health authorities of their intent to run the test prior to initiating testing.  
* Authorized laboratories using the FloodLAMP QuickFluor(TM) COVID-19 Test will have a process in place for reporting test results to healthcare providers and relevant public health authorities, as appropriate.  
* Authorized laboratories will collect information on the performance of the test and report to DMD/OHT7-OIR/OPEQ/CDRH (via email: CDRH-EUA-Reporting@fda.hhs.gov) and FloodLAMP Biotechnologies, PBC support center (via email: eua.support@floodlamp.bio) any suspected occurrence of false positive or false negative results and significant deviations from the established performance characteristics of the test of which they become aware.  
* All laboratory personnel using the test must be appropriately trained in molecular assay techniques and use appropriate laboratory and personal protective equipment when handling these test components, and use the test in accordance with the authorized labeling.  
* FloodLAMP Biotechnologies, PBC authorized distributors, and authorized laboratories using the FloodLAMP QuickFluor(TM) COVID-19 Test will ensure that any records associated with this EUA are maintained until otherwise notified by FDA. Such records will be made available to FDA for inspection upon request. 


1 For ease of reference, this will refer to, “Clinical Laboratory Improvement Amendments of 1988 (CLIA), 42 U.S.C. §263a certified laboratories with FDA Emergency Use Authorization FDA for performing SARS-CoV-2 testing

## Specimen Collection and Storage
Upper respiratory specimens including nasopharyngeal swabs, anterior nasal and mid-turbinate nasal swabs should be collected using standard procedures and recommendations. Swab specimens should be collected in 0.9% saline, PBS, or dry tubes. Specimens should not be collected in UTM, VTM, or Liquid Amies.

Please refer to Interim Guidelines for Collecting, Handling, and Testing Clinical Specimens for COVID-19:  
[https://www.cdc.gov/coronavirus/2019-ncov/lab/guidelines-clinical-specimens.html](https://www.cdc.gov/coronavirus/2019-ncov/lab/guidelines-clinical-specimens.html)

The stability study of the nasal swab sample transported in saline has been conducted by Quantigen Biosciences, with support from The Gates Foundation and UnitedHealth Group. Quantigen Biosciences has granted a right of reference to any sponsor wishing to pursue an EUA to leverage their COVID-19 swab stability data as part of that sponsor’s EUA request.

* Samples can be stored at room temperature for 56 hours after collection prior to inactivation.   
* For longer term storage, samples can be stored at ≤-70oC.

Note: Specimens must be packaged, shipped, and transported according to the current edition of the International Air Transport Association Dangerous Goods Regulation. Follow shipping regulations for UN 3373 Biological Substance, Category B when sending potential 2019-nCoV specimens.

## Running Tests
### Reagent Preparation
The FloodLAMP QuickFluor(TM) COVID-19 Test is to be used with the reagents or equivalents listed in Table 1. 

#### Table 1: Validated reagents used with Test
| Item | Concentration | Chemical Composition | Vendor | Catalog Number |
| :---- | ----- | :---- | :---- | :---- |
| TCEP | .5 M | tris(2-carboxyethyl)phosphine hydrochloride | Sigma-Aldrich Millipore Sigma | 646547-10X1ML |
| EDTA | .5 M | Ethylenediaminetetraacetic acid | Thermo Fisher | 15575020 |
| NaOH | 10 N | Sodium Hydroxide | Sigma-Aldrich | SX0607N-6 |
| Nuclease- free Water | - | Ultrapure Water, nuclease-free | Thermo Fisher | 10977015 |
| NaCl | 5 M | Sodium Chloride | Thermo Fisher | 24740011 |
| LAMP Kit\* | - | Fluorimetric LAMP Kit | New England Biolabs | E1700 |
||

\* Item may not be substituted for equivalent. 

Stocks of TCEP, EDTA, NaOH, and NaCl may be prepared from powder form at the specified concentration using nuclease-free MilliQ or equivalent molecular biology grade water.

0.9% Saline (154 mM) may be prepared by diluting 15.4 mL of 5 M NaCl in MilliQ or equivalent molecular biology grade water to a final volume of 500 mL. Equivalent preparations or commercial saline products may be utilized, with appropriate validation.

A 100X Inactivation Solution is prepared by mixing the components in Table 3 and vortexing for 30 seconds. Equivalent preparations utilizing components with different source concentrations may be used such that the final 100X Concentration is achieved. Aliquots of 100X Inactivation Solution should be stored in the dark at \-20°C for up to 3 months. Upon thaw, working aliquots of 100X Inactivation Solution should be stored in the dark at room temperature for up to 1 month. 

#### Table 3: 100X Inactivation Solution
| Component | Source Concentration | Volume | 100X Concentration |
| :---- | :---: | :---: | :---: |
| TCEP | 0.5 M | 10 mL | 250 mM |
| EDTA | 0.5 M | 4 mL | 100 mM |
| NaOH | 10 N | 2.3 mL | 1.15 N |
| Nuclease-free Water | - | 3.7 mL | - |
| **TOTAL VOLUME** | - | **20 mL** | - |
||

For swabs that are collected or eluted in 0.9% saline solution or equivalent, the 100X Inactivation Solution should be added at 1/100th the sample solution volume.

For dry swabs, a preparation of 1X Inactivation Saline Solution should be prepared per Table 4. 1X Inactivation Saline Solution should be kept at room temperature and used within 24 hours of preparation from components or 100X Inactivation Solution.

#### Table 4: 1X Inactivation Saline Solution
| Component | Volume |
| :---- | :----: |
| 0.9% Saline (154 mM NaCl) in MilliQ Water | 1000 mL |
| 100X Inactivation Solution | 10 mL |
| **TOTAL VOLUME** | **1010 mL** |
||

### Controls Preparation
**One positive and one negative control** will be included on every 96-well plate with up to 94 samples, or with every batch of strip tubes on each heater:

1) A “no template” (negative) control (NTC) is needed to **assure the absence of cross contamination from positive samples, positive controls, or amplicons** and is used **to determine if sample results are valid.** **It consists of nuclease-free water.**  
     
2) A positive template control is needed to **assure proper functioning of reagents and the absence of significant RNAse contamination. It consists of synthetic viral RNA at a concentration of approximately 100,000 cp/mL diluted in total human RNA and nuclease-free water.** Stock and working aliquots of the positive control are produced from the sources listed in Table 5 or equivalents. Working aliquots should be diluted prior to use to 100,000 cp/mL. Positive control aliquots should be stored for at most 3 months at \-80°C, or at most 1 month at \-20°C.   
   
#### Table 5: Components for Positive Template Control
| Material | Vendor | Catalog \# | Volume |
| :---- | :----: | :----: | :----: |
| SARS-CoV2 Positive Control RNA | Twist | 102019 | 5 µl |
| Total Human RNA | Thermo Fisher | 4307281 | 100 µl |
| Nuclease-free Water | Thermo Fisher | 10977015 | 4,895 µl |
||

### 10X LAMP Primer Mix Preparation
The FloodLAMP QuickFluor(TM) COVID-19 Test uses 18 LAMP primers targeted for 3 different SARS-CoV-2 genes, with 6 primers for each target. Primer names and sequences are shown above in Table 2. All 18 primers are mixed together and input into a single amplification reaction. 

Primers may be purchased from the vendor LGC Biosearch Technologies as 3 pre-blended sets, or the primers may be purchased as 18 individual custom oligos. Table 6 below lists the primer products to be ordered.   
   
The LGC Biosearch primer products are provided already blended for each target (6 primers per tube) and dried such that upon resuspension with 1 mL of nuclease-free water, the primers for each target are at 30X concentration. One resuspended tube for each of the 3 targets (i.e. primer blends) are mixed together to yield a 3 mL total volume that contains all individual primers at 10X concentration. This 3 mL of 10X LAMP Primer Mix provides for 1,200 reactions at 2.5 µL per reaction.  
   
Alternatively to the pre-blended LGC Biosearch products, primers may be purchased as individual custom oligos. Custom oligos may be blended to form 30X Primer Set Mixes as intermediates or all mixed together for the 10X LAMP Primer Mix. The FIP and BIP primers for each target require purification by HPLC or an equivalent process. Appropriate validation of primer mixes from custom oligos is required. Primers may be stored at 4°C for up to one month, or at \-20°C for up to 1 year.

#### Table 6: 10X LAMP Primer Mix Components
| Vendor | Item | Catalog number | Quantity | # Reactions |
|--------|------|----------------|-----------|-------------|
| Order one of the following primer sets |||||
| LGC Biosearch Technologies | SARS-CoV-2 LAMP ASIe 6 primer set at 30X (ORF1ab gene) | LAMP_S2-ASIe-48 | 6-48 nmol | 1,200 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP ASIe 6 primer set at 30X (ORF1ab gene) | LAMP_S2-ASIe-480 | 60-480 nmol | 12,000 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP N2 6 primer set at 30X (N gene) | LAMP_S2-N2-48 | 6-48 nmol | 1,200 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP N2 6 primer set at 30X (N gene) | LAMP_S2-N2-480 | 60-480 nmol | 12,000 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP E1 6 primer set at 30X (E gene) | LAMP_S2-E1-48 | 6-48 nmol | 1,200 |
| LGC Biosearch Technologies | SARS-CoV-2 LAMP E1 6 primer set at 30X (E gene) | LAMP_S2-E1-480 | 60-480 nmol | 12,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orf1ab_FIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orf1ab_BIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orf1ab_F3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orf1ab_B3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orf1ab_LF | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | Orf1ab_LB | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_FIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_BIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_F3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_B3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_LF | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | N2_LB | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_FIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_BIP | Custom Order | 1,000 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_F3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_B3 | Custom Order | 125 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_LF | Custom Order | 250 nmol | 25,000 |
| LGC Biosearch Technologies, Eurofins Genomics, Integrated DNA Technologies, Sigma | E1_LB | Custom Order | 250 nmol | 25,000 |
||

### Sample Preparation
\* For wet swab specimens (swabs in saline or unprocessed swab elution): 

1) If samples are frozen, thaw unless no ice crystals are present and then keep on ice, cold block or at 4°C.   
2) Pulse vortex each sample and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.   
3) Wipe the outside of the sample tube with 70% ethanol. 

For dry swab specimens:
1) Wipe the outside of the sample tube with 70% ethanol. 

### Sample Inactivation
1) Place the inactivation heater (a thermal cycler, water bath, dry heat bath or equivalent) in the BSC, turn on, and set the temperature to hold at 100°C.  
2) \* For wet swab specimens: transfer 1 mL or available volume of each sample to an appropriately labeled 1.5 mL or 5 mL tube and securely cap.   
3) \* For wet swab specimens: add 10 µL per 1 mL sample volume of 100X Inactivation Solution to each sample tube.  
4) For dry swab specimens (DO NOT DO FOR WET SWAB SPECIMENS): add 1 mL of 1X Inactivation Solution to each sample tube.  
5) Vortex for 30 seconds.  
6) Place sample tubes into the inactivation heater for 8 minutes.  
7) Remove sample tubes from inactivation heater and let cool at room temperature for 10 minutes.  
8) Place sample tubes on ice, in the refrigerator, or on a cold block at 4°C until ready to perform amplification reaction. 

Note: Testing of inactivated specimens must be conducted the same day inactivation is performed. For long term storage, keep the original specimen at ≤-70°C. 

### Preparing to Run Assay for the First Time
*Note: Any instrument running the FloodLAMP QuickFluor(TM) COVID-19 Test must be calibrated for the following dye: FAM*

#### Download the Template Run File
The Template Run File contains all the parameters preconfigured to run the FloodLAMP QuickFluor(TM) COVID-19 Test. These parameters can be seen in more detail under “Create the Run File ...” headings below.

To download the Template Run File:

1) Go to www.floodlamp.bio/euas  
2) Download the Template Run file(s) for the instrument type and assay to be run.

#### Table 7: Fluorescence LAMP Instrument Template Run File
| Instrument | Setup Template Filename |
| ----- | ----- |
| ABI QuantStudio(TM) 7 Pro | FloodLAMP\_QS7Pro\_Fluor\_template\_run.edt |
| Bio-Rad CFX96 Touch(TM) | FloodLAMP\_BRCFX\_Fluor\_protocol.prcl |
| Bio-Rad CFX96 Touch(TM) | FloodLAMP\_BRCFX\_Fluor\_template\_run.pltd |
||

*Note: Template Run Files only need to be downloaded once upon first use.*

#### Alternatively, Create the Template Run File on QuantStudio(TM) 7 Pro
1) Open the Design and Analysis Software  
2) Select the “SET UP PLATE” option  
3) From the sidebar on the screen, select the following properties to filter:  
   1. Instrument – choose the appropriate instrument  
   2. Block – choose the appropriate block  
   3. RunMode – Standard  
   4. Analysis options are left blank  
4. From the plate sections present on the screen, select the correct System Template and the system will automatically navigate to the "Run Method" tab  
   1. "Presence/Absence" for QuantStudio(TM) 7 Pro  
5. Change run template parameters as shown below:

   Run Parameters

- **Run Method:**  
  - 25 µL Rxn Vol.  
  - 95°C Heated Cover Temp  
  - Ramp Rate: 1.6°C/s

#### Table 8: Fluorimetric LAMP Run Parameters
| Stage | Temperature | Time | Reps |
| :---: | :---: | :---: | :---: |
| 1 | 65°C | 10 sec | 1 |
| 2 | 65°C | 10 sec | 1 |
| 3 | 65°C | 30 sec | 25 |
| 3 | 65°C \* | 30 sec | 25 |
||

*\* This step should be the optical read step*

- **Plate Setup**  
  - Target: FAM (Sars)  
  - Quencher: None  
  - Passive Reference: None

6. Once done editing the template, go to “Actions” in the top right corner, hit “Save As”  
   1. On Connect: Save to template folder  
   2. Offline: Save to preferred location

#### Alternatively, Create the Template Run File on Bio-Rad CFX96 Touch™
1. Launch the CFX96 Touch software package.  
2. In the Startup Wizard pop-up window select the instrument “CFX96” from the drop down menu.  
3. Under “Select Run Type” press the “User-defined” button.  
4. Create a new thermocycler protocol by selecting “Create New” from the Run Setup window.  
5. Under Tools in the top left toolbar select “Run Time Calculator” and check “96 Wells-All Channels”.  
6. Make the following changes to the cycling conditions in the Protocol Editor:   
a. Change the Sample Volume to 25 μL   
b. Change the Lid Setting to 95°C  
c. Change cycles to be as shown below:

#### Table 9: Thermal cycling conditions and plate read steps (BioRad CFX96)
| Stage | Temperature | Time | Reps |
| :---: | :---: | :---: | :---: |
| 1 | 65 C | 30 sec | 25 |
| 1 | 65\* C | 30 sec | 25 |
||

*\* This step should be the optical read step*

7. Click “OK” to save the protocol as type Protocol File (\*.prcl) and return to the Protocol tab in Run Setup

### Create the Plate Layout Map
#### QuantStudio(TM) 7 Pro Option 1: Sample Name Input
For this option, sample names (i.e. specimen IDs) are directly input into the instrument software prior to starting the run.

1. Open template in Design and Analysis app and go to the “Plate Setup” tab  
2. On the right side of the screen ensure the “Samples” tab is highlighted and press the addition icon to add the number of samples being tested.   
3. Click on the “Sample 1” box to rename the sample  
   1. Repeat this step for all subsequent samples being entered  
4. Click the well located in the plate map then check the box next to the sample name from the right side bar to associate the name to the well  
   1. There is also the option to highlight the well location in the plate map and click on the “Enter sample” box. Enter the sample ID and press tab to continue to the next well in the plate map. This will automatically load the sample name into the sidebar.  
5. Once the sample names have been entered, the wells may be highlighted by left clicking the mouse over the starting well and dragging the mouse across all wells associated in run. The targets are then chosen by clicking the check boxes next to each target in the sidebar  
   1. FAM should be chosen and named “Sars”  
6. Once done setting up the template, go to “Actions” in the top right corner and hit “Save As,” a pop-up window will appear directing the user to title the file according to information pertaining to the sample run  
   1. Connect: save to the desired folder (only applicable for 7 Pro)  
   2. Offline: save to a USB that is inserted into the computer  
7. Use your plate layout to load your samples and controls after preparing the amplification reaction mix.

#### QuantStudio(TM) 7 Pro Option 2: Lookup Based on Well Position
For this option, a single generic sample name is applied to all wells, and subsequently, outside of the instrument software, the results are linked to the actual sample name via a lookup table to the well position. 

1. Open template in Design and Analysis app and go to the “Plate Setup” tab  
2. Highlight the entire plate and add 1 sample to all wells, with the same sample name in every well.  
3. Highlight entire plate and add FAM to all wells  
4. Go to “Actions” in the top right corner and hit “Save As” and name the template as desired.  
   1. Connect: save to desired location   
   2. Offline: save to a USB that is inserted into the computer

This process only needs to be done once – all subsequent runs can use the same Template Run File. 

#### Bio-Rad CFX96 Touch(TM):
1. Launch the CFX96 Touch software package and open the correct protocol template  
2. Review the details of the protocol. If correct, click “Next” to proceed to the Plate tab  
3. On the Plate tab, click “Create New” and the Plate Editor appears.   
4. Use the Plate Editor to create a new plate.   
5. To ensure the correct plate size is selected, go to “Settings \> Plate Size” and check that 96-well or 384-well is selected from the drop-down menu.   
   1. The plate size selected must correspond to the block size of the instrument being used.   
6. To set the plate type, select” Settings \> Plate Type” and select “BR Clear” or “BR White” from the drop-down menu.   
   1. The plate type selected should match the plate type used in the run.   
7. To set the scan mode, select the “All Channels” scan mode from the Scan Mode drop-down list in the Plate Editor toolbar.  
8. Select the “Select Fluorophores” button on the upper right of the Plate Editor window   
   1. De-select all default fluorophores and select “FAM”and click OK  
9. In the Plate Editor window highlight the whole plate and click the checkbox in front of FAM  
10. Select the “Experiment Settings” button in order to define the Targets   
    1. In the lower left of the Experiment Settings window in the New box type in “N1” and select “Add”   
    2. Select “OK”   
11. In the Plate Editor window next to FAM in the drop-down menu under Target Name select “Sars”  
12. Click OK to save changes and close the “Select Fluorophores” dialog box. 

#### Bio-Rad CFX96 Touch(TM) Option 1: Sample Name Input
For this option, sample names (i.e. specimen IDs) are directly input into the instrument software prior to starting the run.

1. Load the appropriate sample type to each well by selecting the well and selecting the appropriate Sample Type (Unknown, NTC, or Positive Control) from the drop-down menu.  
2. Multiple wells can be selected at once to load the sample type  
   1. Note: the EC can be listed as an Unknown sample.   
3. In the “Target Names” section confirm that the necessary fluorophores are assigned to each well.   
4. Name each well as desired by typing in the sample name and pressing “Enter” in the Sample Names dropdown list in the right pane.   
5. Click OK to save the Plate File (\*.pltd)and return to the Plate tab in Run Setup. When prompted, specify a name for the plate and a save location

#### Bio-Rad CFX96 Touch(TM) Option 2: Lookup Based on Well Position
For this option, a single generic sample name is applied to all wells, and subsequently, outside of the instrument software, the results are linked to the actual sample name via a lookup table to the well position. 

1. Name the file as desired and save as type “Plate File (\*.pltd)”  
2. Select “Save”, click “OK” in the Plate Editor window and exit the software

For this method of creating a Plate Layout Map, this process only needs to be repeated once – all subsequent runs can use the same template. 

### Fluorimetric LAMP Amplification Reaction Preparation
1) Place a 96-well PCR plate or PCR strip tubes onto a cold block or ice.  
2) Thaw frozen reagents until ice crystals are not present.   
3) Pulse vortex thawed reagents for 3 seconds and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.  
4) Store on ice, in the refrigerator, or on a cold block at 4°C until ready to use.  
5) Prepare the Fluorimetric LAMP Amplification Reaction Mix by combining the components listed below in Table 10. 

      NOTE: Component volumes should be scaled proportionally for the number of reactions. 

6) Vortex the Fluorimetric LAMP Amplification Reaction Solution for 10 seconds and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.  
7) Add 23 µL of the Fluorimetric LAMP Amplification Reaction Solution into the wells of the PCR plate or PCR strip tubes.

#### Table 10: Fluorimetric LAMP Amplification Reaction
| Component | Volume (1 reaction) | Volume (100 reactions) |
| ----- | :---: | :---: |
| 10X LAMP Primer Mix | 2.5 µL | 250 µL |
| Nuclease-Free Water | 7.5 µL | 750 µL |
| Fluorimetric LAMP MM | 12.5 µL | 1250 µL |
| Fluorescent Dye | .5 µL | 50 µL |
| **SUBTOTAL VOLUME** | **23 µL** | **2300 µL** |
| Sample | 2 µL | - |
| **REACTION VOLUME** | **25 µL** | - |
|||

### Sample Addition
NOTE: Ensure that positive and negative controls are included in each batch run (i.e. in each PCR plate or group of strip tubes that are heated together).

1) Add 2 µL of each sample into a separate tube in the amplification reaction PCR plate or strip tubes.   
2) Mix by pipetting.  
3) If using PCR plate optical seal (optionally using heat sealer). If using PCR strip tubes, cap strips.  
4) Pulse vortex and briefly spin down in a centrifuge to collect the liquid at the bottom of the tube.  
5) Continue to section “Run the Assay”

### Run the Assay
Refer to Specific Instrument User Manuals for full system usage and maintenance details.

#### On QuantStudio(TM) 7 Pro
1. Log into user on instrument.  
2. USB: Plug in USB with saved template on it.  
3. From the options on the instrument’s screen press “Load plate file”.  
   1. The QuantStudio(TM) 7 Pro is a touchscreen device.  
4. From the “Run Queue” screen,   
   1. USB: press “USB drive” on the left side.  
   2. Connect: press Cloud icon on the left side.  
5. This will bring up any plate files saved.  
6. Press the plate file associated with the run to be performed.  
7. A new window will appear requesting location of results once the run is complete.  
   1. Connect: Press the “Cloud Connect” icon, press again to verify location the files will be uploaded to and then press “Done”.  
   2. USB: Press the “USB drive Connected” if the icon is not already highlighted and press “Done”.   
8. Press the double-arrow icon located at the top right sided corner of the screen on the instrument.   
   1. The instrument drawer will open from the front.   
9. Place the plate/strips into the plate holder ensuring proper orientation of the plate.   
   1. A1 well should be in the position of the top left corner.  
   2. The plate/strips will appear slightly suspended above the block due to two silicone strips above and below this plate. This is to be expected and the instrument lid will press the plate down once the drawer has closed.   
10. Press “Start Run” on the screen of the instrument.   
    1. A pop-up window will appear asking the user to confirm the plate has been loaded.   
    2. If the plate has been loaded, press “StartRun” again or press “Open Drawer” to place the plate into the block and then press “Start Run”.

#### On Bio-Rad CFX96 Touch(TM)
1) Open the correct .pcrl file and review the protocol details. If correct click “Next” to proceed to the Plate tab.  
2) When prompted, open the correct .pltd file and review the plate details in the Run Information section.  
3) Select the checkbox for the appropriate block (CFX96 or CFX384) on which to perform the run.  
4) To insert the plate or 8-tube strips into the block, click Open Lid.  
5) Insert the plate or 8-tube strips into the block. Ensure the plate or 8-tube strips are properly oriented.  
6) Click Close Lid.  
7) Click Start Run at the bottom right of the screen.  
8) When prompted, save the data file (.pcrd) to the desired location.

### Analyzing Data
#### Exporting Data from QuantStudio(TM) 7 Pro
##### Using USB
1) Confirm Quant says “File Transferred \- USB”  
2) Take USB from Quant and plug it into computer  
3) Export data off of USB onto computer

##### Using Cloud Connect with QuantStudio(TM) 7 Pro
1) Go to [Cloud Connect](https://apps.thermofisher.com/apps/spa/#/dashboard%20%20) and log in.  
2) Go to files and find the data that was just uploaded by the Quant, it will be in the folder chosen previously chosen while running the Quant  
3) Download .xlsx file  

#### Exporting Data from Bio-Rad CFX96 Touch(TM)
1) After the run has completed, open the data file (.pcrd) by going to Select File \> Open \> Data File in the Home window and locating the desired data file. Adjust the following settings as described below.   
2) Select Settings \> Cq Determination mode and select Single Threshold.   
3) Select Settings \> Baseline Setting and select Baseline Subtracted.   
4) Select Settings \> Analysis Mode and select analysis by fluorophore.   
5) Select Settings \> Cycles to Analyze and the Cycles to Analyze dialog box appears. Confirm that all cycles are being analyzed and click “OK”.   
6) Cq values of each well are displayed in the Quantification Data tab.   
7) Export .xlsx files and select Export \> Export all Data Sheets to Excel (Cq values are available in "Quantification Plate View Results").  

#### Compiling Results Option 1: Lookup Based on Well Position
For this option, outside of the instrument software the results are linked to the actual sample name via a lookup table to the well position. An example spreadsheet to perform this lookup and results compilation is available with instructions at [www.floodlamp.bio/euas](http://www.floodlamp.bio/ifus).

#### Compiling Results Option 2: Sample Name Input
For this option, sample names (i.e. specimen IDs) are directly input into the instrument software prior to starting the run. Open the results file and continue to “Analyzing Data” section to score results.

### Results Interpretation
#### Test Controls
All test controls should be examined prior to interpretation of patient specimen results. If the controls are not valid and the expected result, the specimen results cannot be interpreted. Target results for the controls will be interpreted according to Table 11 below.

1) The “No Template” (Negative) Control (NTC) should yield a negative “not detected” result for the SARS target  
     
2) The Positive Template Control should yield a positive “detected” result for the SARS target  
     
3) The Internal Process Control is required to report a negative SARS-CoV-2 result. 

If the negative and positive controls do not appear as expected, the specimen results of the corresponding plate or batch should be considered invalid. In the event of a failure of either the positive or negative control, the lab should discard some or all of the consumables utilized for associated run, including the filter tips, tubes, plates, seals, and aliquots of reagents. Additionally, all pipettes, BSC, and appropriate lab surfaces should be thoroughly cleaned with freshly made 10% bleach solution, 70% ethanol, and (optionally) RNAseZAP(TM) product. In the event of the failure of the positive control, the working aliquot of positive control material should be discarded. Additionally, the lab should review the expiration of the batch of positive control aliquots and verify their integrity by performing qualification reactions of one or more positive control aliquots. If controls continue to fail, labs should not perform additional tests on clinical specimens or report results. Invalid test results should be repeated by performing another amplification reaction.

### Patient Specimen Results Interpretation
NOTE: Patient specimen results can only be interpreted if the positive and negative controls in the plate or group of strip tubes have the expected results.

Use Table 11 below to assign a result to each sample. 

#### Table 11: Interpretation of Assay Results
| ABI QuantStudio(TM) 7 Pro Bio-Rad CFX96 Touch(TM) |  |  |
| :---: | :---: | :---: |
| **Result** | **Ct Value: N1** |  |
| Positive | ≤25.0 |  |
| Negative | Undetermined |  |
|||

## Performance Evaluation
### Analytical Sensitivity: Limit of Detection (LoD)
The Limit of Detection (LoD) for the FloodLAMP QuickFluor(TM) COVID-19 Test was established using gamma irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) spiked into negative real specimens. The negative specimens were confirmed by PCR using the CDC primers. The gamma irradiated virus was spiked into the specimen prior to the heat inactivation step, and carried through the entire assay. The concentration of spike was such that the contrived positive sample was at 100,000 copies/mL after the inactivation step. The stock contrived positive was diluted into inactivated negative sample matrix to produce the concentrations for the LoD study. A preliminary LoD run was performed using the concentrations ranging from 100,000 copies/mL to 3,100 copies/mL. Concentrations of 50,000, 25,000 and 12,500 copies/mL were selected for confirmatory LoD runs. LoD run details are provided in Supporting Data, with the results summarized below in Table 12. The LoD, defined as the concentration at which at least 95% of the samples are positive, was determined at 50,000 copies/mL.

#### Table 12: LoD Confirmatory Data Results
| Instrument | LoD | Positive Replicates | Mean Ct Value (SD) |
| ----- | ----- | :---: | :---: |
| ABI QuantStudio(TM) 7 Pro | 50,000 copies/mL | 95% (20/21) | 11.9 (1.5) |
| ABI QuantStudio(TM) 7 Pro | 25,000 copies/mL | 76% (16/21) | 13.8 (2.3) |
||

### Analytical Sensitivity: Inclusivity (*in silico*)
An inclusivity study was conducted for the ORF1ab, N2, and E1 primer sets against all complete, high coverage SARS-CoV-2 sequences deposited at GISAID as of February 27, 2021. Table 13 summarizes the results of this *in silico* inclusivity analysis. A total of 498,224 sequences were considered. There are 10 sequence isolates that have 1mm to both As1e and E1 and had N2 excluded due to greater than 15 N's, with the other 498,214 sequence isolates all have at least 1 target region that is a complete match.

Each primer set matched at 100% similarity against the SARS-CoV-2 RefSeq reference genome (Wuhan-Hu-1; NC\_045512.1). All three primer sets differed by one or fewer mutations for 99.7% of GISAID sequences, indicating nominal primer hybridization for all SARS-CoV-2 variants under consideration.	

#### Table 13: *In Silico* Inclusivity Analysis for LAMP Primers
| Primer | AS1e  (ORF1ab gene) |  | N2  (N gene) |  | E1  (E gene) |  |
| :---- | ----- | ----- | ----- | ----- | ----- | ----- |
| **Total Primer Length** | 195 |  | 169 |  | 168 |  |
| **Total \# of Strains Evaluated** | 498,224 |  | 498,224 |  | 498,224 |  |
| **100% Match** | 474,717 | 95.3% | 479,548 | 96.3% | 462,538 | 92.8% |
| **1 Mismatch** | 19,301 | 3.9% | 15,698 | 3.2% | 30,626 | 6.1% |
| **2 Mismatches** | 338 | 0.1% | 161 | 0.0% | 1,455 | 0.3% |
| **3 Mismatches** | 9 | 0.0% | 5 | 0.0% | 103 | 0.0% |
| **\> 3 Mismatches** | 0 | 0.0% | 0 | 0.0% | 1 | 0.0% |
| **Total Strains Removed** | 3,859 | 0.8% | 2,812 | 0.6% | 3,501 | 0.7% |
||

### Evaluation of Impact of Viral Mutations
The As1e, E1 and N2 primer regions of all SARS-CoV-2 genomes present in GISAID as of 2/26/2021 were evaluated to assess the potential impact of genomic variants on LAMP primer binding. This analysis was performed with the Primer Monitoring Tool from New England Biolabs ([primer-monitor.neb.com](http://primer-monitor.neb.com)), which continually monitors registered primer sets for overlapping variants in sequences from GISAID. Results are summarized by region and locus below in Table 14, including the 30 countries with most sequences in GISAID. Sequences were aligned to the SARS-CoV-2 reference sequence (NC\_045512.2) using minimap2 (minimap2 \-t 16 \-x asm5 \-a). Variant sites (excluding Ns) were identified using samtools mpileup and summarized by region and genome position. Genomic positions having \>= 40 global variant observations are shown (column labels). When present, box labels indicate the fraction of variants observed at a given locus.

The aggregate of current published mutations are not expected to reduce performance of the FloodLAMP QuickFluor(TM) COVID-19 Test by more than 5% from that established by the performance evaluation in this EUA submission. Further, the use of 3 primer sets targeting different regions in the SARS-CoV-2 genome should make the test robust to new genetic variants.

#### Table 14: Variant Analysis of LAMP Primers
_Heatmap charts showing variant frequency at LAMP primer binding sites across 30 countries for AS1e, N2, and E1 primer sets, based on GISAID sequences aligned to the SARS-CoV-2 reference genome._

### Analytical Specificity: Cross-Reactivity (*in silico*)
*In silico* cross-reactivity analysis was performed by aligning the primer sequences of the FloodLAMP QuickFluor(TM) COVID-19 Test against sequences of other coronaviruses and common respiratory flora using the BLASTn alignment tool from NCBI. Results of this analysis are presented in Tables 15A, 15B, and 15C. 

The % identity range (\# identical bases/ \# primer bases) is shown for each primer and organism. Darker font indicates % identity greater than 80%. Organisms with \>= 50% identity primer hits are shown. This analysis is not intended to predict amplification. Near perfect homology across B3, F3, FIP and BIP is necessary to support successful amplification. With the exception of SARS-CoV, simultaneous homologies do not occur between any of the primers and microorganisms screened. With respect to clinical relevance of the *in silico* cross-reactivity analysis, there are no known circulating strains of SARS-CoV circulating in humans, thus the overall probability for the test to produce a cross-reactive signal is negligible.

#### Table 15A: *In Silico* Cross-Reactivity Analysis for AS1e Primers
| Organism Group | Organism Name | Organism ID | As1_B3 (22 bp) | As1e_BIP (49 bp) | As1_F3 (18 bp) | As1e_FIP (51 bp) | As1_LB (27 bp) | As1_LF (28 bp) |
|---|---|---|---|---|---|---|---|---|
| Same genetic family | SARS coronavirus 2 | NC_045512.2 | 100% | 47%-55% | 100% | 43%-53% | 100% | 100% |
| | Human coronavirus HKU1 | NC_006577.2 | 0% | 0% | 0% | 0% | 0% | 0% |
| | Human coronavirus NL63 | NC_005831.2 | 0% | 0% | 0% | 0% | 0% | 0% |
| | Human coronavirus OC43 strain ATCC VR-759 | NC_006213.1 | 0% | 0% | 0% | 0% | 0% | 0% |
| | SARS coronavirus | NC_004718 | 0% | 0% | 0% | 0% | 0% | 0% |
| Other high priority organisms | Candida albicans SC5314 chromosome 6 sequence | NC_032094.1 | | | 72%-89% | 29% | 52%-67% | |
| | Candida albicans SC5314 chromosome R sequence | NC_032096.1 | 77% | | 89% | 37%-51% | 52%-89% | |
| | Haemophilus influenzae NCTC8143, chromosome: 1 | NZ_LN831035.1 | 59%-73% | 33%-35% | 89% | 33%-45% | 52% | |
| | Candida albicans SC5314 chromosome 2 sequence | NC_032090.1 | 59%-73% | 31% | 72%-83% | 29%-59% | 52% | |
| | Mycobacterium tuberculosis H37Rv | NC_000962.3 | | | 83% | | | |
| | Candida albicans SC5314 chromosome 4 sequence | NC_032092.1 | 59%-82% | 39% | | 29%-41% | 67% | 61% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.3 | NW_017264777.1 | 59%-82% | | 72% | 39%-87% | 59% | |
| | Streptococcus pyogenes NCTC8198, chromosome: 1 | NZ_LN831034.1 | 59%-82% | 31% | 72% | 31% | 52%-67% | |
| | Candida albicans SC5314 chromosome 7 sequence | NC_032095.1 | | | 72%-78% | | 70% | |
| | Mycoplasma pneumoniae FH chromosome | NZ_CP010546.1 | | | 72% | 29%-35% | 78% | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.15 | NW_017264789.1 | 59% | | | 78% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.11 | NW_017264785.1 | 77% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.7 | NW_017264781.1 | 77% | | | 35% | 63% | |
| | Candida albicans SC5314 chromosome 1 sequence | NC_032089.1 | 59% | 43%-49% | 72% | 29%-57% | 63%-74% | 68% |
| | Legionella pneumophila subsp. pascullei strain NCTC12273, chromosome: 1 | NZ_LR134380.1 | 59%-73% | 49% | 72% | 31%-41% | 56%-74% | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.12 | NW_017264786.1 | | | | 31%-43% | 74% | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.8 | NW_017264782.1 | 73% | | 72% | 29%-39% | 52% | |
| | Staphylococcus epidermidis ATCC 12228 | NC_004461.1 | 59%-68% | 31%-37% | 72% | 29%-35% | 56%-67% | 57%-71% |
| | Streptococcus pneumoniae NCTC7465, chromosome: 1 | NZ_LN831051.1 | 59%-68% | 37%-41% | 72% | 29%-41% | 52%-63% | 50% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.14 | NW_017264788.1 | | | | 35% | | 71% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.6 | NW_017264780.1 | | | | 29%-47% | 70% | 68% |
| | Candida albicans SC5314 chromosome 5 sequence | NC_032093.1 | 59%-68% | 35% | | 29%-43% | | 68% |
| | Chlamydia pneumoniae TW-183 | NC_005043.1 | 68% | 37% | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.2 | NW_017264776.1 | 68% | | | 33%-49% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.5 | NW_017264779.1 | | 43% | | 38% | | 68% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.16 | NW_017264790.1 | 64% | | | | | 57% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.1 | NW_017264775.1 | | | | 33%-35% | 59% | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.13 | NW_017264787.1 | 59% | | | | | 50% |
| | Bordetella pertussis 18323 | NC_018518.1 | | | | | | 57% |
| | Rothia mucilaginosa DY-18 DNA | NC_013715.1 | | | | | 52% | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.25 | NW_017264799.1 | | | | | | 50% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.66 | NW_017264840.1 | | | | | | 50% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.4 | NW_017264778.1 | | | | 39%-47% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.54 | NW_017264828.1 |  | 47% | | | | |
| | Candida albicans SC5314 chromosome 3 sequence | NC_032091.1 | | 31% | | 31%-45% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.10 | NW_017264784.1 | | | | 33%-45% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.19 | NW_017264793.1 | | | | 38% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.9 | NW_017264783.1 | | | | 35% | | |
| | Respiratory syncytial virus | NC_001803.1 | | | | 33% | | |
||

#### Table 15B: *In Silico* Cross-Reactivity Analysis for N2 Primers
| Organism Group | Organism Name | Organism ID | N2_B3 (25 bp) | N2_BIP (40 bp) | N2_F3 (21 bp) | N2_FIP (42 bp) | N2_LB (20 bp) | N2_LF (21 bp) |
|---|---|---|---|---|---|---|---|---|
| Same genetic family | SARS coronavirus 2 | NC_045512.2 | 100% | 53% | 100% | 48%-55% | 100% | 100% |
| | SARS coronavirus | NC_004718 | 64% | 53% | 90% | 55% | 85% | 90% |
| | Human coronavirus HKU1 | NC_006577.2 | 0% | 0% | 0% | 0% | 0% | 0% |
| | Human coronavirus NL63 | NC_005831.2 | 0% | 0% | 0% | 0% | 0% | 0% |
| | Human coronavirus OC43 strain ATCC VR-759 | NC_006213.1 | 0% | 0% | 0% | 0% | 0% | 0% |
| Other high priority organisms | Streptococcus pneumoniae NCTC7465, chromosome: 1 | NZ_LN831051.1 | 60%-80% | | 95% | | 75% | 62%-71% |
| | Rothia mucilaginosa DY-18 DNA | NC_013715.1 | | | | 40% | 75%-90% | |
| | Bordetella pertussis 18323 | NC_018518.1 | | 35% | | | 65%-80% | 81% |
| | Candida albicans SC5314 chromosome 6 sequence | NC_032094.1 | 56%-72% | 43% | | | | 62%-81% |
| | Candida albicans SC5314 chromosome 7 sequence | NC_032095.1 | 56%-76% | | 62%-71% | 45% | | 62%-81% |
| | Candida albicans SC5314 chromosome R sequence | NC_032096.1 | 56%-80% | 35%-68% | 62% | | | 62%-81% |
| | Candida albicans SC5314 chromosome 4 sequence | NC_032092.1 | 60%-80% | 35%-45% | 71% | | | 62%-71% |
| | Candida albicans SC5314 chromosome 1 sequence | NC_032089.1 | 60%-72% | 35%-45% | 71%-76% | | | 62%-76% |
| | Chlamydia pneumoniae TW-183 | NC_005043.1 | 56%-76% | | 76% | 36% | 65% | |
| | Legionella pneumophila subsp. pascullei strain NCTC12273, chromosome: 1 | NZ_LR134380.1 | 60%-76% | 43% | | 36%-55% | | 62%-76% |
| | Mycoplasma pneumoniae FH chromosome | NZ_CP010546.1 | 60% | | | | 65%-75% | 76% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.7 | NW_017264781.1 | 68%-64% | | | | | 76% |
| | Pseudomonas aeruginosa PAO1 | NC_002516.2 | | 35% | | | 75% | |
| | Candida albicans SC5314 chromosome 2 sequence | NC_032090.1 | 56%-72% | 48% | 62% | 40% | | 67%-71% |
| | Candida albicans SC5314 chromosome 3 sequence | NC_032091.1 | 56%-72% | | 71% | | | 62% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.17 | NW_017264791.1 | 56%-72% | | | | | 62% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.4 | NW_017264778.1 | 60%-72% | | 71% | | | |
| | Candida albicans SC5314 chromosome 5 sequence | NC_032093.1 | 56%-68% | 35% | | | | 62%-71% |
| | Human parainfluenza virus 1 | NC_003461.1 | | | 71% | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.16 | NW_017264790.1 | 60%-68% | | | | | 62%-71% |
| | Haemophilus influenzae NCTC8143, chromosome: 1 | NZ_LN831035.1 | 60%-68% | 50% | | 43% | | 62%-67% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.13 | NW_017264787.1 | 68% | | | | | |
| | Staphylococcus epidermidis ATCC 12228 | NC_004461.1 | 60%-68% | | 62% | | | 62% |
| | Mycobacterium tuberculosis H37Rv | NC_000962.3 | | | | | | 67% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.1 | NW_017264775.1 | 56% | | | | | 67% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.3 | NW_017264777.1 | 56%-60% | | | | | 67% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.8 | NW_017264782.1 | 64% | 35% | | | | |
| | Streptococcus pyogenes NCTC8198, chromosome: 1 | NZ_LN831034.1 | 60%-64% | 43%-50% | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.6 | NW_017264780.1 | 60% | | | | | 62% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.25 | NW_017264799.1 | 60% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.5 | NW_017264779.1 | 60% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.51 | NW_017264825.1 | 60% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.66 | NW_017264840.1 | 60% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.67 | NW_017264841.1 | 60% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.2 | NW_017264776.1 | 56% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.21 | NW_017264795.1 | 52% | | | | | |
||

#### Table 15C: *In Silico* Cross-Reactivity Analysis for E1 Primers
| Organism Group | Organism Name | Organism ID | E1_B3 (22 bp) | E1_BIP (44 bp) | E1_F3 (23 bp) | E1_FIP (42 bp) | E1_LB (19 bp) | E1_LF (18 bp) |
|---|---|---|---|---|---|---|---|---|
| Same genetic family | SARS coronavirus 2 | NC_045512.2 | 100% | 45%-57% | 100% | 45%-62% | 100% | 100% |
| | SARS coronavirus | NC_004718 | 95% | 55% | 100% | 43%-62% | 100% | 100% |
| | Human coronavirus HKU1 | NC_006577.2 | 0% | 0% | 0% | 0% | 0% | 0% |
| | Human coronavirus NL63 | NC_005831.2 | 0% | 0% | 0% | 0% | 0% | 0% |
| | Human coronavirus OC43 strain ATCC VR-759 | NC_006213.1 | 0% | 0% | 0% | 0% | 0% | 0% |
| Other high priority organisms | Candida albicans SC5314 chromosome R sequence | NC_032096.1 | | | | 40%-50% | | 72%-89% |
| | Pseudomonas aeruginosa PAO1 | NC_002516.2 | | | | | 84% | 72% |
| | Legionella pneumophila subsp. pascullei strain NCTC12273, chromosome: 1 | NZ_LR134380.1 | 59%-73% | | | 36%-40% | | 78%-83% |
| | Candida albicans SC5314 chromosome 2 sequence | NC_032090.1 | 59%-82% | | 43% | | | 72% |
| | Candida albicans SC5314 chromosome 4 sequence | NC_032092.1 | | | | 43%-50% | | 78% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.12 | NW_017264786.1 | | | | | | 78% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.7 | NW_017264781.1 | | | | | | 78% |
| | Staphylococcus epidermidis ATCC 12228 | NC_004461.1 | | 45% | | 43%-48% | | 72%-78% |
| | Haemophilus influenzae NCTC8143, chromosome: 1 | NZ_LN831035.1 | 77% | | | 36%-43% | | |
| | Candida albicans SC5314 chromosome 1 sequence | NC_032089.1 | 59%-73% | | | 38%-48% | | 72% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.3 | NW_017264777.1 | 59%-73% | | 65% | 43% | | |
| | Streptococcus pyogenes NCTC8198, chromosome: 1 | NZ_LN831034.1 | 73% | 41% | | 48% | | 72% |
| | Candida albicans SC5314 chromosome 3 sequence | NC_032091.1 | 59% | | | 43%-48% | | 72% |
| | Candida albicans SC5314 chromosome 7 sequence | NC_032095.1 | | | | 36%-50% | | 72% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.4 | NW_017264778.1 | | | | | | 72% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.5 | NW_017264779.1 | | | 65% | | | 72% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.9 | NW_017264783.1 | 59%-68% | | | | | 72% |
| | Streptococcus pneumoniae NCTC7465, chromosome: 1 | NZ_LN831051.1 | 59%-68% | | | 40% | 68% | 72% |
| | Candida albicans SC5314 chromosome 6 sequence | NC_032094.1 | | | 70% | | 40%-50% | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.13 | NW_017264787.1 | | | 70% | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.1 | NW_017264775.1 | 68% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.2 | NW_017264776.1 | 68% | | | 45% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.6 | NW_017264780.1 | 68% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.16 | NW_017264790.1 | 59%-64% | | | 40% | | |
| | Candida albicans SC5314 chromosome 5 sequence | NC_032093.1 | 59% | | | 40%-43% | | |
| | Chlamydia pneumoniae TW-183 | NC_005043.1 | 0%-59% | 0% | 0% | 0%-36% | 0% | 0% |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.10 | NW_017264784.1 | 59% | | | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.20 | NW_017264794.1 | 59% | | | | | |
| | Mycobacterium tuberculosis H37Rv | NC_000962.3 | | 34% | 57% | | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.30 | NW_017264804.1 | | | | 50% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.69 | NW_017264843.1 | | | | 50% | | |
| | Mycoplasma pneumoniae FH chromosome | NZ_CP010546.1 | | | | 43% | | |
| | Pneumocystis jirovecii RU7 chromosome Unknown supercont1.8 | NW_017264782.1 | | | | 40% | | |
||

### Analytical Specificity: Cross-Reactivity (*wet testing*)
Wet testing was performed to demonstrate that the FloodLAMP QuickFluor(TM) COVID-19 Test does not react with related pathogens, high prevalence disease agents and normal or pathogenic flora that are reasonably likely to be encountered in a clinical specimen.  SARS-CoV, RSV, Flu, Human Metapneumovirus. and Streptococcus Salivarius were tested for potential cross-reactivity, as shown in Table 16 and Supporting Data. 5 µL of each stock of cross-reactivity organism was spiked on dried AN swab specimens. A contrived positive control was produced by spiking gamma irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) onto dried AN swab specimens. Control dried swabs obtained simultaneously were confirmed to be SARS-CoV-2 negative by PCR using the CDC primers. The gamma irradiated SARS-CoV-2 virus and cross-reactivity organisms were spiked into the dried swabs prior to the heat inactivation step, and carried through the full test protocol. The contrived positive had 38 µL of 1e6 copies/mL irradiated virus stock spiked in, producing after elution of the swab in 1 mL of Inactivation Saline Solution at most a concentration of 38,000 copies/mL in the sample input into the amplification reaction.

All wet testing showed no cross-reactivity with the viral pathogens and common respiratory flora, as shown in Table 16.

#### Table 16: Wet Testing Cross-Reactivity Results
| Organism | Description | BEI Number | Detected Replicates |
| ----- | ----- | :---: | :---: |
| SARS-CoV | UV-inactivated virus | NR-3882 | 0/3 |
| Human Metapneumovirus | Genomic RNA | NR-49122 | 0/3 |
| RSV | Genomic RNA | NR-43976 | 0/3 |
| Influenza B | Genomic RNA | NR-45848 | 0/3 |
| Streptococcus salivarius | Bacterial cell culture | HM-121 | 0/3 |
||

### Analytical Specificity: Interfering Substances
Exogenous and endogenous substances were tested for potential interference with the FloodLAMP QuickFluor(TM) COVID-19 Test. 10 µL of each stock of interfering substance was spiked on dried AN swab specimens. A contrived positive control was produced by spiking gamma irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) onto dried AN swab specimens. Control dried swabs obtained simultaneously were confirmed to be SARS-CoV-2 negative by PCR using the CDC primers. The gamma irradiated SARS-CoV-2 virus and interfering substances were spiked into the dried swabs prior to the heat inactivation step, and carried through the full test protocol. The contrived Positive Control Spiked comprised 20 µL of 8e6 copies/mL irradiated virus stock spiked in, producing after elution of the swab in 1 mL of Inactivation Saline Solution at most a concentration of 160,000 copies/mL in the sample input into the amplification reaction.
Exogenous and endogenous substances were tested for potential interference with the FloodLAMP QuickFluor(TM) COVID-19 Test. 10 µL of each stock of interfering substance was spiked on dried AN swab specimens. A contrived positive control was produced by spiking gamma irradiated SARS-CoV-2 virus cell lysate (BEI NR-52287) onto dried AN swab specimens. Control dried swabs obtained simultaneously were confirmed to be SARS-CoV-2 negative by PCR using the CDC primers. The gamma irradiated SARS-CoV-2 virus and interfering substances were spiked into the dried swabs prior to the heat inactivation step, and carried through the full test protocol. The contrived Positive Control Spiked comprised 20 µL of 8e6 copies/mL irradiated virus stock spiked in, producing after elution of the swab in 1 mL of Inactivation Saline Solution at most a concentration of 160,000 copies/mL in the sample input into the amplification reaction.

All interfering substance testing showed no disagreement with expected positive and negative results, as shown in Table 17 and Supporting Data.

#### Table 17: Interfering Substances Results
| Interfering Substance | Active Ingredient | Concentration | % Agreement with Expected Results |  |
| :---: | :---: | :---: | :---: | :---: |
|  |  |  | **Positive Control Spiked** | **Negative Control Unspiked** |
| Blood | N/A | 1% v/v | 100% (3/3) | 100% (3/3) |
| Nasal Congestion Spray | Acetaminophen, Guaifenesin, Phenylephrine HCI | 20% v/v | 100% (3/3) | 100% (3/3) |
| Nasal Allergy Spray | Oxymetazoline HCl | 15% v/v | 100% (3/3) | 100% (3/3) |
| Lozenges | Menthol | 10% w/v | 100% (3/3) | 100% (3/3) |
| Mucin | N/A | 0.5% w/v | 100% (3/3) | 100% (3/3) |
||

## Clinical Evaluation
The clinical evaluation of the FloodLAMP QuickFluor(TM) COVID-19 Test utilized confirmed clinical anterior nares swab specimens. 40 positive and 40 negative clinical specimens were evaluated and compared to a high sensitivity EUA authorized test run on the original fresh samples. The FloodLAMP QuickFluor(TM) COVID-19 Test showed a positive agreement of 80.0% and a negative agreement of 100%. The six false negative results were specimen with high Ct values as previously measured by the comparator test, indicating low viral load. A summary of the clinical performance is shown below in Table 18.

#### Table 18: Clinical Evaluation Results
| FloodLAMP QuickFluor(TM) COVID-19 Test Results | Comparator \- High Sensitivity EUA Authorized Test |  |  |
| :---: | :---: | :---: | :---: |
|  | **Positive** | **Negative** | **Total** |
| Positive | 34 | 0 | 34 |
| Negative | 6 | 40 | 46 |
| Total | 40 | 40 | 80 |
| Positive Agreement | 85.0% (34/40) 95% CI: 70.2% to 94.3% |  |  |
| Negative Agreement | 100% (40/40) 95% CI: 91.2% to 100% |  |  |
||

## Support

FloodLAMP Biotechnologies, PBC support center   
eua.support@floodlamp.bio  
650-394-5233

QuantStudio(TM)  is a trademark of Thermo Fisher Scientific (NYSE: TMO)

Bio-Rad(TM) and Bio-Rad CFX96 Touch(TM)  are trademarks of Bio-Rad Laboratories, Inc. (NYSE: BIO)
